<?php
define("_WIKI_WIKI","Wiki");
define("_WIKI_GOTOWIKI","Μεταβαση στο wiki του μαθήματος");
define("_WIKI_NOPAGESFOUND","Δεν υπάρχουν αλλαγές στις wiki σελίδες");
?>