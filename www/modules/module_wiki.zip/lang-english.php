<?php
define("_WIKI_WIKI","Wiki");
define("_WIKI_GOTOWIKI","Go to lessons wiki");
define("_WIKI_NOPAGESFOUND","There are no changes in wiki pages");
?>