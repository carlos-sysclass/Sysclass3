<?php
define("_CERTIFICATES_CERTIFICATES","Lektion Certifikater");//Lesson Certificates
define("_CERTIFICATES_CERTIFICATES_MODULE","Lektion Certifikater modul");//Lesson Certificates module
define("_CERTIFICATES_FORMATCERTIFICATEFORLESSON","Format certifikat for lektionen");//Format certificate for lesson
define("_CERTIFICATES_LESSONSTATUS","Lektion status");//Lesson status
define("_CERTIFICATES_CERTIFICATEINSTRUCTIONS","I den skabelon, skal du bruge # organisationen # for organisationens navn, # user_name # for brugerens navn, # user_surname # for brugerens efternavn, # lesson_name # for at lære navn, # grade # for kvalitet og # # dato for dato.");//In the template, use #organization# for organization&#039;s name, #user_name# for user&#039;s name, #user_surname# for user&#039;s surname, #lesson_name# for lesson&#039;s name, #grade# for grade and #date# for date.
define("_CERTIFICATES_NOISSUEDCERTIFICATEEXISTS","Der er ingen der udstedes certifikat");//There is no issued certificate
?>
