<?php
define("_CERTIFICATES_CERTIFICATES","Leksjon Sertifikater");//Lesson Certificates
define("_CERTIFICATES_CERTIFICATES_MODULE","Leksjon Sertifikater modulen");//Lesson Certificates module
define("_CERTIFICATES_FORMATCERTIFICATEFORLESSON","Format sertifikat for leksjonen");//Format certificate for lesson
define("_CERTIFICATES_LESSONSTATUS","Leksjon status");//Lesson status
define("_CERTIFICATES_CERTIFICATEINSTRUCTIONS","I malen, bruker # # organisasjonen for organisasjonens navn, brukernavn # # for brukerens navn, # user_surname # for brukerens etternavn, # lesson_name # for leksjonen navn, # # klasse for klasse og dato # # for dato.");//In the template, use #organization# for organization&#039;s name, #user_name# for user&#039;s name, #user_surname# for user&#039;s surname, #lesson_name# for lesson&#039;s name, #grade# for grade and #date# for date.
define("_CERTIFICATES_NOISSUEDCERTIFICATEEXISTS","Det er ingen utstedt sertifikat");//There is no issued certificate
?>
