<?php
define("_CERTIFICATES_CERTIFICATES","Lekcja Certyfikaty");//Lesson Certificates
define("_CERTIFICATES_CERTIFICATES_MODULE","Lekcja Certyfikaty moduł");//Lesson Certificates module
define("_CERTIFICATES_FORMATCERTIFICATEFORLESSON","Format certyfikatu na lekcji");//Format certificate for lesson
define("_CERTIFICATES_LESSONSTATUS","Lekcja status");//Lesson status
define("_CERTIFICATES_CERTIFICATEINSTRUCTIONS","W szablonie, użyj # # organizacji dla organizacji nazwę, nazwa_użytkownika # # za nazwę użytkownika, user_surname # # dla użytkownika nazwisko, lesson_name # # lekcje nazwisko, # klasy do klasy i # # # data daty.");//In the template, use #organization# for organization&#039;s name, #user_name# for user&#039;s name, #user_surname# for user&#039;s surname, #lesson_name# for lesson&#039;s name, #grade# for grade and #date# for date.
define("_CERTIFICATES_NOISSUEDCERTIFICATEEXISTS","Nie ma certyfikat wydany");//There is no issued certificate
?>
