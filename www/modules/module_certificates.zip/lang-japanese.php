<?php
define("_CERTIFICATES_CERTIFICATES","レッスン証明書");//Lesson Certificates
define("_CERTIFICATES_CERTIFICATES_MODULE","レッスン証明書モジュール");//Lesson Certificates module
define("_CERTIFICATES_FORMATCERTIFICATEFORLESSON","レッスンの形式の証明書");//Format certificate for lesson
define("_CERTIFICATES_LESSONSTATUS","レッスンの状態");//Lesson status
define("_CERTIFICATES_CERTIFICATEINSTRUCTIONS","で、テンプレート、組織の名前＃は、ユーザーの名前＃ユーザー名＃は、ユーザーの姓＃ user_surname ＃ 、 ＃年生の授業の名前＃ lesson_name ＃ 、 ＃日グレード＃との日＃ ＃組織使用しています。");//In the template, use #organization# for organization&#039;s name, #user_name# for user&#039;s name, #user_surname# for user&#039;s surname, #lesson_name# for lesson&#039;s name, #grade# for grade and #date# for date.
define("_CERTIFICATES_NOISSUEDCERTIFICATEEXISTS","がない証明書を発行されている");//There is no issued certificate
?>
