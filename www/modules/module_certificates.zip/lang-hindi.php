<?php
define("_CERTIFICATES_CERTIFICATES","सबक प्रमाण पत्र");//Lesson Certificates
define("_CERTIFICATES_CERTIFICATES_MODULE","सबक प्रमाण पत्र मॉड्यूल");//Lesson Certificates module
define("_CERTIFICATES_FORMATCERTIFICATEFORLESSON","सबक के लिए प्रारूप प्रमाणपत्र");//Format certificate for lesson
define("_CERTIFICATES_LESSONSTATUS","सबक स्थिति");//Lesson status
define("_CERTIFICATES_CERTIFICATEINSTRUCTIONS","टेम्पलेट में, संगठन का नाम #, के लिए उपयोगकर्ता का नाम # USER_NAME #, के लिए उपयोगकर्ता के उपनाम # user_surname #, के लिए # ग्रेड सबक का नाम # lesson_name #, के लिए # तिथि ग्रेड # और के लिए तिथि # # के लिए संगठन का उपयोग करें.");//In the template, use #organization# for organization&#039;s name, #user_name# for user&#039;s name, #user_surname# for user&#039;s surname, #lesson_name# for lesson&#039;s name, #grade# for grade and #date# for date.
define("_CERTIFICATES_NOISSUEDCERTIFICATEEXISTS","कोई प्रमाणपत्र जारी है");//There is no issued certificate
?>
