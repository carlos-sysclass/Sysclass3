<?php
define("_CERTIFICATES_CERTIFICATES","Урок Сертификати");//Lesson Certificates
define("_CERTIFICATES_CERTIFICATES_MODULE","Урок Сертификати модул");//Lesson Certificates module
define("_CERTIFICATES_FORMATCERTIFICATEFORLESSON","Формат на сертификат за урок");//Format certificate for lesson
define("_CERTIFICATES_LESSONSTATUS","Урок статус");//Lesson status
define("_CERTIFICATES_CERTIFICATEINSTRUCTIONS","В шаблона, използвайте # # организация за организиране на името, USER_NAME # # за потребителско име, user_surname # # за потребителя, презиме, lesson_name # # за урок име # # клас за клас и дата # # за дата.");//In the template, use #organization# for organization&#039;s name, #user_name# for user&#039;s name, #user_surname# for user&#039;s surname, #lesson_name# for lesson&#039;s name, #grade# for grade and #date# for date.
define("_CERTIFICATES_NOISSUEDCERTIFICATEEXISTS","Не е издаден сертификат");//There is no issued certificate
?>
