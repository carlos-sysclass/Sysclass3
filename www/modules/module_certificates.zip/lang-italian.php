<?php
define("_CERTIFICATES_CERTIFICATES","Lezione Certificati");//Lesson Certificates
define("_CERTIFICATES_CERTIFICATES_MODULE","Lezione Certificati modulo");//Lesson Certificates module
define("_CERTIFICATES_FORMATCERTIFICATEFORLESSON","Formato certificato di lezione");//Format certificate for lesson
define("_CERTIFICATES_LESSONSTATUS","Lezione di stato");//Lesson status
define("_CERTIFICATES_CERTIFICATEINSTRUCTIONS","Nel modello, utilizzare # # organizzazione per l&#39;organizzazione del nome, nome_utente # # per il nome utente, # # user_surname per l&#39;utente del cognome, lesson_name # # lezione per il nome, # # grado per grado e # # data per data.");//In the template, use #organization# for organization&#039;s name, #user_name# for user&#039;s name, #user_surname# for user&#039;s surname, #lesson_name# for lesson&#039;s name, #grade# for grade and #date# for date.
define("_CERTIFICATES_NOISSUEDCERTIFICATEEXISTS","Non vi è alcun certificato rilasciato");//There is no issued certificate
?>
