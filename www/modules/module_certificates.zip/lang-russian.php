<?php
define("_CERTIFICATES_CERTIFICATES","Урок Сертификаты");//Lesson Certificates
define("_CERTIFICATES_CERTIFICATES_MODULE","Урок Сертификаты модуль");//Lesson Certificates module
define("_CERTIFICATES_FORMATCERTIFICATEFORLESSON","Форма сертификата на урок");//Format certificate for lesson
define("_CERTIFICATES_LESSONSTATUS","Урок статус");//Lesson status
define("_CERTIFICATES_CERTIFICATEINSTRUCTIONS","В шаблон, используйте # # организация для названия организации, # # имя_пользователя на имя пользователя, # # user_surname для пользователя фамилию, # # lesson_name за урок, имя, класс # # по классам и дат # # на сегодняшний день.");//In the template, use #organization# for organization&#039;s name, #user_name# for user&#039;s name, #user_surname# for user&#039;s surname, #lesson_name# for lesson&#039;s name, #grade# for grade and #date# for date.
define("_CERTIFICATES_NOISSUEDCERTIFICATEEXISTS","Существует не издал сертификат");//There is no issued certificate
?>
