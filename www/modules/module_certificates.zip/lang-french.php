<?php
define("_CERTIFICATES_CERTIFICATES","Certificats de leçon");//Lesson Certificates
define("_CERTIFICATES_CERTIFICATES_MODULE","Certificats module leçon");//Lesson Certificates module
define("_CERTIFICATES_FORMATCERTIFICATEFORLESSON","Format de certificat pour les cours");//Format certificate for lesson
define("_CERTIFICATES_LESSONSTATUS","Leçon statut");//Lesson status
define("_CERTIFICATES_CERTIFICATEINSTRUCTIONS","Dans le modèle, utilisez # # organisme de nom de l&#39;organization, # # pour nom_utilisateur nom d&#39;utilisateur, user_surname # # pour l&#39;utilisateur le nom de famille, # # lesson_name leçon pour le nom, grade # # pour le grade et la date # # pour la date.");//In the template, use #organization# for organization&#039;s name, #user_name# for user&#039;s name, #user_surname# for user&#039;s surname, #lesson_name# for lesson&#039;s name, #grade# for grade and #date# for date.
define("_CERTIFICATES_NOISSUEDCERTIFICATEEXISTS","Il n&#39;y a pas de certificat délivré");//There is no issued certificate
?>
