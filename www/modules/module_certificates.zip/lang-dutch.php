<?php
define("_CERTIFICATES_CERTIFICATES","Lesson Certificaten");//Lesson Certificates
define("_CERTIFICATES_CERTIFICATES_MODULE","Lesson module Certificaten");//Lesson Certificates module
define("_CERTIFICATES_FORMATCERTIFICATEFORLESSON","Formaat certificaat voor les");//Format certificate for lesson
define("_CERTIFICATES_LESSONSTATUS","Lesson status");//Lesson status
define("_CERTIFICATES_CERTIFICATEINSTRUCTIONS","In de sjabloon gebruiken organisatie # # voor organisatie&#39;s naam, # # gebruikersnaam voor de naam van de gebruiker, # # user_surname voor de gebruiker zijn naam, # # lesson_name les voor de naam, # # rang voor rang en # # datum voor de datum.");//In the template, use #organization# for organization&#039;s name, #user_name# for user&#039;s name, #user_surname# for user&#039;s surname, #lesson_name# for lesson&#039;s name, #grade# for grade and #date# for date.
define("_CERTIFICATES_NOISSUEDCERTIFICATEEXISTS","Er is geen certificaat afgegeven");//There is no issued certificate
?>
