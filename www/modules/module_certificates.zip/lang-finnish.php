<?php
define("_CERTIFICATES_CERTIFICATES","Oppitunnin Sertifikaatit");//Lesson Certificates
define("_CERTIFICATES_CERTIFICATES_MODULE","Oppitunnin Todistukset moduuli");//Lesson Certificates module
define("_CERTIFICATES_FORMATCERTIFICATEFORLESSON","Formaatti todistus oppitunti");//Format certificate for lesson
define("_CERTIFICATES_LESSONSTATUS","Oppitunnin asema");//Lesson status
define("_CERTIFICATES_CERTIFICATEINSTRUCTIONS","Tässä mallissa, käytä # järjestö # Organisaation nimi, # user_name # käyttäjän nimeä, # user_surname # käyttäjälle sukunimi, # lesson_name # for opetus nimi, # luokka #-luokan ja # date # päivämäärän.");//In the template, use #organization# for organization&#039;s name, #user_name# for user&#039;s name, #user_surname# for user&#039;s surname, #lesson_name# for lesson&#039;s name, #grade# for grade and #date# for date.
define("_CERTIFICATES_NOISSUEDCERTIFICATEEXISTS","Ei ole mitään todistusta");//There is no issued certificate
?>
