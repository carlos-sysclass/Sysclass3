<?php
define("_CERTIFICATES_CERTIFICATES","درس شهادات");//Lesson Certificates
define("_CERTIFICATES_CERTIFICATES_MODULE","درس شهادات وحدة");//Lesson Certificates module
define("_CERTIFICATES_FORMATCERTIFICATEFORLESSON","شكل شهادة للدرس");//Format certificate for lesson
define("_CERTIFICATES_LESSONSTATUS","درس الوضع");//Lesson status
define("_CERTIFICATES_CERTIFICATEINSTRUCTIONS","في القالب ، وتنظيم استخدام # # لاسم المنظمة ، USER_NAME # # عن اسم المستخدم ، user_surname # # للمستخدم لقب ، lesson_name # # لدرس اسم الصف # # لوالرتبة وتاريخ # # للتاريخ.");//In the template, use #organization# for organization&#039;s name, #user_name# for user&#039;s name, #user_surname# for user&#039;s surname, #lesson_name# for lesson&#039;s name, #grade# for grade and #date# for date.
define("_CERTIFICATES_NOISSUEDCERTIFICATEEXISTS","لا يوجد أصدرت شهادة");//There is no issued certificate
?>
