<?php
define("_CERTIFICATES_CERTIFICATES","Lekce Certifikáty");//Lesson Certificates
define("_CERTIFICATES_CERTIFICATES_MODULE","Lekce Certifikáty modul");//Lesson Certificates module
define("_CERTIFICATES_FORMATCERTIFICATEFORLESSON","Formát osvědčení pro lekci");//Format certificate for lesson
define("_CERTIFICATES_LESSONSTATUS","Lekce status");//Lesson status
define("_CERTIFICATES_CERTIFICATEINSTRUCTIONS","V šablonu, použijte: # # organizace pro organizace, jméno, # # uzivatel pro uživatelské jméno, # # user_surname pro uživatele, příjmení, # # lesson_name za lekci jméno, # # třídy pro platovou třídu a datum # # data.");//In the template, use #organization# for organization&#039;s name, #user_name# for user&#039;s name, #user_surname# for user&#039;s surname, #lesson_name# for lesson&#039;s name, #grade# for grade and #date# for date.
define("_CERTIFICATES_NOISSUEDCERTIFICATEEXISTS","Neexistuje žádný vydaného certifikátu");//There is no issued certificate
?>
