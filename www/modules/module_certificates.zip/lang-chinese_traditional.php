<?php
define("_CERTIFICATES_CERTIFICATES","課程證書");//Lesson Certificates
define("_CERTIFICATES_CERTIFICATES_MODULE","證書課程模塊");//Lesson Certificates module
define("_CERTIFICATES_FORMATCERTIFICATEFORLESSON","格式證書課程");//Format certificate for lesson
define("_CERTIFICATES_LESSONSTATUS","課程地位");//Lesson status
define("_CERTIFICATES_CERTIFICATEINSTRUCTIONS","在模板，使用＃ ＃組織組織的名稱，用戶名＃ ＃的用戶的名稱， ＃ ＃ user_surname用戶的姓， ＃ ＃ lesson_name的經驗教訓的姓名，年級＃ ＃級和＃ ＃日期為日期。");//In the template, use #organization# for organization&#039;s name, #user_name# for user&#039;s name, #user_surname# for user&#039;s surname, #lesson_name# for lesson&#039;s name, #grade# for grade and #date# for date.
define("_CERTIFICATES_NOISSUEDCERTIFICATEEXISTS","不存在簽發的證書");//There is no issued certificate
?>
