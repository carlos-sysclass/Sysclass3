<?php
define("_CERTIFICATES_CERTIFICATES","Certificados da lição");//Lesson Certificates
define("_CERTIFICATES_CERTIFICATES_MODULE","Módulo dos certificados da lição ");//Lesson Certificates module
define("_CERTIFICATES_FORMATCERTIFICATEFORLESSON","Formatar certidão da lição");//Format certificate for lesson
define("_CERTIFICATES_LESSONSTATUS","Estado da lição");//Lesson status
define("_CERTIFICATES_CERTIFICATEINSTRUCTIONS","No modelo, use #organisation# para organização, #user_name# para nome do usuário, #user_surname# para  sobrenome do usuário, #lesson_name# para o nome da lição , #grade# para o grau da avaliazação #data# para a data.");//In the template, use #organization# for organization&#039;s name, #user_name# for user&#039;s name, #user_surname# for user&#039;s surname, #lesson_name# for lesson&#039;s name, #grade# for grade and #date# for date.
define("_CERTIFICATES_NOISSUEDCERTIFICATEEXISTS","Não existe um certificado emitido");//There is no issued certificate
?>
