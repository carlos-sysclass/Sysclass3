<?php
define("_CERTIFICATES_CERTIFICATES","Lección Certificados");//Lesson Certificates
define("_CERTIFICATES_CERTIFICATES_MODULE","Lección Certificados módulo");//Lesson Certificates module
define("_CERTIFICATES_FORMATCERTIFICATEFORLESSON","Formato de certificado de lección");//Format certificate for lesson
define("_CERTIFICATES_LESSONSTATUS","Lección estado");//Lesson status
define("_CERTIFICATES_CERTIFICATEINSTRUCTIONS","En la plantilla, use # # organización para la organización el nombre, # # de usuario nombre del usuario, # # user_surname para el usuario del apellido, # # lesson_name lección para el nombre, grado # # para el grado y la fecha # # de fecha.");//In the template, use #organization# for organization&#039;s name, #user_name# for user&#039;s name, #user_surname# for user&#039;s surname, #lesson_name# for lesson&#039;s name, #grade# for grade and #date# for date.
define("_CERTIFICATES_NOISSUEDCERTIFICATEEXISTS","No hay ningún certificado expedido");//There is no issued certificate
?>
