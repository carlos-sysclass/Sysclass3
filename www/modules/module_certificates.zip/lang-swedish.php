<?php
define("_CERTIFICATES_CERTIFICATES","Lektion Certifikat");//Lesson Certificates
define("_CERTIFICATES_CERTIFICATES_MODULE","Lektion Certifikat modul");//Lesson Certificates module
define("_CERTIFICATES_FORMATCERTIFICATEFORLESSON","Format intyg för lektionen");//Format certificate for lesson
define("_CERTIFICATES_LESSONSTATUS","Lektion status");//Lesson status
define("_CERTIFICATES_CERTIFICATEINSTRUCTIONS","I mallen, använd # # organisationen för organisationens namn, användarnamn # # för användarens namn, # user_surname # för användaren efternamn, # lesson_name # för lektion namn, # # klass för klass och datum # # för dagen.");//In the template, use #organization# for organization&#039;s name, #user_name# for user&#039;s name, #user_surname# for user&#039;s surname, #lesson_name# for lesson&#039;s name, #grade# for grade and #date# for date.
define("_CERTIFICATES_NOISSUEDCERTIFICATEEXISTS","Det finns ingen utfärdat intyg");//There is no issued certificate
?>
