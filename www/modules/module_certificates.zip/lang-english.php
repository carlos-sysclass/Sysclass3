<?php
define("_CERTIFICATES_CERTIFICATES","Lesson Certificates");
define("_CERTIFICATES_CERTIFICATES_MODULE", "Lesson Certificates module");
define("_CERTIFICATES_FORMATCERTIFICATEFORLESSON","Format certificate for lesson");
define("_CERTIFICATES_LESSONSTATUS", "Lesson status");
define("_CERTIFICATES_CERTIFICATEINSTRUCTIONS", "In the template, use #organization# for organization&#039;s name, #user_name# for user&#039;s name, #user_surname# for user&#039;s surname, #lesson_name# for lesson&#039;s name, #grade# for grade and #date# for date.");
define("_CERTIFICATES_NOISSUEDCERTIFICATEEXISTS", "There is no issued certificate");
?>