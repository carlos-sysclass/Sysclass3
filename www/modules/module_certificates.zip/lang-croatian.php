<?php
define("_CERTIFICATES_CERTIFICATES","Obrazovni Certifikati");//Lesson Certificates
define("_CERTIFICATES_CERTIFICATES_MODULE","Obrazovni Certifikati modul");//Lesson Certificates module
define("_CERTIFICATES_FORMATCERTIFICATEFORLESSON","Format certifikata za sat");//Format certificate for lesson
define("_CERTIFICATES_LESSONSTATUS","Obrazovni status");//Lesson status
define("_CERTIFICATES_CERTIFICATEINSTRUCTIONS","U predložak, koristiti # # organizacija za organizaciju ime, korisničko_ime # # za korisničkog imena, # # user_surname za korisnika prezime, # # lesson_name za sat ime, razred # # za ocjenu i datum # # za datum.");//In the template, use #organization# for organization&#039;s name, #user_name# for user&#039;s name, #user_surname# for user&#039;s surname, #lesson_name# for lesson&#039;s name, #grade# for grade and #date# for date.
define("_CERTIFICATES_NOISSUEDCERTIFICATEEXISTS","Nema potvrde izdane");//There is no issued certificate
?>
