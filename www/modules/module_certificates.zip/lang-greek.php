<?php
define("_CERTIFICATES_CERTIFICATES", "Πιστοποιητικά Μαθημάτων");
define("_CERTIFICATES_CERTIFICATES_MODULE", "'Αρθρωμα Πιστοποιητικά Μαθημάτων");
define("_CERTIFICATES_FORMATCERTIFICATEFORLESSON","Διαμόρφωση πιστοποιητικού για το μάθημα");
define("_CERTIFICATES_LESSONSTATUS", "Κατάσταση μαθήματος");
define("_CERTIFICATES_CERTIFICATEINSTRUCTIONS", "Στο πρότυπο, χρησιμοποιήσετε #organization# για το όνομα του οργανισμού, #user_name# για το όνομα του μαθητή, #user_surname# για το επώνυμο του μαθητή, #lesson_name# για το όνομα του μαθήματος, #grade# για το βαθμό και #date# για την ημερομηνία.");
define("_CERTIFICATES_NOISSUEDCERTIFICATEEXISTS", "Δεν έχει εκδοθεί πιστοποιητικό");
?>