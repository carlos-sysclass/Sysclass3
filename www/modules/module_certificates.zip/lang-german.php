<?php
define("_CERTIFICATES_CERTIFICATES","Lektions-Zertifikate");//Lesson Certificates
define("_CERTIFICATES_CERTIFICATES_MODULE","Lektions-Zertifikate-Modul");//Lesson Certificates module
define("_CERTIFICATES_FORMATCERTIFICATEFORLESSON","Formatiere Zertifikat für Lektion");//Format certificate for lesson
define("_CERTIFICATES_LESSONSTATUS","Lektios-Status");//Lesson status
define("_CERTIFICATES_CERTIFICATEINSTRUCTIONS","In der Vorlage, verwenden Sie #organization# für Organization, #user_name#  für Benutzer-Vorname, #user_surname# für Benutzer-Name, #lesson_name# für den Lektions-Namen, #grade# für die Benotung und #date# für Datum.");//In the template, use #organization# for organization&#039;s name, #user_name# for user&#039;s name, #user_surname# for user&#039;s surname, #lesson_name# for lesson&#039;s name, #grade# for grade and #date# for date.
define("_CERTIFICATES_NOISSUEDCERTIFICATEEXISTS","Es gibt keine ausgestellte Bescheinigung");//There is no issued certificate
?>
