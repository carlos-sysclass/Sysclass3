<?php
define("_CERTIFICATES_CERTIFICATES","课程证书");//Lesson Certificates
define("_CERTIFICATES_CERTIFICATES_MODULE","证书课程模块");//Lesson Certificates module
define("_CERTIFICATES_FORMATCERTIFICATEFORLESSON","格式证书课程");//Format certificate for lesson
define("_CERTIFICATES_LESSONSTATUS","课程地位");//Lesson status
define("_CERTIFICATES_CERTIFICATEINSTRUCTIONS","在模板，使用＃ ＃组织组织的名称，用户名＃ ＃的用户的名称， ＃ ＃ user_surname用户的姓， ＃ ＃ lesson_name的经验教训的姓名，年级＃ ＃级和＃ ＃日期为日期。");//In the template, use #organization# for organization&#039;s name, #user_name# for user&#039;s name, #user_surname# for user&#039;s surname, #lesson_name# for lesson&#039;s name, #grade# for grade and #date# for date.
define("_CERTIFICATES_NOISSUEDCERTIFICATEEXISTS","没有签发证书");//There is no issued certificate
?>
