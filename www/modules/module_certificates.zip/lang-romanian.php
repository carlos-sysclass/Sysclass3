<?php
define("_CERTIFICATES_CERTIFICATES","Lectia de Certificate");//Lesson Certificates
define("_CERTIFICATES_CERTIFICATES_MODULE","Lectia de Certificate de module");//Lesson Certificates module
define("_CERTIFICATES_FORMATCERTIFICATEFORLESSON","Format de certificat pentru lecţie");//Format certificate for lesson
define("_CERTIFICATES_LESSONSTATUS","Lectia de stare");//Lesson status
define("_CERTIFICATES_CERTIFICATEINSTRUCTIONS","În şablonul, folosiţi # # pentru organizarea numele organizatiei, USER_NAME # # pentru nume de utilizator, user_surname # # pentru numele de utilizator, lesson_name # # pentru lecţie numele, gradul # # pentru clasa şi data # # pentru data.");//In the template, use #organization# for organization&#039;s name, #user_name# for user&#039;s name, #user_surname# for user&#039;s surname, #lesson_name# for lesson&#039;s name, #grade# for grade and #date# for date.
define("_CERTIFICATES_NOISSUEDCERTIFICATEEXISTS","Nu există nici un certificat eliberat");//There is no issued certificate
?>
