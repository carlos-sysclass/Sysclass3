<?php

/* This file defines the constants for the module in English */
define("_LESSON_SIDEBAR","Lesson Sidebar");
define("_MYLESSONSMENU","Lessons menu");
?>