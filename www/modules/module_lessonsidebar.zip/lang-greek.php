<?php
/* This file defines the constants for the module in Greek */
define("_LESSON_SIDEBAR", "Προβολή μαθημάτων");
define("_MYLESSONSMENU","Διαθέσιμα μαθήματα");
?>