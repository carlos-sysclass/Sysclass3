<?php
define("_BANNERS_BANNERS","Ad Banners");//Ad Banners
define("_BANNERS_MODULE","Modulul de reclame bannere");//Ad Banners Module
define("_BANNERS_MAIN","Pagina principală");//Main page
define("_BANNERS_MANAGEMENT","Gestionare bannere");//Manage banners
define("_BANNERS_ADDBANNER","Adauga Banner");//Add Banner
define("_BANNERS_IMAGE","Imagine");//Image
define("_BANNERS_LINK","Link");//Link
define("_BANNERS_BANNER","Banner");//Banner
define("_BANNERS_INSERTBANNER","Adauga Banner");//Add Banner
define("_BANNERS_NOBANNERFOUND","Nu au fost găsite bannere");//No banners were found
define("_BANNERS_BANNERSPAGE","Bannere");//Banners
define("_BANNERS_SUCCESFULLYINSERTEDBANNERENTRY","Banner-ului a fost introdusa cu succes");//The banner was inserted succesfully
define("_BANNERS_PROBLEMINSERTINGBANNERENTRY","O problemă a apărut în timp ce introducerea banner-ului");//A problem occured while inserting the banner
define("_BANNERS_SUCCESFULLYUPDATEDBANNERENTRY","Banner-ului a fost actualizat cu succes");//The banner was updated succesfully
define("_BANNERS_PROBLEMUPDATINGBANNERENTRY","O problemă a apărut în timp ce actualizarea banner-ului");//A problem occured while updating the banner
define("_BANNERS_SUCCESFULLYDELETEDBANNER","Banner-ului a fost şters cu succes");//The banner was deleted succesfully
define("_BANNERS_DELETEBANNER","Ştergere banner");//Delete banner
define("_BANNERS_EDITBANNER","Editare banner");//Edit banner
define("_BANNERS_GOTOBANNERPAGE","Du-te la pagina de anunţuri Bannere");//Go to Ad Banners page
define("_BANNERS_ORSELECTONEFROMLIST","Sau selectaţi unul din lista");//Or select one from list
?>
