<?php
define("_BANNERS_BANNERS","Ad Banner");//Ad Banners
define("_BANNERS_MODULE","Ad Banner-Modul");//Ad Banners Module
define("_BANNERS_MAIN","Startseite");//Main page
define("_BANNERS_MANAGEMENT","Banner verwalten");//Manage banners
define("_BANNERS_ADDBANNER","Banner hinzufügen");//Add Banner
define("_BANNERS_IMAGE","Bild");//Image
define("_BANNERS_LINK","Link");//Link
define("_BANNERS_BANNER","Banner");//Banner
define("_BANNERS_INSERTBANNER","Banner hinzufügen");//Add Banner
define("_BANNERS_NOBANNERFOUND","Keine Banner gefunden");//No banners were found
define("_BANNERS_BANNERSPAGE","Banner");//Banners
define("_BANNERS_SUCCESFULLYINSERTEDBANNERENTRY","Das Banner wurde erfolgreich eingefügt");//The banner was inserted succesfully
define("_BANNERS_PROBLEMINSERTINGBANNERENTRY","Beim Einfügen des Banners ist ein Problem aufgetreten");//A problem occured while inserting the banner
define("_BANNERS_SUCCESFULLYUPDATEDBANNERENTRY","Das Banner wurde erfolgreich aktualisiert");//The banner was updated succesfully
define("_BANNERS_PROBLEMUPDATINGBANNERENTRY","Während der Aktualisierung des Banners ist ein Problem aufgetreten");//A problem occured while updating the banner
define("_BANNERS_SUCCESFULLYDELETEDBANNER","Das Banner wurde erfolgreich gelöscht");//The banner was deleted succesfully
define("_BANNERS_DELETEBANNER","Banner löschen");//Delete banner
define("_BANNERS_EDITBANNER","Banner bearbeiten");//Edit banner
define("_BANNERS_GOTOBANNERPAGE","Gehe zur Banner Ad-Seite");//Go to Ad Banners page
define("_BANNERS_ORSELECTONEFROMLIST","oder wählen Sie eines aus der Liste");//Or select one from list
?>