<?php
define("_BANNERS_BANNERS","Ad Banners");
define("_BANNERS_MODULE", "Ad Banners Module");
define("_BANNERS_MAIN", "Main page");
define("_BANNERS_MANAGEMENT","Manage banners");
define("_BANNERS_ADDBANNER", "Add Banner");
define("_BANNERS_IMAGE", "Image");
define("_BANNERS_LINK", "Link");
define("_BANNERS_BANNER", "Banner");
define("_BANNERS_INSERTBANNER", "Add Banner");
define("_BANNERS_NOBANNERFOUND", "No banners were found");
define("_BANNERS_BANNERSPAGE", "Banners");
define("_BANNERS_SUCCESFULLYINSERTEDBANNERENTRY", "The banner was inserted succesfully");
define("_BANNERS_PROBLEMINSERTINGBANNERENTRY", "A problem occured while inserting the banner");
define("_BANNERS_SUCCESFULLYUPDATEDBANNERENTRY", "The banner was updated succesfully");
define("_BANNERS_PROBLEMUPDATINGBANNERENTRY", "A problem occured while updating the banner");
define("_BANNERS_SUCCESFULLYDELETEDBANNER", "The banner was deleted succesfully");
define("_BANNERS_DELETEBANNER", "Delete banner");
define("_BANNERS_EDITBANNER", "Edit banner");
define("_BANNERS_GOTOBANNERSPAGE", "Go to Ad Banners page");
define("_BANNERS_ORSELECTONEFROMLIST", "Or select one from list");
?>