﻿<?php
define("_BANNERS_BANNERS","Bannières de pub");//Ad Banners
define("_BANNERS_MODULE","Module bannières de pub");//Ad Banners Module
define("_BANNERS_MAIN","Page principale");//Main page
define("_BANNERS_MANAGEMENT","Gérer les bannières");//Manage banners
define("_BANNERS_ADDBANNER","Ajouter Banner");//Add Banner
define("_BANNERS_IMAGE","Image");//Image
define("_BANNERS_LINK","Lien");//Link
define("_BANNERS_BANNER","Bannière");//Banner
define("_BANNERS_INSERTBANNER","Ajouter Banner");//Add Banner
define("_BANNERS_NOBANNERFOUND","Pas de bannières ont été trouvés");//No banners were found
define("_BANNERS_BANNERSPAGE","Bannières");//Banners
define("_BANNERS_SUCCESFULLYINSERTEDBANNERENTRY","La bannière a été inséré avec succès");//The banner was inserted succesfully
define("_BANNERS_PROBLEMINSERTINGBANNERENTRY","Un problème est survenu alors que l&#39;insertion de la bannière");//A problem occured while inserting the banner
define("_BANNERS_SUCCESFULLYUPDATEDBANNERENTRY","La bannière a été mise à jour avec succès");//The banner was updated succesfully
define("_BANNERS_PROBLEMUPDATINGBANNERENTRY","Un problème est survenu alors que la mise à jour de la bannière");//A problem occured while updating the banner
define("_BANNERS_SUCCESFULLYDELETEDBANNER","La bannière a été supprimé avec succès");//The banner was deleted succesfully
define("_BANNERS_DELETEBANNER","Supprimer bannière");//Delete banner
define("_BANNERS_EDITBANNER","Modifier la bannière");//Edit banner
define("_BANNERS_GOTOBANNERPAGE","Aller à la page bannières de pub");//Go to Ad Banners page
define("_BANNERS_ORSELECTONEFROMLIST","Ou sélectionnez l&#39;une de la liste");//Or select one from list
?>
