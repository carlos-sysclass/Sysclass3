<?php
define("_BANNERS_BANNERS","Ad Banners");//Ad Banners
define("_BANNERS_MODULE","Ad banners module");//Ad Banners Module
define("_BANNERS_MAIN","Hoofd pagina");//Main page
define("_BANNERS_MANAGEMENT","Manage banners");//Manage banners
define("_BANNERS_ADDBANNER","Toevoegen Banner");//Add Banner
define("_BANNERS_IMAGE","Afbeelding");//Image
define("_BANNERS_LINK","Koppelen");//Link
define("_BANNERS_BANNER","Banner");//Banner
define("_BANNERS_INSERTBANNER","Toevoegen Banner");//Add Banner
define("_BANNERS_NOBANNERFOUND","Geen banners werden gevonden");//No banners were found
define("_BANNERS_BANNERSPAGE","Banners");//Banners
define("_BANNERS_SUCCESFULLYINSERTEDBANNERENTRY","De banner is ingevoegd met succes");//The banner was inserted succesfully
define("_BANNERS_PROBLEMINSERTINGBANNERENTRY","Een probleem opgetreden tijdens het plaatsen van de banner");//A problem occured while inserting the banner
define("_BANNERS_SUCCESFULLYUPDATEDBANNERENTRY","De banner is bijgewerkt met succes");//The banner was updated succesfully
define("_BANNERS_PROBLEMUPDATINGBANNERENTRY","Een probleem opgetreden tijdens het bijwerken van de banner");//A problem occured while updating the banner
define("_BANNERS_SUCCESFULLYDELETEDBANNER","De banner werd succesvol verwijderd");//The banner was deleted succesfully
define("_BANNERS_DELETEBANNER","Verwijderen banner");//Delete banner
define("_BANNERS_EDITBANNER","Edit banner");//Edit banner
define("_BANNERS_GOTOBANNERPAGE","Ga naar pagina Ad Banners");//Go to Ad Banners page
define("_BANNERS_ORSELECTONEFROMLIST","Of kies uit een lijst");//Or select one from list
?>
