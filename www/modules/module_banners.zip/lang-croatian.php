<?php
define("_BANNERS_BANNERS","Oglasni Banneri");//Ad Banners
define("_BANNERS_MODULE","Oglasni Banneri modul");//Ad Banners Module
define("_BANNERS_MAIN","Glavna stranica");//Main page
define("_BANNERS_MANAGEMENT","Upravljanje banneri");//Manage banners
define("_BANNERS_ADDBANNER","Dodaj Banner");//Add Banner
define("_BANNERS_IMAGE","Slike");//Image
define("_BANNERS_LINK","Veza");//Link
define("_BANNERS_BANNER","Baner");//Banner
define("_BANNERS_INSERTBANNER","Dodaj Banner");//Add Banner
define("_BANNERS_NOBANNERFOUND","Nema bannera, pronađena su");//No banners were found
define("_BANNERS_BANNERSPAGE","Banneri");//Banners
define("_BANNERS_SUCCESFULLYINSERTEDBANNERENTRY","U banner je stavljen uspješno");//The banner was inserted succesfully
define("_BANNERS_PROBLEMINSERTINGBANNERENTRY","Problem se dogodila dok umetanje bannera");//A problem occured while inserting the banner
define("_BANNERS_SUCCESFULLYUPDATEDBANNERENTRY","Bannera uspješno je ažuriran");//The banner was updated succesfully
define("_BANNERS_PROBLEMUPDATINGBANNERENTRY","Problem se dogodila dok ažuriranju banner");//A problem occured while updating the banner
define("_BANNERS_SUCCESFULLYDELETEDBANNER","Bannera je uspješno obrisan");//The banner was deleted succesfully
define("_BANNERS_DELETEBANNER","Obriši banner");//Delete banner
define("_BANNERS_EDITBANNER","Uredi banner");//Edit banner
define("_BANNERS_GOTOBANNERPAGE","Idi na stranicu Oglasni Banneri");//Go to Ad Banners page
define("_BANNERS_ORSELECTONEFROMLIST","Ili odaberite iz popisa");//Or select one from list
?>
