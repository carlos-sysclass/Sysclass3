<?php
define("_BANNERS_BANNERS","Ad Banery");//Ad Banners
define("_BANNERS_MODULE","Reklama banery moduł");//Ad Banners Module
define("_BANNERS_MAIN","Strona główna");//Main page
define("_BANNERS_MANAGEMENT","Zarządzanie banery");//Manage banners
define("_BANNERS_ADDBANNER","Dodaj Baner");//Add Banner
define("_BANNERS_IMAGE","Image");//Image
define("_BANNERS_LINK","Łącze");//Link
define("_BANNERS_BANNER","Banner");//Banner
define("_BANNERS_INSERTBANNER","Dodaj Baner");//Add Banner
define("_BANNERS_NOBANNERFOUND","Nie znaleziono banery");//No banners were found
define("_BANNERS_BANNERSPAGE","Banery");//Banners
define("_BANNERS_SUCCESFULLYINSERTEDBANNERENTRY","Baner został dodany pomyślnie");//The banner was inserted succesfully
define("_BANNERS_PROBLEMINSERTINGBANNERENTRY","Wystąpił problem podczas wkładania baner");//A problem occured while inserting the banner
define("_BANNERS_SUCCESFULLYUPDATEDBANNERENTRY","Baner został zaktualizowany");//The banner was updated succesfully
define("_BANNERS_PROBLEMUPDATINGBANNERENTRY","Wystąpił problem podczas aktualizacji baner");//A problem occured while updating the banner
define("_BANNERS_SUCCESFULLYDELETEDBANNER","Baner został usunięty z powodzeniem");//The banner was deleted succesfully
define("_BANNERS_DELETEBANNER","Usuń transparentu");//Delete banner
define("_BANNERS_EDITBANNER","Edycja banner");//Edit banner
define("_BANNERS_GOTOBANNERPAGE","Przejdź do reklam Banery strona");//Go to Ad Banners page
define("_BANNERS_ORSELECTONEFROMLIST","Lub wybierz jedną z listy");//Or select one from list
?>
