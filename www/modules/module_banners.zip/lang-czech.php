<?php
define("_BANNERS_BANNERS","Reklamní bannery");//Ad Banners
define("_BANNERS_MODULE","Reklamní bannery modul");//Ad Banners Module
define("_BANNERS_MAIN","Hlavní stránka");//Main page
define("_BANNERS_MANAGEMENT","Správa bannerů");//Manage banners
define("_BANNERS_ADDBANNER","Přidat Banner");//Add Banner
define("_BANNERS_IMAGE","Image");//Image
define("_BANNERS_LINK","Odkaz");//Link
define("_BANNERS_BANNER","Banner");//Banner
define("_BANNERS_INSERTBANNER","Přidat Banner");//Add Banner
define("_BANNERS_NOBANNERFOUND","Nebyly nalezeny žádné bannery");//No banners were found
define("_BANNERS_BANNERSPAGE","Bannery");//Banners
define("_BANNERS_SUCCESFULLYINSERTEDBANNERENTRY","Banner byl vložen úspěšně");//The banner was inserted succesfully
define("_BANNERS_PROBLEMINSERTINGBANNERENTRY","A problém nastal, zatímco vkládání banneru");//A problem occured while inserting the banner
define("_BANNERS_SUCCESFULLYUPDATEDBANNERENTRY","Banner byl úspěšně aktualizován");//The banner was updated succesfully
define("_BANNERS_PROBLEMUPDATINGBANNERENTRY","A problém nastal, zatímco aktualizace banner");//A problem occured while updating the banner
define("_BANNERS_SUCCESFULLYDELETEDBANNER","Banner byl úspěšně smazán");//The banner was deleted succesfully
define("_BANNERS_DELETEBANNER","Smazat banner");//Delete banner
define("_BANNERS_EDITBANNER","Upravit banner");//Edit banner
define("_BANNERS_GOTOBANNERPAGE","Přejít na reklamní bannery stránku");//Go to Ad Banners page
define("_BANNERS_ORSELECTONEFROMLIST","Nebo vybrat jeden ze seznamu");//Or select one from list
?>
