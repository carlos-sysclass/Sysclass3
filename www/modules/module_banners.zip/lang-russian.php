<?php
define("_BANNERS_BANNERS","Баннеры");//Ad Banners
define("_BANNERS_MODULE","Рекламные щиты модуль");//Ad Banners Module
define("_BANNERS_MAIN","Главная страница");//Main page
define("_BANNERS_MANAGEMENT","Управление баннеры");//Manage banners
define("_BANNERS_ADDBANNER","Добавить Баннер");//Add Banner
define("_BANNERS_IMAGE","Image");//Image
define("_BANNERS_LINK","Ссылка");//Link
define("_BANNERS_BANNER","Баннер");//Banner
define("_BANNERS_INSERTBANNER","Добавить Баннер");//Add Banner
define("_BANNERS_NOBANNERFOUND","Нет баннеров были обнаружены");//No banners were found
define("_BANNERS_BANNERSPAGE","Баннеры");//Banners
define("_BANNERS_SUCCESFULLYINSERTEDBANNERENTRY","Баннер был добавлен успешно");//The banner was inserted succesfully
define("_BANNERS_PROBLEMINSERTINGBANNERENTRY","Проблема произошла в то время как вставить баннер");//A problem occured while inserting the banner
define("_BANNERS_SUCCESFULLYUPDATEDBANNERENTRY","Баннер был успешно обновлен");//The banner was updated succesfully
define("_BANNERS_PROBLEMUPDATINGBANNERENTRY","Проблема возникла при обновлении баннер");//A problem occured while updating the banner
define("_BANNERS_SUCCESFULLYDELETEDBANNER","Баннер был успешно удален");//The banner was deleted succesfully
define("_BANNERS_DELETEBANNER","Удалить баннер");//Delete banner
define("_BANNERS_EDITBANNER","Изменить баннер");//Edit banner
define("_BANNERS_GOTOBANNERPAGE","Перейти на страницу объявлений Баннеры");//Go to Ad Banners page
define("_BANNERS_ORSELECTONEFROMLIST","Или выберите его из списка");//Or select one from list
?>
