<?php
define("_BANNERS_BANNERS","I banner pubblicitari");//Ad Banners
define("_BANNERS_MODULE","I banner pubblicitari modulo");//Ad Banners Module
define("_BANNERS_MAIN","Pagina principale");//Main page
define("_BANNERS_MANAGEMENT","Gestire banner");//Manage banners
define("_BANNERS_ADDBANNER","Aggiungi Banner");//Add Banner
define("_BANNERS_IMAGE","Immagine");//Image
define("_BANNERS_LINK","Collegamento");//Link
define("_BANNERS_BANNER","Banner");//Banner
define("_BANNERS_INSERTBANNER","Aggiungi Banner");//Add Banner
define("_BANNERS_NOBANNERFOUND","N. striscioni sono stati trovati");//No banners were found
define("_BANNERS_BANNERSPAGE","Banner");//Banners
define("_BANNERS_SUCCESFULLYINSERTEDBANNERENTRY","Il banner è stato inserito con successo");//The banner was inserted succesfully
define("_BANNERS_PROBLEMINSERTINGBANNERENTRY","Un problema si è verificato mentre inserendo il banner");//A problem occured while inserting the banner
define("_BANNERS_SUCCESFULLYUPDATEDBANNERENTRY","Il banner è stato aggiornato con successo");//The banner was updated succesfully
define("_BANNERS_PROBLEMUPDATINGBANNERENTRY","Un problema si è verificato durante l&#39;aggiornamento il banner");//A problem occured while updating the banner
define("_BANNERS_SUCCESFULLYDELETEDBANNER","Il banner è stato eliminato con successo");//The banner was deleted succesfully
define("_BANNERS_DELETEBANNER","Elimina banner");//Delete banner
define("_BANNERS_EDITBANNER","Modifica banner");//Edit banner
define("_BANNERS_GOTOBANNERPAGE","Vai alla pagina di annunci Banner");//Go to Ad Banners page
define("_BANNERS_ORSELECTONEFROMLIST","O selezionarne uno dalla lista");//Or select one from list
?>
