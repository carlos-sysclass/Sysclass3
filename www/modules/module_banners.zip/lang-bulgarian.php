<?php
define("_BANNERS_BANNERS","Рекламни Банери");//Ad Banners
define("_BANNERS_MODULE","Рекламни банери модул");//Ad Banners Module
define("_BANNERS_MAIN","Основна страница");//Main page
define("_BANNERS_MANAGEMENT","Управление на банери");//Manage banners
define("_BANNERS_ADDBANNER","Добавяне на банер");//Add Banner
define("_BANNERS_IMAGE","Изображение");//Image
define("_BANNERS_LINK","Връзка");//Link
define("_BANNERS_BANNER","Знаме");//Banner
define("_BANNERS_INSERTBANNER","Добавяне на банер");//Add Banner
define("_BANNERS_NOBANNERFOUND","Не са намерени банери");//No banners were found
define("_BANNERS_BANNERSPAGE","Банери");//Banners
define("_BANNERS_SUCCESFULLYINSERTEDBANNERENTRY","В банер вкарването успешно");//The banner was inserted succesfully
define("_BANNERS_PROBLEMINSERTINGBANNERENTRY","Проблем при включването на банер");//A problem occured while inserting the banner
define("_BANNERS_SUCCESFULLYUPDATEDBANNERENTRY","В банер е актуализиран успешно");//The banner was updated succesfully
define("_BANNERS_PROBLEMUPDATINGBANNERENTRY","Проблем при актуализирането на банери");//A problem occured while updating the banner
define("_BANNERS_SUCCESFULLYDELETEDBANNER","В банер е изтрит успешно");//The banner was deleted succesfully
define("_BANNERS_DELETEBANNER","Изтрий банер");//Delete banner
define("_BANNERS_EDITBANNER","Редактиране банер");//Edit banner
define("_BANNERS_GOTOBANNERPAGE","Отидете на страницата Рекламни Банери");//Go to Ad Banners page
define("_BANNERS_ORSELECTONEFROMLIST","Или избери от списъка");//Or select one from list
?>
