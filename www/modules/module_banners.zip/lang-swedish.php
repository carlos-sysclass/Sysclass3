<?php
define("_BANNERS_BANNERS","Annons Banners");//Ad Banners
define("_BANNERS_MODULE","Ad banners modul");//Ad Banners Module
define("_BANNERS_MAIN","Startsida");//Main page
define("_BANNERS_MANAGEMENT","Hantera banners");//Manage banners
define("_BANNERS_ADDBANNER","Lägg Banner");//Add Banner
define("_BANNERS_IMAGE","Bild");//Image
define("_BANNERS_LINK","Länk");//Link
define("_BANNERS_BANNER","Banner");//Banner
define("_BANNERS_INSERTBANNER","Lägg Banner");//Add Banner
define("_BANNERS_NOBANNERFOUND","Nr banners hittades");//No banners were found
define("_BANNERS_BANNERSPAGE","Banners");//Banners
define("_BANNERS_SUCCESFULLYINSERTEDBANNERENTRY","Bannern infördes framgångsrikt");//The banner was inserted succesfully
define("_BANNERS_PROBLEMINSERTINGBANNERENTRY","Ett problem uppstod när du sätter i banner");//A problem occured while inserting the banner
define("_BANNERS_SUCCESFULLYUPDATEDBANNERENTRY","Bannern uppdaterades framgångsrikt");//The banner was updated succesfully
define("_BANNERS_PROBLEMUPDATINGBANNERENTRY","Ett problem uppstod när uppdaterar banderollen");//A problem occured while updating the banner
define("_BANNERS_SUCCESFULLYDELETEDBANNER","Bannern har raderats");//The banner was deleted succesfully
define("_BANNERS_DELETEBANNER","Radera banner");//Delete banner
define("_BANNERS_EDITBANNER","Redigera banner");//Edit banner
define("_BANNERS_GOTOBANNERPAGE","Gå till Ad banners sida");//Go to Ad Banners page
define("_BANNERS_ORSELECTONEFROMLIST","Eller välj en från listan");//Or select one from list
?>
