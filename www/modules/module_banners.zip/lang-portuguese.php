<?php
define("_BANNERS_BANNERS","Ad Banners");//Ad Banners
define("_BANNERS_MODULE","Módulo Ad Banners");//Ad Banners Module
define("_BANNERS_MAIN","Página principal");//Main page
define("_BANNERS_MANAGEMENT","Gerenciar banners");//Manage banners
define("_BANNERS_ADDBANNER","Adicionar Banner");//Add Banner
define("_BANNERS_IMAGE","Imagem");//Image
define("_BANNERS_LINK","Link");//Link
define("_BANNERS_BANNER","Banner");//Banner
define("_BANNERS_INSERTBANNER","Adicionar Banner");//Add Banner
define("_BANNERS_NOBANNERFOUND","Nenhum Banner foi encontrado");//No banners were found
define("_BANNERS_BANNERSPAGE","Banners");//Banners
define("_BANNERS_SUCCESFULLYINSERTEDBANNERENTRY","O banner foi inserido com sucesso");//The banner was inserted succesfully
define("_BANNERS_PROBLEMINSERTINGBANNERENTRY","Um problema ocorreu durante a inserção do banner");//A problem occured while inserting the banner
define("_BANNERS_SUCCESFULLYUPDATEDBANNERENTRY","O banner foi atualizado com sucesso");//The banner was updated succesfully
define("_BANNERS_PROBLEMUPDATINGBANNERENTRY","Um problema ocorreu ao atualizar o banner");//A problem occured while updating the banner
define("_BANNERS_SUCCESFULLYDELETEDBANNER","O banner foi eliminado com sucesso");//The banner was deleted succesfully
define("_BANNERS_DELETEBANNER","Excluir banner");//Delete banner
define("_BANNERS_EDITBANNER","Editar banner");//Edit banner
define("_BANNERS_GOTOBANNERPAGE","Ir para a página de Ad Banners");//Go to Ad Banners page
define("_BANNERS_ORSELECTONEFROMLIST","ou escolha a partir de uma lista");//Or select one from list
?>