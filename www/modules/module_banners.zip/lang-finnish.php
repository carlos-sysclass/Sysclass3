<?php
define("_BANNERS_BANNERS","Mainoksen Banners");//Ad Banners
define("_BANNERS_MODULE","Mainos bannerit moduuli");//Ad Banners Module
define("_BANNERS_MAIN","PRH");//Main page
define("_BANNERS_MANAGEMENT","Hallinnoi bannereita");//Manage banners
define("_BANNERS_ADDBANNER","Lisää Banner");//Add Banner
define("_BANNERS_IMAGE","Kuva");//Image
define("_BANNERS_LINK","Linkki");//Link
define("_BANNERS_BANNER","Banner");//Banner
define("_BANNERS_INSERTBANNER","Lisää Banner");//Add Banner
define("_BANNERS_NOBANNERFOUND","Ei banderolleja havaittiin");//No banners were found
define("_BANNERS_BANNERSPAGE","Banners");//Banners
define("_BANNERS_SUCCESFULLYINSERTEDBANNERENTRY","Banderolli on lisätty onnistuneesti");//The banner was inserted succesfully
define("_BANNERS_PROBLEMINSERTINGBANNERENTRY","Ongelma ilmeni, kun lisäämällä banner");//A problem occured while inserting the banner
define("_BANNERS_SUCCESFULLYUPDATEDBANNERENTRY","Banderolli on päivitetty onnistuneesti");//The banner was updated succesfully
define("_BANNERS_PROBLEMUPDATINGBANNERENTRY","Ongelma ilmeni, kun taas ajan tasalle banner");//A problem occured while updating the banner
define("_BANNERS_SUCCESFULLYDELETEDBANNER","Banderolli on poistettu onnistuneesti");//The banner was deleted succesfully
define("_BANNERS_DELETEBANNER","Poista banneri");//Delete banner
define("_BANNERS_EDITBANNER","Muokkaa banner");//Edit banner
define("_BANNERS_GOTOBANNERPAGE","Siirry Ad Bannerit sivu");//Go to Ad Banners page
define("_BANNERS_ORSELECTONEFROMLIST","Tai valitse yksi listasta");//Or select one from list
?>
