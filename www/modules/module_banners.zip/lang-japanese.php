<?php
define("_BANNERS_BANNERS","広告バナー");//Ad Banners
define("_BANNERS_MODULE","広告バナーモジュール");//Ad Banners Module
define("_BANNERS_MAIN","メインページ");//Main page
define("_BANNERS_MANAGEMENT","バナー管理");//Manage banners
define("_BANNERS_ADDBANNER","バナーを追加");//Add Banner
define("_BANNERS_IMAGE","イメージ");//Image
define("_BANNERS_LINK","リンク");//Link
define("_BANNERS_BANNER","バナー");//Banner
define("_BANNERS_INSERTBANNER","バナーを追加");//Add Banner
define("_BANNERS_NOBANNERFOUND","ないバナーが発見された");//No banners were found
define("_BANNERS_BANNERSPAGE","旗");//Banners
define("_BANNERS_SUCCESFULLYINSERTEDBANNERENTRY","バナーが正常に挿入されて");//The banner was inserted succesfully
define("_BANNERS_PROBLEMINSERTINGBANNERENTRY","一方、バナー広告を挿入する問題が発生しました");//A problem occured while inserting the banner
define("_BANNERS_SUCCESFULLYUPDATEDBANNERENTRY","バナーが正常に更新されました");//The banner was updated succesfully
define("_BANNERS_PROBLEMUPDATINGBANNERENTRY","一方、バナーの更新の問題が発生");//A problem occured while updating the banner
define("_BANNERS_SUCCESFULLYDELETEDBANNER","バナーが正常に削除されました");//The banner was deleted succesfully
define("_BANNERS_DELETEBANNER","削除バナー");//Delete banner
define("_BANNERS_EDITBANNER","編集バナー");//Edit banner
define("_BANNERS_GOTOBANNERPAGE","バナー広告のページへ戻る");//Go to Ad Banners page
define("_BANNERS_ORSELECTONEFROMLIST","またはリストから選択してください");//Or select one from list
?>
