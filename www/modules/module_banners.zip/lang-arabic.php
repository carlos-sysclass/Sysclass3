<?php
define("_BANNERS_BANNERS","وكتب على لافتات إعلانية");//Ad Banners
define("_BANNERS_MODULE","لافتات اعلانية وحدة");//Ad Banners Module
define("_BANNERS_MAIN","الصفحة الرئيسية");//Main page
define("_BANNERS_MANAGEMENT","إدارة لافتات");//Manage banners
define("_BANNERS_ADDBANNER","أضف بانر");//Add Banner
define("_BANNERS_IMAGE","صورة");//Image
define("_BANNERS_LINK","رابط");//Link
define("_BANNERS_BANNER","راية");//Banner
define("_BANNERS_INSERTBANNER","أضف بانر");//Add Banner
define("_BANNERS_NOBANNERFOUND","لا لافتات تم العثور على");//No banners were found
define("_BANNERS_BANNERSPAGE","الرايات");//Banners
define("_BANNERS_SUCCESFULLYINSERTEDBANNERENTRY","شعار أدرجت بنجاح");//The banner was inserted succesfully
define("_BANNERS_PROBLEMINSERTINGBANNERENTRY","وهناك مشكلة وقعت بينما بإدراج راية");//A problem occured while inserting the banner
define("_BANNERS_SUCCESFULLYUPDATEDBANNERENTRY","راية تم تحديث بنجاح");//The banner was updated succesfully
define("_BANNERS_PROBLEMUPDATINGBANNERENTRY","وهناك مشكلة حدثت حين استكمال راية");//A problem occured while updating the banner
define("_BANNERS_SUCCESFULLYDELETEDBANNER","راية تم حذف بنجاح");//The banner was deleted succesfully
define("_BANNERS_DELETEBANNER","حذف راية");//Delete banner
define("_BANNERS_EDITBANNER","تحرير راية");//Edit banner
define("_BANNERS_GOTOBANNERPAGE","اذهب إلى صفحة وكتب على لافتات إعلانية");//Go to Ad Banners page
define("_BANNERS_ORSELECTONEFROMLIST","أو اختر واحدا من قائمة");//Or select one from list
?>
