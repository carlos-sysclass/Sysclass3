<?php
define("_BANNERS_BANNERS","ΰ¤µΰ¤Ώΰ¤ΰ¥ΰ¤ΰ¤Ύΰ¤ΰ¤¨ ΰ¤¬ΰ¥ΰ¤¨ΰ¤°ΰ¥ΰ¤Έ");//Ad Banners
define("_BANNERS_MODULE","ΰ¤µΰ¤Ώΰ¤ΰ¥ΰ¤ΰ¤Ύΰ¤ΰ¤¨ ΰ¤¬ΰ¥ΰ¤¨ΰ¤° ΰ¤®ΰ¥‰ΰ¤΅ΰ¥ΰ¤―ΰ¥‚ΰ¤²");//Ad Banners Module
define("_BANNERS_MAIN","ΰ¤®ΰ¥ΰ¤–ΰ¥ΰ¤― ΰ¤ΰ¥ƒΰ¤·ΰ¥ΰ¤ ");//Main page
define("_BANNERS_MANAGEMENT","ΰ¤ΰ¥ΰ¤°ΰ¤¬ΰ¤‚ΰ¤§ΰ¤Ώΰ¤¤ ΰ¤¬ΰ¥ΰ¤¨ΰ¤°");//Manage banners
define("_BANNERS_ADDBANNER","ΰ¤¬ΰ¥ΰ¤¨ΰ¤° ΰ¤ΰ¥‹ΰ¤΅ΰ¤Όΰ¥‡ΰ¤‚");//Add Banner
define("_BANNERS_IMAGE","ΰ¤›ΰ¤µΰ¤Ώ");//Image
define("_BANNERS_LINK","ΰ¤ΰ¥‹ΰ¤΅ΰ¤Όΰ¤¨ΰ¤Ύ");//Link
define("_BANNERS_BANNER","ΰ¤¬ΰ¥ΰ¤¨ΰ¤°");//Banner
define("_BANNERS_INSERTBANNER","ΰ¤¬ΰ¥ΰ¤¨ΰ¤° ΰ¤ΰ¥‹ΰ¤΅ΰ¤Όΰ¥‡ΰ¤‚");//Add Banner
define("_BANNERS_NOBANNERFOUND","ΰ¤•ΰ¥‹ΰ¤ ΰ¤¬ΰ¥ΰ¤¨ΰ¤° ΰ¤ΰ¤Ύΰ¤ ΰ¤—ΰ¤");//No banners were found
define("_BANNERS_BANNERSPAGE","ΰ¤¬ΰ¥ΰ¤¨ΰ¤°");//Banners
define("_BANNERS_SUCCESFULLYINSERTEDBANNERENTRY","ΰ¤¬ΰ¥ΰ¤¨ΰ¤° ΰ¤Έΰ¤«ΰ¤²ΰ¤¤ΰ¤Ύΰ¤ΰ¥‚ΰ¤°ΰ¥ΰ¤µΰ¤• ΰ¤΅ΰ¤Ύΰ¤²ΰ¤Ύ ΰ¤¥ΰ¤Ύ");//The banner was inserted succesfully
define("_BANNERS_PROBLEMINSERTINGBANNERENTRY","ΰ¤ΰ¤¬ΰ¤•ΰ¤Ώ ΰ¤¬ΰ¥ΰ¤¨ΰ¤° ΰ¤΅ΰ¤Ύΰ¤²ΰ¤¨ΰ¥‡ ΰ¤ΰ¤• ΰ¤Έΰ¤®ΰ¤Έΰ¥ΰ¤―ΰ¤Ύ ΰ¤Ήΰ¥ΰ¤");//A problem occured while inserting the banner
define("_BANNERS_SUCCESFULLYUPDATEDBANNERENTRY","ΰ¤¬ΰ¥ΰ¤¨ΰ¤° ΰ¤Έΰ¤«ΰ¤²ΰ¤¤ΰ¤Ύΰ¤ΰ¥‚ΰ¤°ΰ¥ΰ¤µΰ¤• ΰ¤…ΰ¤¦ΰ¥ΰ¤―ΰ¤¤ΰ¤¨ ΰ¤•ΰ¤Ώΰ¤―ΰ¤Ύ ΰ¤—ΰ¤―ΰ¤Ύ");//The banner was updated succesfully
define("_BANNERS_PROBLEMUPDATINGBANNERENTRY","ΰ¤ΰ¤¬ΰ¤•ΰ¤Ώ ΰ¤¬ΰ¥ΰ¤¨ΰ¤° ΰ¤…ΰ¤¦ΰ¥ΰ¤―ΰ¤¤ΰ¤¨ ΰ¤ΰ¤• ΰ¤Έΰ¤®ΰ¤Έΰ¥ΰ¤―ΰ¤Ύ ΰ¤Ήΰ¥ΰ¤");//A problem occured while updating the banner
define("_BANNERS_SUCCESFULLYDELETEDBANNER","ΰ¤¬ΰ¥ΰ¤¨ΰ¤° ΰ¤Έΰ¤«ΰ¤²ΰ¤¤ΰ¤Ύΰ¤ΰ¥‚ΰ¤°ΰ¥ΰ¤µΰ¤• ΰ¤¨ΰ¤·ΰ¥ΰ¤ ΰ¤•ΰ¤° ΰ¤¦ΰ¤Ώΰ¤―ΰ¤Ύ ΰ¤—ΰ¤―ΰ¤Ύ");//The banner was deleted succesfully
define("_BANNERS_DELETEBANNER","ΰ¤Ήΰ¤ΰ¤Ύΰ¤ΰ¤ ΰ¤¬ΰ¥ΰ¤¨ΰ¤°");//Delete banner
define("_BANNERS_EDITBANNER","ΰ¤Έΰ¤‚ΰ¤ΰ¤Ύΰ¤¦ΰ¤Ώΰ¤¤ ΰ¤•ΰ¤°ΰ¥‡ΰ¤‚ ΰ¤¬ΰ¥ΰ¤¨ΰ¤°");//Edit banner
define("_BANNERS_GOTOBANNERPAGE","ΰ¤µΰ¤Ώΰ¤ΰ¥ΰ¤ΰ¤Ύΰ¤ΰ¤¨ ΰ¤¬ΰ¥ΰ¤¨ΰ¤°ΰ¥ΰ¤Έ ΰ¤•ΰ¥‡ ΰ¤²ΰ¤Ώΰ¤ ΰ¤ΰ¥ƒΰ¤·ΰ¥ΰ¤  ΰ¤ΰ¤Ύΰ¤“");//Go to Ad Banners page
define("_BANNERS_ORSELECTONEFROMLIST","ΰ¤Έΰ¥‚ΰ¤ΰ¥€ ΰ¤Έΰ¥‡ ΰ¤ΰ¤―ΰ¤¨ ΰ¤•ΰ¤°ΰ¥‡ΰ¤‚ ΰ¤―ΰ¤Ύ ΰ¤«ΰ¤Ώΰ¤° ΰ¤ΰ¤•");//Or select one from list
?>
