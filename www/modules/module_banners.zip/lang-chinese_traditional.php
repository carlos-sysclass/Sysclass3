<?php
define("_BANNERS_BANNERS","廣告橫幅");//Ad Banners
define("_BANNERS_MODULE","廣告橫幅模塊");//Ad Banners Module
define("_BANNERS_MAIN","主網頁");//Main page
define("_BANNERS_MANAGEMENT","管理標語");//Manage banners
define("_BANNERS_ADDBANNER","新增橫幅");//Add Banner
define("_BANNERS_IMAGE","圖像");//Image
define("_BANNERS_LINK","鏈接");//Link
define("_BANNERS_BANNER","橫幅");//Banner
define("_BANNERS_INSERTBANNER","新增橫幅");//Add Banner
define("_BANNERS_NOBANNERFOUND","沒有橫幅被發現");//No banners were found
define("_BANNERS_BANNERSPAGE","八旗");//Banners
define("_BANNERS_SUCCESFULLYINSERTEDBANNERENTRY","旗幟插入成功");//The banner was inserted succesfully
define("_BANNERS_PROBLEMINSERTINGBANNERENTRY","出現了問題，而插入的旗幟");//A problem occured while inserting the banner
define("_BANNERS_SUCCESFULLYUPDATEDBANNERENTRY","旗幟是更新成功");//The banner was updated succesfully
define("_BANNERS_PROBLEMUPDATINGBANNERENTRY","出現了問題，而更新的旗幟");//A problem occured while updating the banner
define("_BANNERS_SUCCESFULLYDELETEDBANNER","旗幟是成功刪除");//The banner was deleted succesfully
define("_BANNERS_DELETEBANNER","刪除旗幟");//Delete banner
define("_BANNERS_EDITBANNER","編輯旗幟");//Edit banner
define("_BANNERS_GOTOBANNERPAGE","轉到廣告橫幅頁");//Go to Ad Banners page
define("_BANNERS_ORSELECTONEFROMLIST","或選擇其中一個，從名單");//Or select one from list
?>
