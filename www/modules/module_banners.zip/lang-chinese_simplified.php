<?php
define("_BANNERS_BANNERS","广告横幅");//Ad Banners
define("_BANNERS_MODULE","广告横幅模块");//Ad Banners Module
define("_BANNERS_MAIN","主网页");//Main page
define("_BANNERS_MANAGEMENT","管理标语");//Manage banners
define("_BANNERS_ADDBANNER","新增横幅");//Add Banner
define("_BANNERS_IMAGE","图像");//Image
define("_BANNERS_LINK","链接");//Link
define("_BANNERS_BANNER","横幅");//Banner
define("_BANNERS_INSERTBANNER","新增横幅");//Add Banner
define("_BANNERS_NOBANNERFOUND","没有横幅被发现");//No banners were found
define("_BANNERS_BANNERSPAGE","八旗");//Banners
define("_BANNERS_SUCCESFULLYINSERTEDBANNERENTRY","旗帜插入成功");//The banner was inserted succesfully
define("_BANNERS_PROBLEMINSERTINGBANNERENTRY","出现了问题，而插入的旗帜");//A problem occured while inserting the banner
define("_BANNERS_SUCCESFULLYUPDATEDBANNERENTRY","旗帜是更新成功");//The banner was updated succesfully
define("_BANNERS_PROBLEMUPDATINGBANNERENTRY","出现了问题，而更新的旗帜");//A problem occured while updating the banner
define("_BANNERS_SUCCESFULLYDELETEDBANNER","旗帜是成功删除");//The banner was deleted succesfully
define("_BANNERS_DELETEBANNER","删除旗帜");//Delete banner
define("_BANNERS_EDITBANNER","编辑旗帜");//Edit banner
define("_BANNERS_GOTOBANNERPAGE","转到广告横幅页");//Go to Ad Banners page
define("_BANNERS_ORSELECTONEFROMLIST","或选择其中一个，从名单");//Or select one from list
?>
