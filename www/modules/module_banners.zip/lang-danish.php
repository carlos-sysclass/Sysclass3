<?php
define("_BANNERS_BANNERS","Ad Bannere");//Ad Banners
define("_BANNERS_MODULE","Ad bannere modul");//Ad Banners Module
define("_BANNERS_MAIN","Main page");//Main page
define("_BANNERS_MANAGEMENT","Administrer bannere");//Manage banners
define("_BANNERS_ADDBANNER","Tilføj Banner");//Add Banner
define("_BANNERS_IMAGE","Image");//Image
define("_BANNERS_LINK","Link");//Link
define("_BANNERS_BANNER","Banner");//Banner
define("_BANNERS_INSERTBANNER","Tilføj Banner");//Add Banner
define("_BANNERS_NOBANNERFOUND","Nr. bannere blev fundet");//No banners were found
define("_BANNERS_BANNERSPAGE","Bannere");//Banners
define("_BANNERS_SUCCESFULLYINSERTEDBANNERENTRY","Banneret blev indsat med succes");//The banner was inserted succesfully
define("_BANNERS_PROBLEMINSERTINGBANNERENTRY","Et problem opstod under indsættelse af de banneret");//A problem occured while inserting the banner
define("_BANNERS_SUCCESFULLYUPDATEDBANNERENTRY","Banneret blev opdateret med succes");//The banner was updated succesfully
define("_BANNERS_PROBLEMUPDATINGBANNERENTRY","Et problem opstod under ajourføring af de banneret");//A problem occured while updating the banner
define("_BANNERS_SUCCESFULLYDELETEDBANNER","Banneret blev slettet med succes");//The banner was deleted succesfully
define("_BANNERS_DELETEBANNER","Slet banner");//Delete banner
define("_BANNERS_EDITBANNER","Rediger banner");//Edit banner
define("_BANNERS_GOTOBANNERPAGE","Gå til Ad Bannere side");//Go to Ad Banners page
define("_BANNERS_ORSELECTONEFROMLIST","Eller vælge en fra listen");//Or select one from list
?>
