<?php
define("_BANNERS_BANNERS","Διαφημίσεις");
define("_BANNERS_MODULE", "Άρθρωμα Διαφημίσεις");
define("_BANNERS_MAIN","Κύρια σελίδα");
define("_BANNERS_MANAGEMENT","Διαχείριση");
define("_BANNERS_ADDBANNER", "Προσθήκη Διαφήμισης");
define("_BANNERS_IMAGE", "Εικόνα");
define("_BANNERS_LINK", "Σύνδεσμος");
define("_BANNERS_BANNER", "Διαφήμιση");
define("_BANNERS_INSERTBANNER", "Προσθήκη διαφήμισης");
define("_BANNERS_NOBANNERFOUND", "Δεν υπάρχουν διαφημίσεις");
define("_BANNERS_BANNERSSPAGE", "Διαφημίσεις");
define("_BANNERS_SUCCESFULLYINSERTEDBANNERENTRY", "Η διαφήμιση προστέθηκε επιτυχώς");
define("_BANNERS_PROBLEMINSERTINGBANNERENTRY", "Παρουσιάστηκε σφάλμα κατά την προσθήκη της διαφήμισης");
define("_BANNERS_SUCCESFULLYUPDATEDBANNERENTRY", "Η διαφήμιση ενημερώθηκε επιτυχώς");
define("_BANNERS_PROBLEMUPDATINGBANNERENTRY", "Παρουσιάστηκε σφάλμα κατά την ενημέρωση της διαφήμισης");
define("_BANNERS_SUCCESFULLYDELETEDBANNER", "Η διαφήμιση διαγράφηκε επιτυχώς");
define("_BANNERS_DELETEBANNER", "Διαγραφή διαφήμισης");
define("_BANNERS_EDITBANNER", "Ενημέρωση διαφήμισης");
define("_BANNERS_GOTOBANNERSPAGE", "Μετάβαση στην σελίδα των Διαφημίσεων");
define("_BANNERS_ORSELECTONEFROMLIST", "Ή επιλέξτε ένα από τη λίστα");
?>