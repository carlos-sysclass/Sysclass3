<?php
define("_BANNERS_BANNERS","Ad Bannere");//Ad Banners
define("_BANNERS_MODULE","Annonse bannere modulen");//Ad Banners Module
define("_BANNERS_MAIN","Hovedside");//Main page
define("_BANNERS_MANAGEMENT","Behandle bannere");//Manage banners
define("_BANNERS_ADDBANNER","Legg Banner");//Add Banner
define("_BANNERS_IMAGE","Bilde");//Image
define("_BANNERS_LINK","Forbindelse");//Link
define("_BANNERS_BANNER","Banner");//Banner
define("_BANNERS_INSERTBANNER","Legg Banner");//Add Banner
define("_BANNERS_NOBANNERFOUND","Ingen bannere ble funnet");//No banners were found
define("_BANNERS_BANNERSPAGE","Bannere");//Banners
define("_BANNERS_SUCCESFULLYINSERTEDBANNERENTRY","Banneret ble satt inn vellykket");//The banner was inserted succesfully
define("_BANNERS_PROBLEMINSERTINGBANNERENTRY","Et problem oppstod ved å sette inn banner");//A problem occured while inserting the banner
define("_BANNERS_SUCCESFULLYUPDATEDBANNERENTRY","Banneret ble oppdatert");//The banner was updated succesfully
define("_BANNERS_PROBLEMUPDATINGBANNERENTRY","Et problem oppstod under oppdatering av banneret");//A problem occured while updating the banner
define("_BANNERS_SUCCESFULLYDELETEDBANNER","Banneret ble slettet");//The banner was deleted succesfully
define("_BANNERS_DELETEBANNER","Slett banner");//Delete banner
define("_BANNERS_EDITBANNER","Rediger banner");//Edit banner
define("_BANNERS_GOTOBANNERPAGE","Gå til Ad Bannere side");//Go to Ad Banners page
define("_BANNERS_ORSELECTONEFROMLIST","Eller velg en fra listen");//Or select one from list
?>
