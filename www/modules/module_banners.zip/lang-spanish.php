<?php
define("_BANNERS_BANNERS","Banners de anuncios");//Ad Banners
define("_BANNERS_MODULE","Los anuncios módulo");//Ad Banners Module
define("_BANNERS_MAIN","Página Principal");//Main page
define("_BANNERS_MANAGEMENT","Administrar banners");//Manage banners
define("_BANNERS_ADDBANNER","Añadir Banner");//Add Banner
define("_BANNERS_IMAGE","Imagen");//Image
define("_BANNERS_LINK","Vínculo");//Link
define("_BANNERS_BANNER","Banner");//Banner
define("_BANNERS_INSERTBANNER","Añadir Banner");//Add Banner
define("_BANNERS_NOBANNERFOUND","No se encontraron pancartas");//No banners were found
define("_BANNERS_BANNERSPAGE","Banners");//Banners
define("_BANNERS_SUCCESFULLYINSERTEDBANNERENTRY","El banner se insertó con éxito");//The banner was inserted succesfully
define("_BANNERS_PROBLEMINSERTINGBANNERENTRY","Un problema se produjo al mismo tiempo la inserción de la bandera");//A problem occured while inserting the banner
define("_BANNERS_SUCCESFULLYUPDATEDBANNERENTRY","El banner se ha actualizado con éxito");//The banner was updated succesfully
define("_BANNERS_PROBLEMUPDATINGBANNERENTRY","Se ha producido un problema mientras que la actualización de la bandera");//A problem occured while updating the banner
define("_BANNERS_SUCCESFULLYDELETEDBANNER","El banner se ha eliminado con éxito");//The banner was deleted succesfully
define("_BANNERS_DELETEBANNER","Eliminar banner");//Delete banner
define("_BANNERS_EDITBANNER","Editar banner");//Edit banner
define("_BANNERS_GOTOBANNERPAGE","Ir a la página de anuncios Banners");//Go to Ad Banners page
define("_BANNERS_ORSELECTONEFROMLIST","O seleccione uno de la lista");//Or select one from list
?>
