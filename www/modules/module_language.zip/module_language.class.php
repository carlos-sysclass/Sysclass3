<?php

class module_language extends MagesterModule {
	
	const GET_LANGUAGES				= 'get_languages';
	const GET_SECTION				= 'get_section';
//	const ADD_POLO					= 'add_polo';
//	const EDIT_POLO					= 'edit_polo';
//	const DELETE_POLO				= 'delete_polo';
	
    // Mandatory functions required for module function
    public function getName() {
        return _MODULE_LANGUAGE;
    }

    public function getPermittedRoles() {
        return array("administrator" /*,"professor" *//*,"student"*/);
    }

    public function isLessonModule() {
        return false;
    }

    public function getCenterLinkInfo() {
        $currentUser = $this -> getCurrentUser();
        if ($currentUser -> getType() == "administrator") {
            return array('title' => _MODULE_LANGUAGE,
                         'image' => $this -> moduleBaseDir . 'images/language.png',
                         'link'  => $this -> moduleBaseUrl
            );
        }
    }

    public function getNavigationLinks() {
    	$selectedAction = isset($_GET['action']) ? $_GET['action'] : self::GET_LANGUAGES;

        $basicNavArray = array (
			array ('title' => _HOME, 'link' => "administrator.php?ctg=control_panel"),
    		array ('title' => _MODULE_LANGUAGE_MANAGEMENT, 'link'  => $this -> moduleBaseUrl)
		);
        /*
		if ($selectedAction == self::EDIT_POLO) {
            $basicNavArray[] = array ('title' => _MODULE_POLOS_EDITPOLO, 'link'  => $this -> moduleBaseUrl . "&action=" . self::EDIT_POLO . "&polo_id=". $_GET['polo_id']);
		} else if ($selectedAction == self::ADD_POLO) {
            $basicNavArray[] = array ('title' => _MODULE_POLOS_ADDPOLO, 'link'  => $this -> moduleBaseUrl . "&action=" . self::ADD_POLO);
		}
		*/
        return $basicNavArray;
    }

    public function getSidebarLinkInfo() {
        $link_of_menu_clesson = array (
        	array (
        		'id' => 'language_link_id1',
            	'title' => $this->getName(),
            	'image' => $this -> moduleBaseDir . 'images/language16.png',
            	'_magesterExtensions' => '1',
            	'link'  => $this -> moduleBaseUrl
        	)
        );
        
        return array ( "system" => $link_of_menu_clesson);

    }

    public function getLinkToHighlight() {
        return 'language_link_id1';
    }


    /* MAIN-INDEPENDENT MODULE PAGES */
    public function getModule() {
		$selectedAction = isset($_GET['action']) ? $_GET['action'] : self::GET_LANGUAGES;
		
		$smarty = $this -> getSmartyVar();
		
		$smarty -> assign("T_MODULE_LANGUAGE_ACTION", $selectedAction);    	
    	
        // Get smarty global variable
        $smarty = $this -> getSmartyVar();
        
        if ($selectedAction == self::GET_SECTION) {
        	// 1. LOAD SELECTED SECTION
        	if (eF_checkParameter($_GET['section_id'], 'directory')) {
        		$section_id = $_GET['section_id'];
        		$filename = $this->moduleBaseDir . "sections/" . $section_id . ".php.inc";
        		if (file_exists($filename)) {
        			$output = require_once($filename);
        			
        			if ($_GET['output'] == 'json') {
        				echo json_encode($output['data']);
        				exit;	
        			} else {
        				$smarty->assign("T_MODULE_LANGUAGE_SECTION_ID", $section_id);
        				$smarty->assign("T_MODULE_LANGUAGE_SECTION_OUTPUT", $output);
        			}
        		} else {
        			// ERRO: SECTION NOT FOUND
        			if ($_GET['output'] == 'json') {
        				/** @todo Get a way to return JSON errors */
						echo json_encode(_MODULE_LANGUAGE_SECTION_NOT_FOUND);
        				exit;
        			} else {
        				$this->setMessageVar(_MODULE_LANGUAGE_SECTION_NOT_FOUND, "failure");
        			}
        		}
        	} else {
        		if ($_GET['output'] == 'json') {
        			/** @todo Get a way to return JSON errors */
        			echo json_encode(_MODULE_LANGUAGE_SECTION_INVALID);
					exit;
        		} else {
        			$this->setMessageVar(_MODULE_LANGUAGE_SECTION_INVALID, "failure");		
        		}
        		
        	}
        }
/*
        if ($selectedAction == self::DELETE_POLO && eF_checkParameter($_GET['polo_id'], 'id')) {
            eF_deleteTableData("module_polos", "id=".$_GET['polo_id']);
            
            header("location:". $this -> moduleBaseUrl ."&message=".urlencode(_MODULE_POLOS_SUCCESFULLYDELETEDPOLOENTRY)."&message_type=success");
        } else if (
        	$selectedAction == self::ADD_POLO || 
        	($selectedAction == self::EDIT_POLO && eF_checkParameter($_GET['polo_id'], 'id'))
        ) {

            // Create ajax enabled table for meeting attendants
            if ($selectedAction == self::EDIT_POLO) {
                if (isset($_GET['ajax']) && $_GET['ajax'] == 'poloTable') {
                    isset($_GET['limit']) && eF_checkParameter($_GET['limit'], 'uint') ? $limit = $_GET['limit'] : $limit = G_DEFAULT_TABLE_SIZE;

                    if (isset($_GET['sort']) && eF_checkParameter($_GET['sort'], 'text')) {
                        $sort = $_GET['sort'];
                        isset($_GET['order']) && $_GET['order'] == 'desc' ? $order = 'desc' : $order = 'asc';
                    } else {
                        $sort = 'login';
                    }

                    $polos = eF_getTableData("module_polos", "*" );

                    $users = eF_multiSort($users, $_GET['sort'], $order);
                    if (isset($_GET['filter'])) {
                        $users = eF_filterData($users , $_GET['filter']);
                    }

                    $smarty -> assign("T_USERS_SIZE", sizeof($users));

                    if (isset($_GET['limit']) && eF_checkParameter($_GET['limit'], 'int')) {
                        isset($_GET['offset']) && eF_checkParameter($_GET['offset'], 'int') ? $offset = $_GET['offset'] : $offset = 0;
                        $users = array_slice($users, $offset, $limit);
                    }

					$smarty -> assign("T_POLOS", $polos);
                    $smarty -> display($this -> getSmartyTpl());
                    exit;

                } else {
                    $polos = eF_getTableData("module_polos", "*" );
                    $smarty -> assign("T_POLOS", $polos);
                }
            }

            $form = new HTML_QuickForm("polo_entry_form", "post", $_SERVER['REQUEST_URI'], "", null, true);
			$form -> addElement('hidden', 'polo_ID');
			
            $form -> registerRule('checkParameter', 'callback', 'eF_checkParameter');                   //Register this rule for checking user input with our function, eF_checkParameter
            
            $stateList = localization::getStateList();
            
            $form -> addElement('text', 'nome', _MODULE_POLOS_NOME, 'class = "large"');
            $form -> addRule('nome', _MODULE_POLOS_THEFIELDNAMEISMANDATORY, 'required', null, 'client');
            $form -> addElement('text', 'razao_social', _MODULE_POLOS_RAZAO_SOCIAL, 'class = "large"');
            $form -> addRule('razao_social', _MODULE_POLOS_THEFIELDRAZAOSOCIALISMANDATORY, 'required', null, 'client');
            $form -> addElement('text', 'contato', _MODULE_POLOS_CONTATO, 'class = "large"');
			$form -> addElement('text', 'cep', _MODULE_POLOS_CEP, 'class = "medium"');
			$form -> addElement('text', 'endereco', _MODULE_POLOS_ENDERECO, 'class = "large"');
			$form -> addElement('text', 'numero', _MODULE_POLOS_NUMERO, 'class = "small"');
			$form -> addElement('text', 'complemento', _MODULE_POLOS_COMPLEMENTO, 'class = "small"');
			$form -> addElement('text', 'bairro', _MODULE_POLOS_BAIRRO, 'class = "medium"');
			$form -> addElement('text', 'cidade', _MODULE_POLOS_CIDADE, 'class = "medium"');
			$form -> addElement('select', 'uf', _MODULE_POLOS_UF, $stateList, 'class = "small"');
			$form -> addElement('text', 'telefone', _MODULE_POLOS_TELEFONE, 'class = "medium"');
			$form -> addElement('text', 'celular', _MODULE_POLOS_CELULAR, 'class = "medium"');
			$form -> addElement('textarea', 'observacoes', _MODULE_POLOS_OBSERVACOES, 'class = "large"');
			$form -> addElement('advcheckbox', 'active', _MODULE_POLOS_ACTIVE, null, '', array(0, 1));
			
            $form -> addElement('submit', 'submit_polo', _MODULE_POLOS_SAVE, 'class = "button_colour round_all"');
            
            if ($selectedAction == self::EDIT_POLO) {
                $polo_entry = eF_getTableData("module_polos", "*", "id=".$_GET['polo_id']);
                
				$defaults = array(
					'polo_ID'		=> $polo_entry[0]['id'],
					'nome' 			=> $polo_entry[0]['nome'],
					'razao_social'	=> $polo_entry[0]['razao_social'],
					'contato'		=> $polo_entry[0]['contato'],
					'observacoes'	=> $polo_entry[0]['observacoes'],
					'cep'			=> $polo_entry[0]['cep'],
					'endereco'		=> $polo_entry[0]['endereco'],
					'numero'		=> $polo_entry[0]['numero'],
					'complemento'	=> $polo_entry[0]['complemento'],
					'bairro'		=> $polo_entry[0]['bairro'],
					'cidade'		=> $polo_entry[0]['cidade'],
					'uf'			=> $polo_entry[0]['uf'],
					'telefone'		=> $polo_entry[0]['telefone'],
					'celular'		=> $polo_entry[0]['celular'],
					'active'		=> (bool)($polo_entry[0]['active'] == '1')				
				);
            } else {
                $defaults = array(
					'polo_ID'		=> -1,
                	'active'		=> 1           
				);
            }
            $form -> setDefaults( $defaults );            

            if ($form -> isSubmitted() && $form -> validate()) {
            	$fields = array(
					'nome' 			=> $form -> exportValue('nome'),
					'razao_social'	=> $form -> exportValue('razao_social'),
					'contato'		=> $form -> exportValue('contato'),
					'observacoes'	=> $form -> exportValue('observacoes'),
					'cep'			=> $form -> exportValue('cep'),
					'endereco'		=> $form -> exportValue('endereco'),
					'numero'		=> $form -> exportValue('numero'),
					'complemento'	=> $form -> exportValue('complemento'),
					'bairro'		=> $form -> exportValue('bairro'),
					'cidade'		=> $form -> exportValue('cidade'),
					'uf'			=> $form -> exportValue('uf'),
					'telefone'		=> $form -> exportValue('telefone'),
					'celular'		=> $form -> exportValue('celular'),
					'active'		=> $form -> exportValue('active')				
            	);
            	
             	if ($selectedAction == self::EDIT_POLO) {
             		$fields['id']	= $form -> exportValue('polo_ID');
             		
					if (eF_updateTableData("module_polos", $fields, "id=".$_GET['polo_id'])) {
						header("location:".$this -> moduleBaseUrl."&message=".urlencode(_MODULE_POLOS_SUCCESFULLYUPDATEDPOLOENTRY)."&message_type=success");
					} else {
						header("location:".$this -> moduleBaseUrl."&action=" . self::EDIT_POLO ."&polo_id=".$_GET['polo_id']."&message=".urlencode(_MODULE_POLOS_PROBLEMUPDATINGPOLOENTRY)."&message_type=failure");
					}
				} else {
					if ($result = eF_insertTableData("module_polos", $fields)) {
						header("location:".$this -> moduleBaseUrl."&action=" . self::EDIT_POLO ."&polo_id=".$result."&message=".urlencode(_MODULE_POLOS_SUCCESFULLYINSERTEDPOLOENTRY)."&message_type=success&tab=users");
					} else {
						header("location:".$this -> moduleBaseUrl."&action=" . self::ADD_POLO . "&message=".urlencode(_MODULE_POLOS_PROBLEMINSERTINGPOLOENTRY)."&message_type=failure");
					}
				}
            }
            
            $renderer = new HTML_QuickForm_Renderer_ArraySmarty($smarty);
            $form -> accept($renderer);

            $smarty -> assign('T_MODULE_POLOS_FORM', $renderer -> toArray());
        } else {
			$polos = eF_getTableData("module_polos", "*" );
            $smarty -> assign("T_POLOS", $polos);
        }
        */
        return true;
    }

    public function getSmartyTpl() {
        $smarty = $this -> getSmartyVar();
        $smarty -> assign("T_MODULE_LANGUAGE_BASEDIR" , $this -> moduleBaseDir);
        $smarty -> assign("T_MODULE_LANGUAGE_BASEURL" , $this -> moduleBaseUrl);
        $smarty -> assign("T_MODULE_LANGUAGE_BASELINK" , $this -> moduleBaseLink);
        
        $selectedAction = isset($_GET['action']) ? $_GET['action'] : self::GET_LANGUAGES;
        
        if ($selectedAction != self::GET_SECTION) {
	        
	        $smarty -> assign("T_MODULE_LANGUAGE_ACTION", $selectedAction);
	        
	        return $this -> moduleBaseDir . "templates/default.tpl";
        }
    }
    
    public function getLanguageFile($language = null) {
    	if (is_null($language)) {
    		$language = $this->getCurrentLanguage();
    	}
    	// REQUIRE ALL SECTIONS FILE TRANSLATED FILES
    	// READ DIRECTION language / $language /, AND INCLUDE FILES IN ORDER
    	$directory = $this->moduleBaseDir . "languages/" . $language;
    	
    	$this->includeLanguageFiles($directory);
	}
    
    private function includeLanguageFiles($directory = null) {
    	if (is_null($directory)) {
    		$directory = $this->moduleBaseDir . "languages/" . $this->getCurrentLanguage();
    	}
    	 
    	$files = scandir($directory, 1);
    	natcasesort($files);
    	
    	
    	foreach($files as $file) {
    		if ($file == '.' || $file == '..' || strpos($file, '.') === 0) {
    			continue;
			} elseif (is_dir($directory . '/' . $file)) {
    			$this->includeLanguageFiles($directory . '/' . $file);
    		} elseif (is_file($directory . '/' . $file)) {
    			include_once($directory . '/' . $file);
    		}
    	}
    }
    
	private function getCurrentLanguage() {
		if (isset($_SESSION['s_language'])) {
			/** If there is a current language in the session, use that*/
			return $_SESSION['s_language'];
		} elseif ($GLOBALS['configuration']['default_language']) {
    		/** If there isn't a language in the session, use the default system language*/
			return $GLOBALS['configuration']['default_language'];
		} else {
    		//If there isn't neither a session language, or a default language in the configuration, use english by default
    		return "english";
		}
	}
}
?>