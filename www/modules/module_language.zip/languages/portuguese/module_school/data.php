<?php
define("_MODULE_SCHOOL","Escolas");
define("_MODULE_SCHOOLS_MANAGEMENT", "Gerenciar Escolas");
define("_MODULE_SCHOOLS_ADDSCHOOL", "Adicionar Escola");
define("_MODULE_SCHOOLS_EDITSCHOOL","Editar Escola");

/* FORMS TOKENS */
define("_MODULE_SCHOOLS_NOME","Nome");
define("_MODULE_SCHOOLS_THEFIELDNAMEISMANDATORY","O campo nome é obrigatório");
define("_MODULE_SCHOOLS_RAZAO_SOCIAL","Razão Social");
define("_MODULE_SCHOOLS_THEFIELDRAZAOSOCIALISMANDATORY","O campo razão social é obrigatório");

define("_MODULE_SCHOOLS_CONTATO","Contato");
define("_MODULE_SCHOOLS_TELEFONE","Telefone");
define("_MODULE_SCHOOLS_CELULAR","Celular");
define("_MODULE_SCHOOLS_ACTIVE","Ativo");
define("_MODULE_SCHOOLS_OBSERVACOES","Observações");
define("_MODULE_SCHOOLS_CEP","Cep:");
define("_MODULE_SCHOOLS_ENDERECO","Logradouro");
define("_MODULE_SCHOOLS_NUMERO","Número");
define("_MODULE_SCHOOLS_COMPLEMENTO","Complemento");
define("_MODULE_SCHOOLS_BAIRRO","Bairro");
define("_MODULE_SCHOOLS_CIDADE","Cidade");
define("_MODULE_SCHOOLS_UF","Estado");
define("_MODULE_SCHOOLS_SAVE","Salvar");

define("_MODULE_SCHOOLS_SUCCESFULLYDELETEDSCHOOLENTRY","Escola excluída com sucesso");
define("_MODULE_SCHOOLS_SUCCESFULLYUPDATEDSCHOOLENTRY","Escola atualizada com sucesso");
define("_MODULE_SCHOOLS_PROBLEMUPDATINGSCHOOLENTRY","Ocorreu um problema ao tentar salvar a escola.");
define("_MODULE_SCHOOLS_SUCCESFULLYINSERTEDSCHOOLENTRY","Escola inserida com sucesso");
define("_MODULE_SCHOOLS_PROBLEMINSERTINGSCHOOLENTRY","Ocorreu um problema ao tentar salvar a escola.");
?>