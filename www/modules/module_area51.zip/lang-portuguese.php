<?php
define("_AREA51_NAME", "Area 51");
define("_AREA51_MAIN", "Area 51 - Ambiente de desenvolvimentos pesados");
