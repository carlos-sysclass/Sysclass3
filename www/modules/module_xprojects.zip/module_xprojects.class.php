<?php

class module_xprojects extends MagesterExtendedModule {
    // CORE MODULE FUNCTIONS
    public function getName() {
        return "XPROJECTS";
    }
    public function getPermittedRoles() {
        return array("student");
    }
    public function isLessonModule() {
        return false;
    }
    
    /* MAIN-INDEPENDENT MODULE INFO, PAGES, TEMPLATES, ETC... */
    public function getCourseDashboardLinkInfo() {
		return array(
			'title' 		=> __XPROJECTS_NAME,
        	'image'			=> "images/others/transparent.gif",
			'image_class'	=> "sprite32 sprite32-projects",
            'link'  		=> $this -> moduleBaseUrl
		);
    }
    /* BLOCK FUNCTIONS */
	public function loadCourseProjectsBlock($blockIndex = null) {
    	$smarty 		= $this->getSmartyVar();
    	$currentUser	= $this->getCurrentUser();
    	
    	// GET INTER-LESSON PROJECTS
    	
    	$this->getCourseProjects();
//		if (!isset($currentUser -> coreAccess['calendar']) || $currentUser -> coreAccess['calendar'] != 'hidden') {

    	// CHECK IF USER IS A COURSE (INTER-LESSON) GROUP
    	
    	// 
	    	$this->getParent()->appendTemplate(array(
		   		'title'			=> __XPROJECTS_COURSE_PROJECTS,
		   		'template'		=> $this->moduleBaseDir . 'templates/blocks/xprojects.projects.tpl'
	    	), $blockIndex);
//		} else {
//			return false;
//		}
		/*
    	T_CALENDAR_EVENTS
    	T_VIEW_CALENDAR
    	T_CALENDAR_OPTIONS
    	T_CALENDAR_LINK
    	*/
    	return true;
    	
    }
    public function loadCourseGroupsBlock($blockIndex = null) {
    	$smarty 		= $this->getSmartyVar();
    	$currentUser	= $this->getCurrentUser();
    	
//		if (!isset($currentUser -> coreAccess['calendar']) || $currentUser -> coreAccess['calendar'] != 'hidden') {

    	// CHECK IF USER IS A COURSE (INTER-LESSON) GROUP
    	
    	// 
	    	$this->getParent()->appendTemplate(array(
		   		'title'			=> __XPROJECTS_COURSE_GROUPS,
		   		'template'		=> $this->moduleBaseDir . 'templates/blocks/xprojects.groups.tpl'
	    	), $blockIndex);
//		} else {
//			return false;
//		}
		/*
    	T_CALENDAR_EVENTS
    	T_VIEW_CALENDAR
    	T_CALENDAR_OPTIONS
    	T_CALENDAR_LINK
    	*/
    	return true;
    	
    }
    /* ACTIONS FUNCTIONS */
    /* HOOK ACTIONS FUNCTIONS */  
    /* DATA MODEL FUNCTIONS /*/
    public function getProjectById($project_id) {
    	
    	
    }
    public function getCourseProjects($course_id = null) {
    	if (eF_checkParameter($course_id, 'id')) {
    		$editcourse = $this->getEditedCourse(null, $course_id);
    	} else {
    		$editcourse = $this->getEditedCourse();
    	}
    	if ($editedcourse) {
	    	$editcourse->course['id'];
	    	
	    	//var_dump($editcourse->getProjects());    		
    	}
    	return false;

    }
    
}
?>