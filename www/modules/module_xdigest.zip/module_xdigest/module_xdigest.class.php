<?php
class module_xdigest extends MagesterExtendedModule {
	
	public function getName() {
        return "XDIGEST";
    }
	
    public function getPermittedRoles() {
        return array("administrator","professor", "student");
    }
	
}
?>
