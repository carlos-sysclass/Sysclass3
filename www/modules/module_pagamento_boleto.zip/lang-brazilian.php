<?php
define("_MODULE_BOLETO","Administração de Boletos");


define("_MODULE_BOLETO_NEWLOGIN", "New login name");
define("_MODULE_BOLETO_SELECTUSERTOCHANGELOGINFOR", "Select user to change login for");
define("_MODULE_BOLETO_CHANGELOGIN", "Change login");
define("_MODULE_BOLETO_USERALREADYEXISTS", "A user with this login already exists");
define("_MODULE_BOLETO_OPERATIONCOMPLETEDSUCCESSFULLYBUTHEFOLLOWINGTABLESCOULDNOTBEUPDATED", "Operation completed successfully but the following tables could not be updated");
define("_MODULE_BOLETO_GLOBALLESSONSETTINGS", "Global lesson settings");
define("_MODULE_BOLETO_SQLINTERFACE", "SQL interface");
define("_MODULE_BOLETO_SQLCOMMAND", "SQL command");
define("_MODULE_BOLETO_ROWSINSET", "Rows in set");
define("_MODULE_BOLETO_QUERYOK", "Query OK");
define("_MODULE_BOLETO_ROWSAFFECTED", "rows affected");
define("_MODULE_BOLETO_EMPTYSET", "Empty set");
define("_MODULE_BOLETO_BULKCOMPLETECOURSES", "Bulk complete lessons and courses");
?>

