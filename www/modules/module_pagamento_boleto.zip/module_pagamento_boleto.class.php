<?php

/*

* Class defining the new module

* Its name should be the same as the one provided in the module.xml file

*/
class module_pagamento_boleto extends MagesterModule {
	/*
	* Mandatory function returning the name of the module
	* @return string the name of the module
	*/
	public function getName() {
		return _MODULE_BOLETO;
	}
	/*
	* Mandatory function returning an array of permitted roles from the set {"administrator", "professor", "student"}
	*
	* @return array of _magester user roles that this module applies for
	*/
	public function getPermittedRoles() {
		return array("administrator");
	}
	
	public function onNewPaymentRegistered($payment_id, $payment_type) {
		// PaymentStatus:
		// 1. registrado, 2. Emitido, 3. Pago, 4. Cancelado
		// PEGAR PRIMEIRO BOLETO COM STATUS Registrado e Gerar o Boleto
		// GERAR BOLETO NO VALOR DA PARCELA COM STATUS 2..... SETAR O STATUS PARA 3.
		
		// NÃO EMITIR NADA SE EXISTIR BOLETO COM STATUS 3.
		
	}
	
 
    public function getModule() {
    	if ($_GET['show'] == 'boleto') {
			$boleto_html = include($this -> moduleBaseDir . "classes/boleto_itau.php");
			return $boleto_html;
    	}
    	return true;
	}
	public function getSmartyTpl() {
		if ($_GET['show'] != 'boleto') {
			$smarty = $this -> getSmartyVar();
			$smarty -> assign("T_MODULE_BOLETO_BASEDIR" , $this -> moduleBaseDir);
			$smarty -> assign("T_MODULE_BOLETO_BASEURL" , $this -> moduleBaseUrl);
			$smarty -> assign("T_MODULE_BOLETO_BASELINK", $this -> moduleBaseLink);
			return $this -> moduleBaseDir . "module.tpl";
		}
		return false;
	}
}
?>
