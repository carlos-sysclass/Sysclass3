<?php
require_once (dirname(__FILE__) . '/../module_xpay/module_xpay_submodule.interface.php');

class module_xpay_boleto extends MagesterExtendedModule implements IxPaySubmodule {
	
	protected static $subModules = null;
/*	
	protected $conf = array(
		// Opção => Autorizar transação autenticada e não-autenticada
		'authorization'					=> 2,	
		'auto_capture'					=> "false",
		// [A - Débito, 1- Crédito, 2 - loja, 3 - Administradora]
		'payment_subdivision_method'	=> 3
	);
*/
	public function getName() {
		return "XPAY_BOLETO";
	}
	
	public function getPermittedRoles() {
		return array("administrator", "student");
	}
	
	/* IxPaySubmodule INTERFACE FUNCTIONS */
	public static function getInstance() {
		$currentUser = self::getCurrentUser();
	
		$defined_moduleBaseUrl 	= G_SERVERNAME . $currentUser -> getRole() . ".php" . "?ctg=module&op=" . __CLASS__;
		$defined_moduleFolder 	= __CLASS__;
	
		return new self($defined_moduleBaseUrl , $defined_moduleFolder);
	}
	
	public function getPaymentInstances() {
		return array(
			//'title'		=> __XPAY_PAYPAL_DO_PAYMENT,
			'baselink'	=> $this->moduleBaseLink,
			'default'	=> 'boleto:cef_sigcb',
			'options'	=> array (
				"cef_sigcb"	=> array(
					"name" 			=> "Boleto Bancário",
					"image_name"	=> "boleto",
					"config"		=> array($this, "getPaymentInstanceConfig") // CAN BE A CALLBACK 
				),
				"itau_extensao"	=> array(
					"name" 			=> "Boleto Bancário",
					"image_name"	=> "boleto",
					"active"		=> false,
					"config"		=> array($this, "getPaymentInstanceConfig") // CAN BE A CALLBACK 
				),
			)
		);
	}
	public function getPaymentInstanceConfig($instance_id, array $overrideOptions) {
		// RETURN ALL BOLETO METHOD DATA, BASED ON INSTANCE ID
		//$instance_id = end(explode(":", $instance_id));
		
		if (file_exists($this->moduleBaseDir . "config/" . $instance_id . ".inc")) {
			$__METHOD_SUPER_OPTIONS = $overrideOptions;
			
			$config = require($this->moduleBaseDir . "config/" . $instance_id . ".inc");
			return $config;
		}
		return false;
	}
	
	public function initPaymentProccess($negociation_id, $invoice_index, array $data) {
		// MOSTRAR O BOLETO AGORA, MÊRMÂO!!!
		//var_dump(func_get_args());
		$payInstances = $this->getPaymentInstances();
		
		if (!array_key_exists('option', $data) || !in_array($data['option'], array_keys($payInstances['options']))) {
			$indexOpt = $payInstances['default'];
		} else {
			$indexOpt = $data['option'];
		}
		//$indexOpt = end(explode(":", $indexOpt));
		
		
		$invoiceData = $this->getParent()->_getNegociationInvoiceByIndex($negociation_id, $invoice_index);
		/*
		echo '<pre>';
		var_dump($invoiceData);
		echo '</pre>';
		*/
		$payInstance = $payInstances['options'][$indexOpt];
		
		
		$datavencimento = date_create_from_format("Y-m-d H:i:s", $invoiceData['data_vencimento']);
		if (!$datavencimento) {
			$datavencimento = date_create_from_format("Y-m-d", $invoiceData['data_vencimento']);
		}

		if (!$datavencimento) {
			return false;
		}
		// Composição Nosso Numero - CEF SIGCB
		// course_id (3)
		$invoiceOptions["nosso_numero1"]	= sprintf("%03d", substr($invoiceData['course_id'], 0, 3));
		// invoice_index (3)
		$invoiceOptions["nosso_numero2"]	= sprintf("%03d", substr($invoiceData['invoice_index'], 0, 3));
		// user_id (5) + negociation_id(4)
		$invoiceOptions["nosso_numero3"] 	= sprintf("%05d%04d", substr($invoiceData['user_id'], 0, 5), substr($invoiceData['negociation_id'], 0, 4));
		
		$invoiceOptions["numero_documento"] = $invoiceData['invoice_id'];	// Num do pedido ou do documento
		$invoiceOptions["data_vencimento"] = $datavencimento->format("d/m/Y"); // Data de Vencimento do Boleto - REGRA: Formato DD/MM/AAAA
//		$dadosboleto["data_documento"] = date("d/m/Y"); // Data de emissão do Boleto
//		$dadosboleto["data_processamento"] = date("d/m/Y"); // Data de processamento do boleto (opcional)
		$invoiceOptions["valor_boleto"] = number_format($invoiceData['full_price'] - $invoiceData['paid'], 2, ",", ""); 	// Valor do Boleto - REGRA: Com vírgula e sempre com duas casas depois da virgula

		
		// DADOS DO SEU CLIENTE
//		$dadosboleto["sacado"] 		= "Andre Kucaniz";
//		$dadosboleto["endereco1"] 	= "Av Presidente Getúlio Vargas, 4547 Ap 90 / Água Verde";
//		$dadosboleto["endereco2"] 	= "Curitiba / Paraná";
		
		//var_dump($invoiceOptions);
		
		if (is_callable($payInstance['config'])) {
			$methodConfig = call_user_func($payInstance['config'], $indexOpt, $invoiceOptions);
		} else {
			$methodConfig = $payInstance['config'];
		}
		/*
		var_dump($methodConfig);
		exit;
		*/
		// INJECT USER DATA, INVOICE DATA, ETC...
		echo $boletoHTML = $this->loadPaymentInvoiceFromTpl($indexOpt, $methodConfig);
		exit;
		
		
		
		// CREATE FORM
		/*
		$smarty = $this->getSmartyVar();
		
		if (!is_object($this->getParent())) {
			$currentContext = $this;
		} else {
			$currentContext = $this->getParent();
		}
		
		$form = new HTML_QuickForm("xpay_paypal_init_payment", "post", $_SERVER['REQUEST_URI'], "", null, true);
		$form -> registerRule('checkParameter', 'callback', 'eF_checkParameter');
		
		$parcelas = array (
			"A"	=> "Débito",
			"1"	=> "Crédito À Vista",
			"2"	=> "2x c/ Juros", 
			"3"	=> "3x c/ Juros",
			"4"	=> "4x c/ Juros",
			"5"	=> "5x c/ Juros",
			"6"	=> "6x c/ Juros"
		);
		foreach($parcelas as $key => $item) {
			$form -> addElement('radio', 'qtde_parcelas', $item, $item, $key, 'class="qtde_parcelas"');
		}
		
		$form -> addElement('submit', 'xpay_paypal_submit', __XPAY_CIELO_MAKE, 'class = "button_colour round_all"');
		
		if ($form -> isSubmitted() && $form -> validate()) {
			$Pedido = $this->processPaymentForm($payment_id, $invoice_id, $form->exportValues());
			
			$this->injectJS("jquery/jquery.fancybox");
			
			$smarty -> assign("T_XPAY_CIELO_URL_AUTENTICACAO", $Pedido->urlAutenticacao);
		}
		$renderer = new HTML_QuickForm_Renderer_ArraySmarty($smarty);
		$form -> accept($renderer);
		$smarty -> assign('T_MODULE_XPAY_CIELO_FORM', $renderer -> toArray());
		
		$currentContext->appendTemplate(array(
			'title'			=> __XPAY_CIELO_DO_PAYMENT,
			'template'		=> $this->moduleBaseDir . 'templates/hook/xpay.do_payment.tpl',
			'contentclass'	=> 'blockContents',
			'options'		=> array(
			)
		), $blockIndex);
		
		
		$this->assignSmartyModuleVariables();
		
		return true;
		*/
	}
	
	private function loadPaymentInvoiceFromTpl($paymentIndex, $paymentConfig) {
		$smarty = $this->getSmartyVar();
		
		$invoiceFile = sprintf(
			"%stemplates/layouts/%s.tpl", 
			$this->moduleBaseDir,
			$paymentIndex 
		);

		$smartyFunctionsFile = sprintf(
				"%sfunctions/smarty/%s.xpay_boleto_FBarCode.php",
				$this->moduleBaseDir,
				$paymentIndex
		);
		require($smartyFunctionsFile);
		
		$smarty->register_function(
			sprintf('xpay_boleto_%s_FBarCode', $paymentIndex),
			sprintf('xpay_boleto_%s_FBarCode', $paymentIndex)
		);

		$this->assignSmartyModuleVariables();
		
		/* CUSTOM FIELDS */
		$index = "03";
		//$paymentConfig["numero_documento"] = "0000000" . $index;
		//$paymentConfig["valor_boleto"] = "1," . $index;
		$smarty->assign("T_" . strtoupper($this->getName()) . "_CFG", $paymentConfig);
		
		$boletoHTML = $smarty -> fetch($invoiceFile);
		return $boletoHTML;
	}
	public function paymentCanBeDone($payment_id, $invoice_id) {
		return true;
	}
	public function getInvoiceStatusById($payment_id, $invoice_id) {
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	/* ACTIONS FUNCTIONS */
	/*
	public function doPaymentAction() {
		// GET SUB MODULES FUNCTIONS
		var_dump($this->getSubmodules());
		
		
	}
	*/
	/* MODEL FUNCTIONS */
	/*
	public function getSubmodules() {
		if (is_null(self::$subModules)) {
			self::$subModules = array(); 
		
			$modules = ef_loadAllModules(true);
		
			foreach($modules as $module) {
				if ($module instanceof IxPaySubmodule) {
					self::$subModules[] = $module;
				}
			}
		}
		return self::$subModules;
	}
	*/
}
?>