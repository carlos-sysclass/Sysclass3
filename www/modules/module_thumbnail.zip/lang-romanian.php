<?php
define("_THUMBNAIL","Miniaturi");//Thumbnails
define("_THUMBNAIL_THUMBNAILLIST","Miniaturi lista de link-uri");//Thumbnails links list
define("_THUMBNAIL_ADDTHUMBNAIL","Adauga link-ul de pictograme");//Add thumbnail link
define("_THUMBNAIL_PREVIEW","Miniatură versiune snapshot");//Thumbnail snapshot
define("_THUMBNAIL_NAME","Miniatură legendă");//Thumbnail caption
define("_THUMBNAIL_VIDEOLINK","Miniaturi leagă aici");//Thumbnails link

define("_THUMBNAIL_PROBLEMINSERTINGTHUMBNAILENTRY","Miniaturi pictograme link-ul de intrare nu a putut fi creat");//Thumbnails thumbnail link entry could not be created
define("_THUMBNAIL_SUCCESFULLYINSERTEDTHUMBNAILENTRY","Succesfylly inserează link-ul de pictograme");//Succesfylly inserted thumbnail link
define("_THUMBNAIL_SUCCESFULLYUPDATEDTHUMBNAILENTRY","Au fost actualizate cu succes pictograme leagă aici");//Succesfully updated thumbnail link
define("_THUMBNAIL_EDITTHUMBNAIL","Editare legătură pictograme");//Edit thumbnail link
define("_THUMBNAIL_DELETETHUMBNAIL","Ştergere foto mini leagă aici");//Delete thumbnail link
define("_THUMBNAILAREYOUSUREYOUWANTTODELETEEVENT","Sunteţi sigur că doriţi să ştergeţi acest link-ul de pictograme din listă");//Are you sure you want to delete this thumbnail link from the list
define("_THUMBNAIL_SUCCESFULLYDELETEDTHUMBNAILENTRY","Miniatură link-uri a fost şters cu succes");//Thumbnail links deleted succesfully
define("_THUMBNAILNOMEETINGSCHEDULED","Miniaturi lista de pictograme este gol");//The Thumbnails thumbnail list is empty

define("_THUMBNAIL_DESCRIPTION","Descriere");//Description
define("_THUMBNAIL_THUMBNAILVIDEODATA","Miniatură de date");//Thumbnail data
define("_THUMBNAIL_MANAGEMENT","Miniatură de gestionare a");//Thumbnail management
define("_THUMBNAIL_PREVIOUS","Înapoi");//Previous
define("_THUMBNAIL_NEXT","Următorul");//Next
define("_THUMBNAIL_EXAMPLE","Exemplu");//Example
define("_THUMBNAILTHEFIELDNAMEISMANDATORY","Miniatură legendă câmp este obligatoriu");//Thumbnail caption field is mandatory
?>
