<?php
define("_THUMBNAIL","ΰ¤¥ΰ¤‚ΰ¤¬ΰ¤¨ΰ¥‡ΰ¤²");//Thumbnails
define("_THUMBNAIL_THUMBNAILLIST","ΰ¤¥ΰ¤‚ΰ¤¬ΰ¤¨ΰ¥‡ΰ¤² ΰ¤Έΰ¥‚ΰ¤ΰ¥€ ΰ¤²ΰ¤Ώΰ¤‚ΰ¤•ΰ¥ΰ¤Έ");//Thumbnails links list
define("_THUMBNAIL_ADDTHUMBNAIL","ΰ¤¥ΰ¤‚ΰ¤¬ΰ¤¨ΰ¥‡ΰ¤² ΰ¤²ΰ¤Ώΰ¤‚ΰ¤• ΰ¤ΰ¥‹ΰ¤΅ΰ¤Όΰ¥‡ΰ¤‚");//Add thumbnail link
define("_THUMBNAIL_PREVIEW","ΰ¤¥ΰ¤‚ΰ¤¬ΰ¤¨ΰ¥‡ΰ¤² ΰ¤Έΰ¥ΰ¤¨ΰ¥ΰ¤ΰ¤¶ΰ¥‰ΰ¤");//Thumbnail snapshot
define("_THUMBNAIL_NAME","ΰ¤²ΰ¤ΰ¥ΰ¤›ΰ¤µΰ¤Ώ ΰ¤¶ΰ¥€ΰ¤°ΰ¥ΰ¤·ΰ¤•");//Thumbnail caption
define("_THUMBNAIL_VIDEOLINK","ΰ¤¥ΰ¤‚ΰ¤¬ΰ¤¨ΰ¥‡ΰ¤² ΰ¤•ΰ¤΅ΰ¤Όΰ¥€");//Thumbnails link

define("_THUMBNAIL_PROBLEMINSERTINGTHUMBNAILENTRY","ΰ¤¥ΰ¤‚ΰ¤¬ΰ¤¨ΰ¥‡ΰ¤² ΰ¤¥ΰ¤‚ΰ¤¬ΰ¤¨ΰ¥‡ΰ¤² ΰ¤•ΰ¤΅ΰ¤Όΰ¥€ ΰ¤ΰ¥ΰ¤°ΰ¤µΰ¥‡ΰ¤¶ ΰ¤¨ΰ¤Ήΰ¥€ΰ¤‚ ΰ¤¬ΰ¤¨ΰ¤Ύΰ¤―ΰ¤Ύ ΰ¤ΰ¤Ύ ΰ¤Έΰ¤•ΰ¤¤ΰ¤Ύ ΰ¤Ήΰ¥");//Thumbnails thumbnail link entry could not be created
define("_THUMBNAIL_SUCCESFULLYINSERTEDTHUMBNAILENTRY","Succesfylly ΰ¤¥ΰ¤‚ΰ¤¬ΰ¤¨ΰ¥‡ΰ¤² ΰ¤•ΰ¤΅ΰ¤Όΰ¥€ ΰ¤΅ΰ¤Ύΰ¤²ΰ¤Ύ");//Succesfylly inserted thumbnail link
define("_THUMBNAIL_SUCCESFULLYUPDATEDTHUMBNAILENTRY","ΰ¤Έΰ¤«ΰ¤²ΰ¤¤ΰ¤Ύΰ¤ΰ¥‚ΰ¤°ΰ¥ΰ¤µΰ¤• ΰ¤¥ΰ¤‚ΰ¤¬ΰ¤¨ΰ¥‡ΰ¤² ΰ¤•ΰ¤΅ΰ¤Όΰ¥€ ΰ¤…ΰ¤¦ΰ¥ΰ¤―ΰ¤¤ΰ¤¨");//Succesfully updated thumbnail link
define("_THUMBNAIL_EDITTHUMBNAIL","ΰ¤Έΰ¤‚ΰ¤ΰ¤Ύΰ¤¦ΰ¤Ώΰ¤¤ ΰ¤•ΰ¤°ΰ¥‡ΰ¤‚ ΰ¤¥ΰ¤‚ΰ¤¬ΰ¤¨ΰ¥‡ΰ¤² ΰ¤•ΰ¤΅ΰ¤Όΰ¥€");//Edit thumbnail link
define("_THUMBNAIL_DELETETHUMBNAIL","ΰ¤Ήΰ¤ΰ¤Ύΰ¤ΰ¤ ΰ¤¥ΰ¤‚ΰ¤¬ΰ¤¨ΰ¥‡ΰ¤² ΰ¤•ΰ¤΅ΰ¤Όΰ¥€");//Delete thumbnail link
define("_THUMBNAILAREYOUSUREYOUWANTTODELETEEVENT","ΰ¤•ΰ¥ΰ¤―ΰ¤Ύ ΰ¤†ΰ¤ ΰ¤Έΰ¥‚ΰ¤ΰ¥€ ΰ¤Έΰ¥‡ ΰ¤‡ΰ¤Έ ΰ¤¥ΰ¤‚ΰ¤¬ΰ¤¨ΰ¥‡ΰ¤² ΰ¤²ΰ¤Ώΰ¤‚ΰ¤• ΰ¤•ΰ¥‹ ΰ¤¨ΰ¤·ΰ¥ΰ¤ ΰ¤•ΰ¤°ΰ¤¨ΰ¤Ύ ΰ¤ΰ¤Ύΰ¤Ήΰ¤¤ΰ¥‡ ΰ¤Ήΰ¥ΰ¤‚");//Are you sure you want to delete this thumbnail link from the list
define("_THUMBNAIL_SUCCESFULLYDELETEDTHUMBNAILENTRY","ΰ¤¥ΰ¤‚ΰ¤¬ΰ¤¨ΰ¥‡ΰ¤² ΰ¤Έΰ¤«ΰ¤²ΰ¤¤ΰ¤Ύΰ¤ΰ¥‚ΰ¤°ΰ¥ΰ¤µΰ¤• ΰ¤¨ΰ¤·ΰ¥ΰ¤ ΰ¤•ΰ¤° ΰ¤¦ΰ¤Ώΰ¤―ΰ¤Ύ ΰ¤—ΰ¤―ΰ¤Ύ ΰ¤²ΰ¤Ώΰ¤‚ΰ¤•");//Thumbnail links deleted succesfully
define("_THUMBNAILNOMEETINGSCHEDULED","ΰ¤‡ΰ¤Έ ΰ¤¥ΰ¤‚ΰ¤¬ΰ¤¨ΰ¥‡ΰ¤² ΰ¤¥ΰ¤‚ΰ¤¬ΰ¤¨ΰ¥‡ΰ¤² ΰ¤Έΰ¥‚ΰ¤ΰ¥€ ΰ¤–ΰ¤Ύΰ¤²ΰ¥€ ΰ¤Ήΰ¥");//The Thumbnails thumbnail list is empty

define("_THUMBNAIL_DESCRIPTION","ΰ¤µΰ¤°ΰ¥ΰ¤£ΰ¤¨");//Description
define("_THUMBNAIL_THUMBNAILVIDEODATA","ΰ¤¥ΰ¤‚ΰ¤¬ΰ¤¨ΰ¥‡ΰ¤² ΰ¤΅ΰ¥‡ΰ¤ΰ¤Ύ");//Thumbnail data
define("_THUMBNAIL_MANAGEMENT","ΰ¤¥ΰ¤‚ΰ¤¬ΰ¤¨ΰ¥‡ΰ¤² ΰ¤ΰ¥ΰ¤°ΰ¤¬ΰ¤‚ΰ¤§ΰ¤¨");//Thumbnail management
define("_THUMBNAIL_PREVIOUS","ΰ¤ΰ¤Ώΰ¤›ΰ¤²ΰ¥‡");//Previous
define("_THUMBNAIL_NEXT","ΰ¤…ΰ¤—ΰ¤²ΰ¤Ύ");//Next
define("_THUMBNAIL_EXAMPLE","ΰ¤‰ΰ¤¦ΰ¤Ύΰ¤Ήΰ¤°ΰ¤£");//Example
define("_THUMBNAILTHEFIELDNAMEISMANDATORY","ΰ¤²ΰ¤ΰ¥ΰ¤›ΰ¤µΰ¤Ώ ΰ¤¶ΰ¥€ΰ¤°ΰ¥ΰ¤·ΰ¤• ΰ¤«ΰ¥€ΰ¤²ΰ¥ΰ¤΅ ΰ¤…ΰ¤¨ΰ¤Ώΰ¤µΰ¤Ύΰ¤°ΰ¥ΰ¤― ΰ¤Ήΰ¥");//Thumbnail caption field is mandatory
?>
