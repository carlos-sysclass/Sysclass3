<?php
define("_THUMBNAIL","Miniatyrbilder");//Thumbnails
define("_THUMBNAIL_THUMBNAILLIST","Miniatyrbilder linker listen");//Thumbnails links list
define("_THUMBNAIL_ADDTHUMBNAIL","Legg til miniatyr koblingen");//Add thumbnail link
define("_THUMBNAIL_PREVIEW","Thumbnail øyeblikksbilde");//Thumbnail snapshot
define("_THUMBNAIL_NAME","Thumbnail bildetekst");//Thumbnail caption
define("_THUMBNAIL_VIDEOLINK","Miniatyrbilder koblingen");//Thumbnails link

define("_THUMBNAIL_PROBLEMINSERTINGTHUMBNAILENTRY","Miniatyrbilder miniatyr link oppføringen kunne ikke opprettes");//Thumbnails thumbnail link entry could not be created
define("_THUMBNAIL_SUCCESFULLYINSERTEDTHUMBNAILENTRY","Succesfylly settes miniatyr koblingen");//Succesfylly inserted thumbnail link
define("_THUMBNAIL_SUCCESFULLYUPDATEDTHUMBNAILENTRY","Oppdatert miniatyr koblingen");//Succesfully updated thumbnail link
define("_THUMBNAIL_EDITTHUMBNAIL","Rediger miniatyr koblingen");//Edit thumbnail link
define("_THUMBNAIL_DELETETHUMBNAIL","Slett miniatyr koblingen");//Delete thumbnail link
define("_THUMBNAILAREYOUSUREYOUWANTTODELETEEVENT","Er du sikker på at du vil slette denne miniatyr link fra listen");//Are you sure you want to delete this thumbnail link from the list
define("_THUMBNAIL_SUCCESFULLYDELETEDTHUMBNAILENTRY","Thumbnail lenker ble slettet");//Thumbnail links deleted succesfully
define("_THUMBNAILNOMEETINGSCHEDULED","Miniatyrbildene miniatyr er tom");//The Thumbnails thumbnail list is empty

define("_THUMBNAIL_DESCRIPTION","Beskrivelse");//Description
define("_THUMBNAIL_THUMBNAILVIDEODATA","Thumbnail data");//Thumbnail data
define("_THUMBNAIL_MANAGEMENT","Thumbnail ledelse");//Thumbnail management
define("_THUMBNAIL_PREVIOUS","Forrige");//Previous
define("_THUMBNAIL_NEXT","Neste");//Next
define("_THUMBNAIL_EXAMPLE","Eksempel");//Example
define("_THUMBNAILTHEFIELDNAMEISMANDATORY","Thumbnail bildetekst feltet er obligatorisk");//Thumbnail caption field is mandatory
?>
