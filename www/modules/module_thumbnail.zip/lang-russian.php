<?php
define("_THUMBNAIL","Эскизы");//Thumbnails
define("_THUMBNAIL_THUMBNAILLIST","Эскизы списка ссылок");//Thumbnails links list
define("_THUMBNAIL_ADDTHUMBNAIL","Добавить ссылку эскизов");//Add thumbnail link
define("_THUMBNAIL_PREVIEW","Эскиз снимок");//Thumbnail snapshot
define("_THUMBNAIL_NAME","Эскиз подпись");//Thumbnail caption
define("_THUMBNAIL_VIDEOLINK","Эскизы связь");//Thumbnails link

define("_THUMBNAIL_PROBLEMINSERTINGTHUMBNAILENTRY","Эскизы эскизов ссылка вступление не может быть создана");//Thumbnails thumbnail link entry could not be created
define("_THUMBNAIL_SUCCESFULLYINSERTEDTHUMBNAILENTRY","Succesfylly вставить ссылку эскизов");//Succesfylly inserted thumbnail link
define("_THUMBNAIL_SUCCESFULLYUPDATEDTHUMBNAILENTRY","Успешно обновлена эскизов связь");//Succesfully updated thumbnail link
define("_THUMBNAIL_EDITTHUMBNAIL","Изменить эскизов связь");//Edit thumbnail link
define("_THUMBNAIL_DELETETHUMBNAIL","Удалить ссылку эскизов");//Delete thumbnail link
define("_THUMBNAILAREYOUSUREYOUWANTTODELETEEVENT","Вы уверены, что хотите удалить эту миниатюру ссылке из списка");//Are you sure you want to delete this thumbnail link from the list
define("_THUMBNAIL_SUCCESFULLYDELETEDTHUMBNAILENTRY","Эскиз связей успешно удален");//Thumbnail links deleted succesfully
define("_THUMBNAILNOMEETINGSCHEDULED","Эскизы эскизов список пуст");//The Thumbnails thumbnail list is empty

define("_THUMBNAIL_DESCRIPTION","Описание");//Description
define("_THUMBNAIL_THUMBNAILVIDEODATA","Эскиз данных");//Thumbnail data
define("_THUMBNAIL_MANAGEMENT","Эскиз управления");//Thumbnail management
define("_THUMBNAIL_PREVIOUS","Предыдущая");//Previous
define("_THUMBNAIL_NEXT","Следующий");//Next
define("_THUMBNAIL_EXAMPLE","Пример");//Example
define("_THUMBNAILTHEFIELDNAMEISMANDATORY","Эскиз подпись поле является обязательным");//Thumbnail caption field is mandatory
?>
