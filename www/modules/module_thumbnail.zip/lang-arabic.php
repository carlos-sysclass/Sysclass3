<?php
define("_THUMBNAIL","أظافر الإبهام");//Thumbnails
define("_THUMBNAIL_THUMBNAILLIST","الصور المصغرة الصلات القائمة");//Thumbnails links list
define("_THUMBNAIL_ADDTHUMBNAIL","أضف المصغرة صلة");//Add thumbnail link
define("_THUMBNAIL_PREVIEW","صورة مصغرة لقطة");//Thumbnail snapshot
define("_THUMBNAIL_NAME","صورة مصغرة مصورة");//Thumbnail caption
define("_THUMBNAIL_VIDEOLINK","الصور المصغرة صلة");//Thumbnails link

define("_THUMBNAIL_PROBLEMINSERTINGTHUMBNAILENTRY","الصور المصغرة المصغرة دخول صلة لا يمكن خلق");//Thumbnails thumbnail link entry could not be created
define("_THUMBNAIL_SUCCESFULLYINSERTEDTHUMBNAILENTRY","Succesfylly تدرج المصغرة صلة");//Succesfylly inserted thumbnail link
define("_THUMBNAIL_SUCCESFULLYUPDATEDTHUMBNAILENTRY","نجحت عملية تحديث المصغرة صلة");//Succesfully updated thumbnail link
define("_THUMBNAIL_EDITTHUMBNAIL","تحرير المصغرة صلة");//Edit thumbnail link
define("_THUMBNAIL_DELETETHUMBNAIL","حذف المصغرة صلة");//Delete thumbnail link
define("_THUMBNAILAREYOUSUREYOUWANTTODELETEEVENT","هل أنت متأكد من أنك تريد حذف هذه الصورة المصغرة وصلة من القائمة");//Are you sure you want to delete this thumbnail link from the list
define("_THUMBNAIL_SUCCESFULLYDELETEDTHUMBNAILENTRY","صورة مصغرة حذف الروابط بنجاح");//Thumbnail links deleted succesfully
define("_THUMBNAILNOMEETINGSCHEDULED","الصور المصغرة المصغرة القائمة فارغة");//The Thumbnails thumbnail list is empty

define("_THUMBNAIL_DESCRIPTION","الوصف");//Description
define("_THUMBNAIL_THUMBNAILVIDEODATA","صورة مصغرة البيانات");//Thumbnail data
define("_THUMBNAIL_MANAGEMENT","الإدارة المصغرة");//Thumbnail management
define("_THUMBNAIL_PREVIOUS","السابق");//Previous
define("_THUMBNAIL_NEXT","التالي");//Next
define("_THUMBNAIL_EXAMPLE","مثال");//Example
define("_THUMBNAILTHEFIELDNAMEISMANDATORY","تغطية مصورة الميدان هو صورة مصغرة إلزامية");//Thumbnail caption field is mandatory
?>
