<?php
define("_THUMBNAIL","Miniatury");//Thumbnails
define("_THUMBNAIL_THUMBNAILLIST","Miniatury odkazy seznam");//Thumbnails links list
define("_THUMBNAIL_ADDTHUMBNAIL","Přidat odkaz");//Add thumbnail link
define("_THUMBNAIL_PREVIEW","Thumbnail Snapshot");//Thumbnail snapshot
define("_THUMBNAIL_NAME","Thumbnail Caption");//Thumbnail caption
define("_THUMBNAIL_VIDEOLINK","Miniatury odkaz");//Thumbnails link

define("_THUMBNAIL_PROBLEMINSERTINGTHUMBNAILENTRY","Miniatury thumbnail odkaz vstupu nemohla být vytvořena");//Thumbnails thumbnail link entry could not be created
define("_THUMBNAIL_SUCCESFULLYINSERTEDTHUMBNAILENTRY","Succesfylly zní thumbnail odkaz");//Succesfylly inserted thumbnail link
define("_THUMBNAIL_SUCCESFULLYUPDATEDTHUMBNAILENTRY","Úspěšně aktualizován thumbnail odkaz");//Succesfully updated thumbnail link
define("_THUMBNAIL_EDITTHUMBNAIL","Upravit náhled odkaz");//Edit thumbnail link
define("_THUMBNAIL_DELETETHUMBNAIL","Odstranit miniaturu odkaz");//Delete thumbnail link
define("_THUMBNAILAREYOUSUREYOUWANTTODELETEEVENT","Jste si jisti, že chcete smazat tuto miniaturu odkaz ze seznamu");//Are you sure you want to delete this thumbnail link from the list
define("_THUMBNAIL_SUCCESFULLYDELETEDTHUMBNAILENTRY","Thumbnail odkazy úspěšně smazána");//Thumbnail links deleted succesfully
define("_THUMBNAILNOMEETINGSCHEDULED","Náhled náhled seznam je prázdný");//The Thumbnails thumbnail list is empty

define("_THUMBNAIL_DESCRIPTION","Popis");//Description
define("_THUMBNAIL_THUMBNAILVIDEODATA","Thumbnail údajů");//Thumbnail data
define("_THUMBNAIL_MANAGEMENT","Thumbnail řízení");//Thumbnail management
define("_THUMBNAIL_PREVIOUS","Předchozí");//Previous
define("_THUMBNAIL_NEXT","Příští");//Next
define("_THUMBNAIL_EXAMPLE","Příklad");//Example
define("_THUMBNAILTHEFIELDNAMEISMANDATORY","Thumbnail popisek pole je povinné");//Thumbnail caption field is mandatory
?>
