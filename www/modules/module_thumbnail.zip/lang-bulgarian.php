<?php
define("_THUMBNAIL","Кадри");//Thumbnails
define("_THUMBNAIL_THUMBNAILLIST","Кадри връзки списък");//Thumbnails links list
define("_THUMBNAIL_ADDTHUMBNAIL","Добавете картинка линк");//Add thumbnail link
define("_THUMBNAIL_PREVIEW","Кадър за снимка");//Thumbnail snapshot
define("_THUMBNAIL_NAME","Кадър надпис");//Thumbnail caption
define("_THUMBNAIL_VIDEOLINK","Кадри линк");//Thumbnails link

define("_THUMBNAIL_PROBLEMINSERTINGTHUMBNAILENTRY","Кадри картинка влизане връзка не може да бъде създаден");//Thumbnails thumbnail link entry could not be created
define("_THUMBNAIL_SUCCESFULLYINSERTEDTHUMBNAILENTRY","Succesfylly добавя картинка линк");//Succesfylly inserted thumbnail link
define("_THUMBNAIL_SUCCESFULLYUPDATEDTHUMBNAILENTRY","Актуализиран успешно картинка линк");//Succesfully updated thumbnail link
define("_THUMBNAIL_EDITTHUMBNAIL","Редактиране картинка линк");//Edit thumbnail link
define("_THUMBNAIL_DELETETHUMBNAIL","Изтриване на картинка линк");//Delete thumbnail link
define("_THUMBNAILAREYOUSUREYOUWANTTODELETEEVENT","Сигурни ли сте, че искате да изтриете тази картинка връзката от списъка");//Are you sure you want to delete this thumbnail link from the list
define("_THUMBNAIL_SUCCESFULLYDELETEDTHUMBNAILENTRY","Кадър връзки изтрит успешно");//Thumbnail links deleted succesfully
define("_THUMBNAILNOMEETINGSCHEDULED","Кадрите картинка Списъкът е празен");//The Thumbnails thumbnail list is empty

define("_THUMBNAIL_DESCRIPTION","Описание");//Description
define("_THUMBNAIL_THUMBNAILVIDEODATA","Кадър данни");//Thumbnail data
define("_THUMBNAIL_MANAGEMENT","Кадър управление");//Thumbnail management
define("_THUMBNAIL_PREVIOUS","Предишна");//Previous
define("_THUMBNAIL_NEXT","Следващ");//Next
define("_THUMBNAIL_EXAMPLE","Пример");//Example
define("_THUMBNAILTHEFIELDNAMEISMANDATORY","Кадър надпис поле е задължително");//Thumbnail caption field is mandatory
?>
