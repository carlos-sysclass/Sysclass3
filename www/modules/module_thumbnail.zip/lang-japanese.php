<?php
define("_THUMBNAIL","サムネイル");//Thumbnails
define("_THUMBNAIL_THUMBNAILLIST","サムネイル一覧のリンク");//Thumbnails links list
define("_THUMBNAIL_ADDTHUMBNAIL","サムネイルのリンクを追加");//Add thumbnail link
define("_THUMBNAIL_PREVIEW","サムネイルのスナップショット");//Thumbnail snapshot
define("_THUMBNAIL_NAME","サムネイルのキャプション");//Thumbnail caption
define("_THUMBNAIL_VIDEOLINK","サムネイルのリンク");//Thumbnails link

define("_THUMBNAIL_PROBLEMINSERTINGTHUMBNAILENTRY","サムネイルサムネイルリンクのエントリを作成できませんでした");//Thumbnails thumbnail link entry could not be created
define("_THUMBNAIL_SUCCESFULLYINSERTEDTHUMBNAILENTRY","Succesfyllyサムネイルリンクを挿入");//Succesfylly inserted thumbnail link
define("_THUMBNAIL_SUCCESFULLYUPDATEDTHUMBNAILENTRY","サムネイルリンクが正常に更新");//Succesfully updated thumbnail link
define("_THUMBNAIL_EDITTHUMBNAIL","編集サムネイルリンク");//Edit thumbnail link
define("_THUMBNAIL_DELETETHUMBNAIL","サムネイルのリンクを削除");//Delete thumbnail link
define("_THUMBNAILAREYOUSUREYOUWANTTODELETEEVENT","あなたのリストから、このサムネイルリンクを削除してもよろしいです");//Are you sure you want to delete this thumbnail link from the list
define("_THUMBNAIL_SUCCESFULLYDELETEDTHUMBNAILENTRY","サムネイルが正常に削除されたリンク");//Thumbnail links deleted succesfully
define("_THUMBNAILNOMEETINGSCHEDULED","サムネイルサムネイルの一覧は空です");//The Thumbnails thumbnail list is empty

define("_THUMBNAIL_DESCRIPTION","説明");//Description
define("_THUMBNAIL_THUMBNAILVIDEODATA","サムネイルのデータ");//Thumbnail data
define("_THUMBNAIL_MANAGEMENT","サムネイル管理");//Thumbnail management
define("_THUMBNAIL_PREVIOUS","前");//Previous
define("_THUMBNAIL_NEXT","次の");//Next
define("_THUMBNAIL_EXAMPLE","例");//Example
define("_THUMBNAILTHEFIELDNAMEISMANDATORY","サムネイルのキャプションフィールドは必須である");//Thumbnail caption field is mandatory
?>
