<?php
define("_THUMBNAIL","Miniatyrer");//Thumbnails
define("_THUMBNAIL_THUMBNAILLIST","Miniatyrer länkar lista");//Thumbnails links list
define("_THUMBNAIL_ADDTHUMBNAIL","Lägg till miniatyrbild länk");//Add thumbnail link
define("_THUMBNAIL_PREVIEW","Thumbnail ögonblicksbild");//Thumbnail snapshot
define("_THUMBNAIL_NAME","Thumbnail bildtext");//Thumbnail caption
define("_THUMBNAIL_VIDEOLINK","Miniatyrer länk");//Thumbnails link

define("_THUMBNAIL_PROBLEMINSERTINGTHUMBNAILENTRY","Miniatyrer thumbnail länk posten kunde inte skapas");//Thumbnails thumbnail link entry could not be created
define("_THUMBNAIL_SUCCESFULLYINSERTEDTHUMBNAILENTRY","Succesfylly införas thumbnail länk");//Succesfylly inserted thumbnail link
define("_THUMBNAIL_SUCCESFULLYUPDATEDTHUMBNAILENTRY","Har uppdaterats thumbnail länk");//Succesfully updated thumbnail link
define("_THUMBNAIL_EDITTHUMBNAIL","Redigera miniatyrbild länk");//Edit thumbnail link
define("_THUMBNAIL_DELETETHUMBNAIL","Ta bort miniatyrbild länk");//Delete thumbnail link
define("_THUMBNAILAREYOUSUREYOUWANTTODELETEEVENT","Är du säker på att du vill ta bort den här thumbnail länk från listan");//Are you sure you want to delete this thumbnail link from the list
define("_THUMBNAIL_SUCCESFULLYDELETEDTHUMBNAILENTRY","Thumbnail länkar raderats");//Thumbnail links deleted succesfully
define("_THUMBNAILNOMEETINGSCHEDULED","Miniatyrerna thumbnail listan är tom");//The Thumbnails thumbnail list is empty

define("_THUMBNAIL_DESCRIPTION","Beskrivning");//Description
define("_THUMBNAIL_THUMBNAILVIDEODATA","Thumbnail uppgifter");//Thumbnail data
define("_THUMBNAIL_MANAGEMENT","Thumbnail förvaltning");//Thumbnail management
define("_THUMBNAIL_PREVIOUS","Föregående");//Previous
define("_THUMBNAIL_NEXT","Nästa");//Next
define("_THUMBNAIL_EXAMPLE","Exempel");//Example
define("_THUMBNAILTHEFIELDNAMEISMANDATORY","Thumbnail bildtext fältet är obligatoriskt");//Thumbnail caption field is mandatory
?>
