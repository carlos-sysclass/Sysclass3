<?php
define("_THUMBNAIL","縮略圖");//Thumbnails
define("_THUMBNAIL_THUMBNAILLIST","縮略圖鏈接列表");//Thumbnails links list
define("_THUMBNAIL_ADDTHUMBNAIL","添加縮略圖鏈接");//Add thumbnail link
define("_THUMBNAIL_PREVIEW","縮圖快照");//Thumbnail snapshot
define("_THUMBNAIL_NAME","標題縮略圖");//Thumbnail caption
define("_THUMBNAIL_VIDEOLINK","縮略圖鏈接");//Thumbnails link

define("_THUMBNAIL_PROBLEMINSERTINGTHUMBNAILENTRY","縮略圖縮略圖鏈接進入無法建立");//Thumbnails thumbnail link entry could not be created
define("_THUMBNAIL_SUCCESFULLYINSERTEDTHUMBNAILENTRY","Succesfylly插入縮略圖鏈接");//Succesfylly inserted thumbnail link
define("_THUMBNAIL_SUCCESFULLYUPDATEDTHUMBNAILENTRY","成功更新縮略圖鏈接");//Succesfully updated thumbnail link
define("_THUMBNAIL_EDITTHUMBNAIL","編輯縮略圖鏈接");//Edit thumbnail link
define("_THUMBNAIL_DELETETHUMBNAIL","刪除縮略圖鏈接");//Delete thumbnail link
define("_THUMBNAILAREYOUSUREYOUWANTTODELETEEVENT","您是否確實要刪除此縮略圖鏈接的名單");//Are you sure you want to delete this thumbnail link from the list
define("_THUMBNAIL_SUCCESFULLYDELETEDTHUMBNAILENTRY","縮略圖鏈接刪除成功");//Thumbnail links deleted succesfully
define("_THUMBNAILNOMEETINGSCHEDULED","縮略圖縮略圖列表是空的");//The Thumbnails thumbnail list is empty

define("_THUMBNAIL_DESCRIPTION","說明");//Description
define("_THUMBNAIL_THUMBNAILVIDEODATA","縮略圖數據");//Thumbnail data
define("_THUMBNAIL_MANAGEMENT","縮略圖管理");//Thumbnail management
define("_THUMBNAIL_PREVIOUS","上一頁");//Previous
define("_THUMBNAIL_NEXT","下一個");//Next
define("_THUMBNAIL_EXAMPLE","例如");//Example
define("_THUMBNAILTHEFIELDNAMEISMANDATORY","標題縮略圖領域是強制性的");//Thumbnail caption field is mandatory
?>
