<?php
define("_THUMBNAIL","Pikkukuvat");//Thumbnails
define("_THUMBNAIL_THUMBNAILLIST","Pikkukuvat linkkien luettelo");//Thumbnails links list
define("_THUMBNAIL_ADDTHUMBNAIL","Lisää pikkukuva linkki");//Add thumbnail link
define("_THUMBNAIL_PREVIEW","Thumbnail tilannekuvan");//Thumbnail snapshot
define("_THUMBNAIL_NAME","Thumbnail kuvateksti");//Thumbnail caption
define("_THUMBNAIL_VIDEOLINK","Pikkukuvat linkki");//Thumbnails link

define("_THUMBNAIL_PROBLEMINSERTINGTHUMBNAILENTRY","Pikkukuvat thumbnail linkki merkintä ei voi luoda");//Thumbnails thumbnail link entry could not be created
define("_THUMBNAIL_SUCCESFULLYINSERTEDTHUMBNAILENTRY","Succesfylly Lisätään thumbnail linkki");//Succesfylly inserted thumbnail link
define("_THUMBNAIL_SUCCESFULLYUPDATEDTHUMBNAILENTRY","Päivittäminen onnistui thumbnail linkki");//Succesfully updated thumbnail link
define("_THUMBNAIL_EDITTHUMBNAIL","Muokkaa thumbnail linkki");//Edit thumbnail link
define("_THUMBNAIL_DELETETHUMBNAIL","Poista pikkukuva linkki");//Delete thumbnail link
define("_THUMBNAILAREYOUSUREYOUWANTTODELETEEVENT","Oletko varma että haluat poistaa tämän thumbnail linkki listalta");//Are you sure you want to delete this thumbnail link from the list
define("_THUMBNAIL_SUCCESFULLYDELETEDTHUMBNAILENTRY","Thumbnail linkkejä poistettu");//Thumbnail links deleted succesfully
define("_THUMBNAILNOMEETINGSCHEDULED","Pikkukuvia thumbnail on tyhjä");//The Thumbnails thumbnail list is empty

define("_THUMBNAIL_DESCRIPTION","Kuvaus");//Description
define("_THUMBNAIL_THUMBNAILVIDEODATA","Thumbnail tiedot");//Thumbnail data
define("_THUMBNAIL_MANAGEMENT","Thumbnail hallinta");//Thumbnail management
define("_THUMBNAIL_PREVIOUS","Edellinen");//Previous
define("_THUMBNAIL_NEXT","Seuraava");//Next
define("_THUMBNAIL_EXAMPLE","Esimerkki");//Example
define("_THUMBNAILTHEFIELDNAMEISMANDATORY","Thumbnail kuvateksti kenttä on pakollinen");//Thumbnail caption field is mandatory
?>
