<?php
define("_THUMBNAIL","Miniaturer");//Thumbnails
define("_THUMBNAIL_THUMBNAILLIST","Miniaturer links liste");//Thumbnails links list
define("_THUMBNAIL_ADDTHUMBNAIL","Tilføj miniature link");//Add thumbnail link
define("_THUMBNAIL_PREVIEW","Thumbnail øjebliksbillede");//Thumbnail snapshot
define("_THUMBNAIL_NAME","Thumbnail billedtekst");//Thumbnail caption
define("_THUMBNAIL_VIDEOLINK","Miniaturer link");//Thumbnails link

define("_THUMBNAIL_PROBLEMINSERTINGTHUMBNAILENTRY","Miniaturer thumbnail link indrejse kunne ikke oprettes");//Thumbnails thumbnail link entry could not be created
define("_THUMBNAIL_SUCCESFULLYINSERTEDTHUMBNAILENTRY","Succesfylly indsættes thumbnail link");//Succesfylly inserted thumbnail link
define("_THUMBNAIL_SUCCESFULLYUPDATEDTHUMBNAILENTRY","Blevet opdateret thumbnail link");//Succesfully updated thumbnail link
define("_THUMBNAIL_EDITTHUMBNAIL","Rediger thumbnail link");//Edit thumbnail link
define("_THUMBNAIL_DELETETHUMBNAIL","Slet thumbnail link");//Delete thumbnail link
define("_THUMBNAILAREYOUSUREYOUWANTTODELETEEVENT","Er du sikker på du vil slette denne thumbnail link fra listen");//Are you sure you want to delete this thumbnail link from the list
define("_THUMBNAIL_SUCCESFULLYDELETEDTHUMBNAILENTRY","Thumbnail links slettet med succes!");//Thumbnail links deleted succesfully
define("_THUMBNAILNOMEETINGSCHEDULED","Den Thumbnails thumbnail liste er tom");//The Thumbnails thumbnail list is empty

define("_THUMBNAIL_DESCRIPTION","Beskrivelse");//Description
define("_THUMBNAIL_THUMBNAILVIDEODATA","Thumbnail data");//Thumbnail data
define("_THUMBNAIL_MANAGEMENT","Thumbnail forvaltning");//Thumbnail management
define("_THUMBNAIL_PREVIOUS","Forrige");//Previous
define("_THUMBNAIL_NEXT","Næste");//Next
define("_THUMBNAIL_EXAMPLE","Eksempel");//Example
define("_THUMBNAILTHEFIELDNAMEISMANDATORY","Thumbnail billedtekst felt er obligatorisk");//Thumbnail caption field is mandatory
?>
