<?php
define("_THUMBNAIL","Thumbnails");//Thumbnails
define("_THUMBNAIL_THUMBNAILLIST","Thumbnails Links-Liste");//Thumbnails links list
define("_THUMBNAIL_ADDTHUMBNAIL","Thumbnail-Link hinzufügen");//Add thumbnail link
define("_THUMBNAIL_PREVIEW","Thumbnail-Snapshot");//Thumbnail snapshot
define("_THUMBNAIL_NAME","Thumbnail Bildunterschrift");//Thumbnail caption
define("_THUMBNAIL_VIDEOLINK","Thumbnails Link");//Thumbnails link

define("_THUMBNAIL_PROBLEMINSERTINGTHUMBNAILENTRY","Thumbnail-Link Eintrag konnte nicht erstellt werden");//Thumbnails thumbnail link entry could not be created
define("_THUMBNAIL_SUCCESFULLYINSERTEDTHUMBNAILENTRY","Thumbnail-Link erfolgreich eingefügt");//Succesfylly inserted thumbnail link
define("_THUMBNAIL_SUCCESFULLYUPDATEDTHUMBNAILENTRY","Thumbnail-Link erfolgreich aktualisiert");//Succesfully updated thumbnail link
define("_THUMBNAIL_EDITTHUMBNAIL","Thumbnail-Link bearbeiten");//Edit thumbnail link
define("_THUMBNAIL_DELETETHUMBNAIL","Thumbnail-Link löschen");//Delete thumbnail link
define("_THUMBNAILAREYOUSUREYOUWANTTODELETEEVENT","Sind Sie sicher, dass Sie diesen Thumbnail-Link aus der Liste löschen möchten");//Are you sure you want to delete this thumbnail link from the list
define("_THUMBNAIL_SUCCESFULLYDELETEDTHUMBNAILENTRY","Thumbnail-Links erfolgreich gelöscht");//Thumbnail links deleted succesfully
define("_THUMBNAILNOMEETINGSCHEDULED","Die Thumbnail-Liste ist leer");//The Thumbnails thumbnail list is empty

define("_THUMBNAIL_DESCRIPTION","Beschreibung");//Description
define("_THUMBNAIL_THUMBNAILVIDEODATA","Thumbnail-Daten");//Thumbnail data
define("_THUMBNAIL_MANAGEMENT","Thumbnail-Management");//Thumbnail management
define("_THUMBNAIL_PREVIOUS","Zurück");//Previous
define("_THUMBNAIL_NEXT","Nächster");//Next
define("_THUMBNAIL_EXAMPLE","Beispiel");//Example
define("_THUMBNAILTHEFIELDNAMEISMANDATORY","Thumbnail Bildunterschrifts-Feld ist obligatorisch");//Thumbnail caption field is mandatory
?>
