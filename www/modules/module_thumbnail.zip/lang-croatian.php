<?php
define("_THUMBNAIL","Thumbnails");//Thumbnails
define("_THUMBNAIL_THUMBNAILLIST","Thumbnails Lista linkova");//Thumbnails links list
define("_THUMBNAIL_ADDTHUMBNAIL","Dodaj link sličice");//Add thumbnail link
define("_THUMBNAIL_PREVIEW","Thumbnail snimak");//Thumbnail snapshot
define("_THUMBNAIL_NAME","Thumbnail naslov");//Thumbnail caption
define("_THUMBNAIL_VIDEOLINK","Thumbnails link");//Thumbnails link

define("_THUMBNAIL_PROBLEMINSERTINGTHUMBNAILENTRY","Thumbnails sličice vezu unos nije mogla biti kreirana");//Thumbnails thumbnail link entry could not be created
define("_THUMBNAIL_SUCCESFULLYINSERTEDTHUMBNAILENTRY","Succesfylly umetnuti sličice link");//Succesfylly inserted thumbnail link
define("_THUMBNAIL_SUCCESFULLYUPDATEDTHUMBNAILENTRY","Uspješno ažuriran sličice link");//Succesfully updated thumbnail link
define("_THUMBNAIL_EDITTHUMBNAIL","Uredi sličice link");//Edit thumbnail link
define("_THUMBNAIL_DELETETHUMBNAIL","Obriši sličice link");//Delete thumbnail link
define("_THUMBNAILAREYOUSUREYOUWANTTODELETEEVENT","Jeste li sigurni da želite izbrisati ovu sličicu vezu s popisa");//Are you sure you want to delete this thumbnail link from the list
define("_THUMBNAIL_SUCCESFULLYDELETEDTHUMBNAILENTRY","Thumbnail linkovi uspješno obrisan");//Thumbnail links deleted succesfully
define("_THUMBNAILNOMEETINGSCHEDULED","U Thumbnails sličice Lista je prazna");//The Thumbnails thumbnail list is empty

define("_THUMBNAIL_DESCRIPTION","Opis");//Description
define("_THUMBNAIL_THUMBNAILVIDEODATA","Thumbnail podataka");//Thumbnail data
define("_THUMBNAIL_MANAGEMENT","Thumbnail upravljanje");//Thumbnail management
define("_THUMBNAIL_PREVIOUS","Prethodna");//Previous
define("_THUMBNAIL_NEXT","Dalje");//Next
define("_THUMBNAIL_EXAMPLE","Primjer");//Example
define("_THUMBNAILTHEFIELDNAMEISMANDATORY","Thumbnail naslov polje je obavezan");//Thumbnail caption field is mandatory
?>
