<?php
define("_THUMBNAIL","Thumbnails");
define("_THUMBNAIL_THUMBNAILLIST", "Thumbnails links list");
define("_THUMBNAIL_ADDTHUMBNAIL", "Add thumbnail link");
define("_THUMBNAIL_PREVIEW", "Thumbnail snapshot");
define("_THUMBNAIL_NAME", "Thumbnail caption");
define("_THUMBNAIL_VIDEOLINK", "Thumbnails link");

define("_THUMBNAIL_PROBLEMINSERTINGTHUMBNAILENTRY", "Thumbnails thumbnail link entry could not be created");
define("_THUMBNAIL_SUCCESFULLYINSERTEDTHUMBNAILENTRY", "Succesfylly inserted thumbnail link");
define("_THUMBNAIL_SUCCESFULLYUPDATEDTHUMBNAILENTRY", "Succesfully updated thumbnail link");
define("_THUMBNAIL_EDITTHUMBNAIL", "Edit thumbnail link");
define("_THUMBNAIL_DELETETHUMBNAIL", "Delete thumbnail link");
define("_THUMBNAILAREYOUSUREYOUWANTTODELETEEVENT","Are you sure you want to delete this thumbnail link from the list");
define("_THUMBNAIL_SUCCESFULLYDELETEDTHUMBNAILENTRY","Thumbnail links deleted succesfully");
define("_THUMBNAILNOMEETINGSCHEDULED","The Thumbnails thumbnail list is empty");

define("_THUMBNAIL_DESCRIPTION", "Description");
define("_THUMBNAIL_THUMBNAILVIDEODATA","Thumbnail data");
define("_THUMBNAIL_MANAGEMENT","Thumbnail management");
define("_THUMBNAIL_PREVIOUS", "Previous");
define("_THUMBNAIL_NEXT", "Next");
define("_THUMBNAIL_EXAMPLE", "Example");
define("_THUMBNAILTHEFIELDNAMEISMANDATORY","Thumbnail caption field is mandatory");
?>