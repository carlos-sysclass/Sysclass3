<?php
define("_THUMBNAIL","Miniatury");//Thumbnails
define("_THUMBNAIL_THUMBNAILLIST","Miniatury Lista linków");//Thumbnails links list
define("_THUMBNAIL_ADDTHUMBNAIL","Dodaj miniaturę link");//Add thumbnail link
define("_THUMBNAIL_PREVIEW","Miniatura migawki");//Thumbnail snapshot
define("_THUMBNAIL_NAME","Miniatura podpis");//Thumbnail caption
define("_THUMBNAIL_VIDEOLINK","Miniatury link");//Thumbnails link

define("_THUMBNAIL_PROBLEMINSERTINGTHUMBNAILENTRY","Miniatury miniatury link wpis nie może zostać utworzony");//Thumbnails thumbnail link entry could not be created
define("_THUMBNAIL_SUCCESFULLYINSERTEDTHUMBNAILENTRY","Succesfylly dodaje miniaturę link");//Succesfylly inserted thumbnail link
define("_THUMBNAIL_SUCCESFULLYUPDATEDTHUMBNAILENTRY","Pomyślnie zaktualizowane miniaturę link");//Succesfully updated thumbnail link
define("_THUMBNAIL_EDITTHUMBNAIL","Edytuj miniaturę link");//Edit thumbnail link
define("_THUMBNAIL_DELETETHUMBNAIL","Usuń miniaturę link");//Delete thumbnail link
define("_THUMBNAILAREYOUSUREYOUWANTTODELETEEVENT","Czy na pewno chcesz usunąć ten link miniaturę z listy");//Are you sure you want to delete this thumbnail link from the list
define("_THUMBNAIL_SUCCESFULLYDELETEDTHUMBNAILENTRY","Miniatura linki została usunięta");//Thumbnail links deleted succesfully
define("_THUMBNAILNOMEETINGSCHEDULED","Miniatury miniatury lista jest pusta");//The Thumbnails thumbnail list is empty

define("_THUMBNAIL_DESCRIPTION","Opis");//Description
define("_THUMBNAIL_THUMBNAILVIDEODATA","Miniatura danych");//Thumbnail data
define("_THUMBNAIL_MANAGEMENT","Miniatura zarządzania");//Thumbnail management
define("_THUMBNAIL_PREVIOUS","Poprzednia");//Previous
define("_THUMBNAIL_NEXT","Następny");//Next
define("_THUMBNAIL_EXAMPLE","Przykład");//Example
define("_THUMBNAILTHEFIELDNAMEISMANDATORY","Miniatura napis pola obowiązkowe");//Thumbnail caption field is mandatory
?>
