<?php
define("_THUMBNAIL","Miniaturas");//Thumbnails
define("_THUMBNAIL_THUMBNAILLIST","Lista de links miniaturas");//Thumbnails links list
define("_THUMBNAIL_ADDTHUMBNAIL","Adicionar link da miniatura");//Add thumbnail link
define("_THUMBNAIL_PREVIEW","Miniatura instantâneo");//Thumbnail snapshot
define("_THUMBNAIL_NAME","Legenda da miniatura");//Thumbnail caption
define("_THUMBNAIL_VIDEOLINK","Link da miniatura");//Thumbnails link

define("_THUMBNAIL_PROBLEMINSERTINGTHUMBNAILENTRY","Link da miniatura não pode ser criado");//Thumbnails thumbnail link entry could not be created
define("_THUMBNAIL_SUCCESFULLYINSERTEDTHUMBNAILENTRY","Link da miniatura inserido com sucesso");//Succesfylly inserted thumbnail link
define("_THUMBNAIL_SUCCESFULLYUPDATEDTHUMBNAILENTRY","Link da miniatura atualizado com sucesso");//Succesfully updated thumbnail link
define("_THUMBNAIL_EDITTHUMBNAIL","Editar link da miniatura");//Edit thumbnail link
define("_THUMBNAIL_DELETETHUMBNAIL","Excluir link da miniatura");//Delete thumbnail link
define("_THUMBNAILAREYOUSUREYOUWANTTODELETEEVENT","Tem certeza de que deseja excluir este link da miniatura da lista");//Are you sure you want to delete this thumbnail link from the list
define("_THUMBNAIL_SUCCESFULLYDELETEDTHUMBNAILENTRY","Link da miniatura excluído com sucesso");//Thumbnail links deleted succesfully
define("_THUMBNAILNOMEETINGSCHEDULED","A lista das links da miniatura está vazia");//The Thumbnails thumbnail list is empty

define("_THUMBNAIL_DESCRIPTION","Descrição");//Description
define("_THUMBNAIL_THUMBNAILVIDEODATA","Dados do link da miniatura");//Thumbnail data
define("_THUMBNAIL_MANAGEMENT","Gerenciar miniatura");//Thumbnail management
define("_THUMBNAIL_PREVIOUS","Anterior");//Previous
define("_THUMBNAIL_NEXT","Próximo");//Next
define("_THUMBNAIL_EXAMPLE","Exemplo");//Example
define("_THUMBNAILTHEFIELDNAMEISMANDATORY","Campo da legenda  da miniatura é obrigatório");//Thumbnail caption field is mandatory
?>
