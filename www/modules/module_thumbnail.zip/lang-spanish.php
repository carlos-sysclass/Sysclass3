<?php
define("_THUMBNAIL","Miniaturas");//Thumbnails
define("_THUMBNAIL_THUMBNAILLIST","Miniaturas lista de enlaces");//Thumbnails links list
define("_THUMBNAIL_ADDTHUMBNAIL","Añadir enlace miniatura");//Add thumbnail link
define("_THUMBNAIL_PREVIEW","Miniatura instantánea");//Thumbnail snapshot
define("_THUMBNAIL_NAME","Título de miniatura");//Thumbnail caption
define("_THUMBNAIL_VIDEOLINK","Miniaturas vínculo");//Thumbnails link

define("_THUMBNAIL_PROBLEMINSERTINGTHUMBNAILENTRY","Miniaturas miniatura vínculo entrada no puede ser creado");//Thumbnails thumbnail link entry could not be created
define("_THUMBNAIL_SUCCESFULLYINSERTEDTHUMBNAILENTRY","Succesfylly enlace insertado en miniatura");//Succesfylly inserted thumbnail link
define("_THUMBNAIL_SUCCESFULLYUPDATEDTHUMBNAILENTRY","Se ha actualizado en miniatura vínculo");//Succesfully updated thumbnail link
define("_THUMBNAIL_EDITTHUMBNAIL","Editar miniatura vínculo");//Edit thumbnail link
define("_THUMBNAIL_DELETETHUMBNAIL","Eliminar miniatura vínculo");//Delete thumbnail link
define("_THUMBNAILAREYOUSUREYOUWANTTODELETEEVENT","¿Estás seguro de que desea eliminar este enlace en miniatura de la lista");//Are you sure you want to delete this thumbnail link from the list
define("_THUMBNAIL_SUCCESFULLYDELETEDTHUMBNAILENTRY","Miniatura vínculos suprimido con éxito");//Thumbnail links deleted succesfully
define("_THUMBNAILNOMEETINGSCHEDULED","La lista de miniaturas Miniaturas está vacía");//The Thumbnails thumbnail list is empty

define("_THUMBNAIL_DESCRIPTION","Descripción");//Description
define("_THUMBNAIL_THUMBNAILVIDEODATA","Miniatura de datos");//Thumbnail data
define("_THUMBNAIL_MANAGEMENT","Miniatura de gestión");//Thumbnail management
define("_THUMBNAIL_PREVIOUS","Anterior");//Previous
define("_THUMBNAIL_NEXT","Siguiente");//Next
define("_THUMBNAIL_EXAMPLE","Ejemplo");//Example
define("_THUMBNAILTHEFIELDNAMEISMANDATORY","Miniatura campo de texto es obligatoria");//Thumbnail caption field is mandatory
?>
