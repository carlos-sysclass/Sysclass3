<?php
define("_THUMBNAIL","缩略图");//Thumbnails
define("_THUMBNAIL_THUMBNAILLIST","缩略图链接列表");//Thumbnails links list
define("_THUMBNAIL_ADDTHUMBNAIL","添加缩略图链接");//Add thumbnail link
define("_THUMBNAIL_PREVIEW","缩图快照");//Thumbnail snapshot
define("_THUMBNAIL_NAME","标题缩略图");//Thumbnail caption
define("_THUMBNAIL_VIDEOLINK","缩略图链接");//Thumbnails link

define("_THUMBNAIL_PROBLEMINSERTINGTHUMBNAILENTRY","缩略图缩略图链接进入无法建立");//Thumbnails thumbnail link entry could not be created
define("_THUMBNAIL_SUCCESFULLYINSERTEDTHUMBNAILENTRY","Succesfylly插入缩略图链接");//Succesfylly inserted thumbnail link
define("_THUMBNAIL_SUCCESFULLYUPDATEDTHUMBNAILENTRY","成功更新缩略图链接");//Succesfully updated thumbnail link
define("_THUMBNAIL_EDITTHUMBNAIL","编辑缩略图链接");//Edit thumbnail link
define("_THUMBNAIL_DELETETHUMBNAIL","删除缩略图链接");//Delete thumbnail link
define("_THUMBNAILAREYOUSUREYOUWANTTODELETEEVENT","您是否确实要删除此缩略图链接的名单");//Are you sure you want to delete this thumbnail link from the list
define("_THUMBNAIL_SUCCESFULLYDELETEDTHUMBNAILENTRY","缩略图链接删除成功");//Thumbnail links deleted succesfully
define("_THUMBNAILNOMEETINGSCHEDULED","缩略图缩略图列表是空的");//The Thumbnails thumbnail list is empty

define("_THUMBNAIL_DESCRIPTION","说明");//Description
define("_THUMBNAIL_THUMBNAILVIDEODATA","缩略图数据");//Thumbnail data
define("_THUMBNAIL_MANAGEMENT","缩略图管理");//Thumbnail management
define("_THUMBNAIL_PREVIOUS","上一页");//Previous
define("_THUMBNAIL_NEXT","下一个");//Next
define("_THUMBNAIL_EXAMPLE","例如");//Example
define("_THUMBNAILTHEFIELDNAMEISMANDATORY","标题缩略图领域是强制性的");//Thumbnail caption field is mandatory
?>
