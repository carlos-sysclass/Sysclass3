<?php
define("_THUMBNAIL","Εικόνες");
define("_THUMBNAIL_THUMBNAILLIST", "Λίστα εικόνων");
define("_THUMBNAIL_ADDTHUMBNAIL", "Προσθήκη εικόνας");
define("_THUMBNAIL_PREVIEW", "Προεπισκόπηση εικόνας");
define("_THUMBNAIL_NAME", "Τίτλος εικόνας");
define("_THUMBNAIL_VIDEOLINK", "Thumbnails σύνδεσμος");

define("_THUMBNAIL_PROBLEMINSERTINGTHUMBNAILENTRY", "Η εικόνα αυτή δεν ήταν δυνατό να δημιουργηθεί");
define("_THUMBNAIL_SUCCESFULLYINSERTEDTHUMBNAILENTRY", "Η εικόνα καταχωρήθηκε επιτυχώς");
define("_THUMBNAIL_SUCCESFULLYUPDATEDTHUMBNAILENTRY", "Τα στοιχεία της εικόνας άλλαξαν επιτυχώς");
define("_THUMBNAIL_EDITTHUMBNAIL", "Επεξεργασία στοιχείων εικόνας");
define("_THUMBNAIL_DELETETHUMBNAIL", "Διαγραφή εικόνας");
define("_THUMBNAILAREYOUSUREYOUWANTTODELETEEVENT","Είστε σίγουροι ότι θέλετε να διαγράψετε την εικόνα αυτή από τη λίστα;");
define("_THUMBNAIL_SUCCESFULLYDELETEDTHUMBNAILENTRY","Η εικόνα διαγράφηκε επιτυχώς από τη λίστα");
define("_THUMBNAILNOMEETINGSCHEDULED","Η λίστα με τις εικόνες είναι κενή");

define("_THUMBNAIL_DESCRIPTION", "Περιγραφή");
define("_THUMBNAIL_THUMBNAILVIDEODATA","Πληροφορίες εικόνας");
define("_THUMBNAIL_MANAGEMENT","Επεξεργασία εικόνας");
define("_THUMBNAIL_PREVIOUS", "Προηγούμενο");
define("_THUMBNAIL_NEXT", "Επόμενο");
define("_THUMBNAIL_EXAMPLE", "Παράδειγμα");
define("_THUMBNAILTHEFIELDNAMEISMANDATORY","Ο τίτλος της εικόνας είναι υποχρεωτικός");

?>