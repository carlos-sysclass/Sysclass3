<?php
define("_THUMBNAIL","Miniaturen");//Thumbnails
define("_THUMBNAIL_THUMBNAILLIST","Miniaturen koppelingen lijst");//Thumbnails links list
define("_THUMBNAIL_ADDTHUMBNAIL","Thumbnail toevoeg link");//Add thumbnail link
define("_THUMBNAIL_PREVIEW","Thumbnail momentopname");//Thumbnail snapshot
define("_THUMBNAIL_NAME","Thumbnail bijschrift");//Thumbnail caption
define("_THUMBNAIL_VIDEOLINK","Miniaturen link");//Thumbnails link

define("_THUMBNAIL_PROBLEMINSERTINGTHUMBNAILENTRY","Miniaturen thumbnail link item kan niet worden gemaakt");//Thumbnails thumbnail link entry could not be created
define("_THUMBNAIL_SUCCESFULLYINSERTEDTHUMBNAILENTRY","Succesfylly ingevoegd thumbnail link");//Succesfylly inserted thumbnail link
define("_THUMBNAIL_SUCCESFULLYUPDATEDTHUMBNAILENTRY","Bijgewerkt thumbnail link");//Succesfully updated thumbnail link
define("_THUMBNAIL_EDITTHUMBNAIL","Edit thumbnail link");//Edit thumbnail link
define("_THUMBNAIL_DELETETHUMBNAIL","Verwijderen thumbnail link");//Delete thumbnail link
define("_THUMBNAILAREYOUSUREYOUWANTTODELETEEVENT","Weet u zeker dat u dit wilt verwijderen thumbnail link in de lijst");//Are you sure you want to delete this thumbnail link from the list
define("_THUMBNAIL_SUCCESFULLYDELETEDTHUMBNAILENTRY","Thumbnail links succesvol verwijderd");//Thumbnail links deleted succesfully
define("_THUMBNAILNOMEETINGSCHEDULED","Miniaturen thumbnail De lijst is leeg");//The Thumbnails thumbnail list is empty

define("_THUMBNAIL_DESCRIPTION","Beschrijving");//Description
define("_THUMBNAIL_THUMBNAILVIDEODATA","Thumbnail gegevens");//Thumbnail data
define("_THUMBNAIL_MANAGEMENT","Thumbnail beheer");//Thumbnail management
define("_THUMBNAIL_PREVIOUS","Vorige");//Previous
define("_THUMBNAIL_NEXT","Volgende");//Next
define("_THUMBNAIL_EXAMPLE","Voorbeeld");//Example
define("_THUMBNAILTHEFIELDNAMEISMANDATORY","Thumbnail bijschrift is een verplicht veld");//Thumbnail caption field is mandatory
?>
