<?php
define("_THUMBNAIL","Miniature");//Thumbnails
define("_THUMBNAIL_THUMBNAILLIST","Miniature link elenco");//Thumbnails links list
define("_THUMBNAIL_ADDTHUMBNAIL","Aggiungi miniatura link");//Add thumbnail link
define("_THUMBNAIL_PREVIEW","Anteprima istantanea");//Thumbnail snapshot
define("_THUMBNAIL_NAME","Didascalia Miniatura");//Thumbnail caption
define("_THUMBNAIL_VIDEOLINK","Miniature link");//Thumbnails link

define("_THUMBNAIL_PROBLEMINSERTINGTHUMBNAILENTRY","Miniature miniatura collegamento ingresso potrebbe non essere creato");//Thumbnails thumbnail link entry could not be created
define("_THUMBNAIL_SUCCESFULLYINSERTEDTHUMBNAILENTRY","Succesfylly link inserito in miniatura");//Succesfylly inserted thumbnail link
define("_THUMBNAIL_SUCCESFULLYUPDATEDTHUMBNAILENTRY","Aggiornato miniatura link");//Succesfully updated thumbnail link
define("_THUMBNAIL_EDITTHUMBNAIL","Modifica miniatura link");//Edit thumbnail link
define("_THUMBNAIL_DELETETHUMBNAIL","Elimina collegamento miniatura");//Delete thumbnail link
define("_THUMBNAILAREYOUSUREYOUWANTTODELETEEVENT","Sei sicuro di voler eliminare questo collegamento in miniatura dalla lista");//Are you sure you want to delete this thumbnail link from the list
define("_THUMBNAIL_SUCCESFULLYDELETEDTHUMBNAILENTRY","Thumbnail link eliminato con successo");//Thumbnail links deleted succesfully
define("_THUMBNAILNOMEETINGSCHEDULED","Le anteprime in miniatura elenco è vuoto");//The Thumbnails thumbnail list is empty

define("_THUMBNAIL_DESCRIPTION","Descrizione");//Description
define("_THUMBNAIL_THUMBNAILVIDEODATA","Anteprima dei dati");//Thumbnail data
define("_THUMBNAIL_MANAGEMENT","Anteprima di gestione");//Thumbnail management
define("_THUMBNAIL_PREVIOUS","Precedente");//Previous
define("_THUMBNAIL_NEXT","Successivo");//Next
define("_THUMBNAIL_EXAMPLE","Esempio");//Example
define("_THUMBNAILTHEFIELDNAMEISMANDATORY","Anteprima didascalia campo è obbligatorio");//Thumbnail caption field is mandatory
?>
