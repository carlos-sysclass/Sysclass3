<?php
define("_THUMBNAIL","Thumbnails");//Thumbnails
define("_THUMBNAIL_THUMBNAILLIST","Vignettes la liste des liens");//Thumbnails links list
define("_THUMBNAIL_ADDTHUMBNAIL","Ajouter thumbnail lien");//Add thumbnail link
define("_THUMBNAIL_PREVIEW","Thumbnail instantané");//Thumbnail snapshot
define("_THUMBNAIL_NAME","Légende de vignette");//Thumbnail caption
define("_THUMBNAIL_VIDEOLINK","Vignettes lien");//Thumbnails link

define("_THUMBNAIL_PROBLEMINSERTINGTHUMBNAILENTRY","Les vignettes des vignettes lien entrée n&#39;a pas pu être créé");//Thumbnails thumbnail link entry could not be created
define("_THUMBNAIL_SUCCESFULLYINSERTEDTHUMBNAILENTRY","Succesfylly lien inséré thumbnail");//Succesfylly inserted thumbnail link
define("_THUMBNAIL_SUCCESFULLYUPDATEDTHUMBNAILENTRY","Mis à jour des vignettes lien");//Succesfully updated thumbnail link
define("_THUMBNAIL_EDITTHUMBNAIL","Modifier le lien thumbnail");//Edit thumbnail link
define("_THUMBNAIL_DELETETHUMBNAIL","Supprimer le lien thumbnail");//Delete thumbnail link
define("_THUMBNAILAREYOUSUREYOUWANTTODELETEEVENT","Êtes-vous sûr de vouloir supprimer ce lien aperçu de la liste");//Are you sure you want to delete this thumbnail link from the list
define("_THUMBNAIL_SUCCESFULLYDELETEDTHUMBNAILENTRY","Thumbnail liens supprimé avec succès");//Thumbnail links deleted succesfully
define("_THUMBNAILNOMEETINGSCHEDULED","Les vignettes des vignettes liste est vide");//The Thumbnails thumbnail list is empty

define("_THUMBNAIL_DESCRIPTION","Description");//Description
define("_THUMBNAIL_THUMBNAILVIDEODATA","Thumbnail données");//Thumbnail data
define("_THUMBNAIL_MANAGEMENT","Thumbnail gestion");//Thumbnail management
define("_THUMBNAIL_PREVIOUS","Précédent");//Previous
define("_THUMBNAIL_NEXT","Suivant");//Next
define("_THUMBNAIL_EXAMPLE","Exemple");//Example
define("_THUMBNAILTHEFIELDNAMEISMANDATORY","Légende de vignette champ est obligatoire");//Thumbnail caption field is mandatory
?>
