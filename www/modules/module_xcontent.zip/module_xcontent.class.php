<?php
class module_xcontent extends MagesterExtendedModule {
		
    // CORE MODULE FUNCTIONS
    public function getName() {
        return "XCONTENT";
    }
    
    public function getPermittedRoles() {
        return array("administrator", "professor", "student");
    }
    public function isLessonModule() {
        return false;
    }
	/*
	public function getNavigationLinks() {
		$this->showModuleBreadcrumbs = false;
		
		return parent::getNavigationLinks();
	}
    */
    /* MAIN-INDEPENDENT MODULE INFO, PAGES, TEMPLATES, ETC... */
    /*
	public function addStylesheets() {
		return array("960gs/fluid/24columns");
	}
	*/
    /* BLOCK FUNCTIONS */
    public function loadContentAnalisysBlock($blockIndex = null, $blockInfo = null) {
    	$smarty 		= $this->getSmartyVar();
    	$currentUser	= $this->getCurrentUser();
    	
    	// OPEN TEST RESULT
    	$testContentID = $blockInfo['unit_id'];
    	
    	try {
    		$userTest = new MagesterTest($testContentID);
    		
    		$recentUserTests = eF_getTableData(
    			"completed_tests JOIN tests ON tests_id = tests.id JOIN users ON completed_tests.users_LOGIN = users.login", 
    			"completed_tests.id, completed_tests.test, completed_tests.score, users.name as username, users.surname, completed_tests.tests_ID, tests.name, completed_tests.timestamp, completed_tests.users_LOGIN", 
    			"completed_tests.status != 'deleted' and completed_tests.users_LOGIN = '" . $this->getCurrentUser()->user['login'] . "' and completed_tests.tests_id = " . $userTest->test['id'], "timestamp DESC");
    		
    		
    		
    		if (count($recentUserTests) > 0) {
    			$userScore = is_null($recentUserTests[0]['score']) ? 0 : $recentUserTests[0]['score'];

    			// SHOW RESULT BASED ON USER SCORE
				$levels = array(
			   		1	=> array(
			   			'label'	=> 'Básico',
			   			'text'	=> 'Comunicar-se de forma simples em inglês, em situações previsíveis do dia-a-dia de trabalho ou numa viagem. Seu vocabulário é básico e permite que você fale sobre sim mesmo, sobre seu trabalho e dê detalhes sobre o que o rodeia.',
		   				'next_title'	=> 'O próximo nível do curso Idiompro é o Pré-Intermediário. Nele você será capaz de:',
			   			'next'	=> array(
			   				array(
			   					'title'	=> 'Em reunião:',
			   					'text'	=> 'Comunicar-se claramente, expressar opiniões, dar sugestões, apresentar e descrever outras pessoas, lidar com diferentes culturas em encontros profissionais ou viagens.'
			   				),
		   					array(
	   							'title'	=> 'Em entrevista:',
	   							'text'	=> 'Comunicar-se em ambientes formais, falar sobre si mesmo, sobre o que você gosta e não gosta, hobbies, carreira e desenvolvimento pessoal.'
		   					),
		   					array(
		   							'title'	=> 'Em comunicação escrita:',
		   							'text'	=> 'Escrever relatórios e e-mails simples.'
		   					)
			   			)
			   		),
					2	=> array(
			   			'label'	=> 'Pré-Intermediário',
						'text'	=> 'Compreender informações simples encontradas nas situações do dia-a-dia e manter uma conversa a respeito de assuntos do seu interesse. Consegue explorar uma grande variedade de linguagem simples com flexibilidade para expressar muito daquilo que quer transmitir. Consegue comunicar-se adequadamente em contextos profissionais de rotina.',
						'next_title'	=> 'O próximo nível do curso Idiompro é o Intermediário. Nesse nível você será capaz de:',
						'next'	=> array(
							array(
								'title'	=> 'Em reunião:',
								'text'	=> 'Comunicar-se claramente em várias situações de negócios incluindo transações financeiras e realizar apresentações de negócios com confiança.'
							),
							array(
								'title'	=> 'Em entrevista:',
								'text'	=> 'Comunicar-se claramente em entrevistas de emprego descrevendo suas atividades e qualidades e falando sobre si mesmo com mais detalhes e profundidade.'
							),
							array(
								'title'	=> 'Em comunicação escrita:',
								'text'	=> 'Escrever cartas formais e informais, inclusive reclamações, e preparar relatórios um pouco mais complexos e detalhados.'
							)
						)
							
			   		),
					3	=> array(
			   			'label'	=> 'Intermediário',
						'text'	=> 'Expressar claramente ideias e opiniões sobre uma ampla variedade de tópicos, além de compreender e trocar informações com segurança. Possui comando ativo dos aspectos essenciais da língua. Comunica-se com competência e independência em muitas situações profissionais e sociais.',
						'next_title'	=> 'O próximo nível do curso Idiompro é o Intermediário Superior. Nesse nível você será capaz de:',
						'next'	=> array(
							array(
								'title'	=> 'Em reunião:',
								'text'	=> 'Conduzir apresentações com gráficos e negociações com clareza e segurança, utilizar vocabulário relacionado às áreas de marketing, meio ambiente e tecnologia. Conduzir negócios em todo o mundo.'
							),
							array(
								'title'	=> 'Em entrevista:',
								'text'	=> 'Habilidades completas para falar sobre si mesmo e outras pessoas, seus hobbies, preferências e motivações.'
							),
							array(
								'title'	=> 'Em comunicação escrita:',
								'text'	=> 'Desenvolver relatórios contendo gráficos, pesquisas de mercado, apresentar os pros e contras e fazer comparações de dados.'
							)
						)
							
					),
					4	=> array(
			   			'label'	=> 'Intermediário Superior',
						'text'	=> 'Expressar suas opiniões com bastante clareza. Negociar e discutir com segurança. Possui comando suficiente da língua para conseguir adotar uma estrutura apropriada em várias circunstâncias diferentes. Avalia situações, identifica problemas e oferece soluções. Já consegue assumir um papel de liderança ao iniciar e conduzir uma conversa.',
						'next_title'	=> 'O próximo nível do curso Idiompro é o Avançado. Nesse nível você será capaz de:',
						'next'	=> array(
							array(
								'title'	=> 'Em reunião:',
								'text'	=> 'Comandar reuniões, mantendo o controle usando a linguagem específica do assunto com facilidade e fluência.'
							),
							array(
								'title'	=> 'Em entrevista:',
								'text'	=> 'Expressar-se com clareza e fluência, dominado com segurança uma ampla variedade de assuntos com elevado grau de exatidão.'
							),
							array(
								'title'	=> 'Em comunicação escrita:',
								'text'	=> 'Expressar-se com amplo repertório de negócios, com fornecedores e clientes, escrever planejamentos e comparativos de mercado.'
							)
						)
			   		),
					5	=> array(
			   			'label'	=> 'Superior',
						'text'	=> 'Expressar- se com clareza e fluência, dominando com segurança uma ampla variedade de linguagem, com elevado grau de exatidão. Lidar com informações complexas com segurança. Demonstrar um amplo repertório de vocabulário, estruturas e expressões coloquiais e idiomáticas. Comandar reuniões, mantendo o controle usando a linguagem específica do assunto com facilidade e fluência. Aproxima-se da competência de quem está falando sua língua-mãe.'
			   		)
				);
				
				//var_dump($recentUserTests[0]);

				if ($userScore <= 40) {
			   		$level = 1;
				} elseif ($userScore > 40 && $userScore <= 55) {
			   		$level = 2;
				} elseif ($userScore > 55 && $userScore <= 70) {
					$level = 3;
				} elseif ($userScore > 70 && $userScore <= 85) {
					$level = 4;
				} else {
					$level = 5;
				}
    		} else {
    			// Usuário ainda não fez o teste
    			
    		}
    		
    		$smarty -> assign("T_XCONTENT_USERLEVEL", $levels[$level]);
    		$smarty -> assign("T_XCONTENT_USERSCORE", $userScore);
    		    		
	    	
	    	$this->getParent()->appendTemplate(array(
		   		'title'			=> __XCONTENT_LEVEL . ":" . $levels[$level]['label'],
		   		'template'		=> $this->moduleBaseDir . 'templates/blocks/analisys_range.text.tpl',
		   		'contentclass'	=> 'blockContents'
	    	), $blockIndex);
	    	
	    	

	    	
	    	$this->injectJS("jquery/jquery-ui");
    	
	    	
	    	return true;    	
    	} catch (Exception $e) {
    		return false;    	
    	}
    }
    public function loadContentAnalisysRangeBlock($blockIndex = null, $blockInfo = null) {
    	
    	

    	$this->getParent()->appendTemplate(array(
	   		'title'			=> __XCONTENT_LEVELS,
	   		'template'		=> $this->moduleBaseDir . 'templates/blocks/analisys_range.table.tpl',
	   		'contentclass'	=> 'blockContents'
    	), $blockIndex);
    }
    public function loadContentScheduleListBlock($blockIndex = null, $blockInfo = null) {
    	// CHECK context (filter) LINK (polo, user_type, course, etc).
    	// OPEN TEST RESULT
    	$smarty 		= $this->getSmartyVar();
    	$currentUser	= $this->getCurrentUser();
    	
    	var_dump($currentUser -> user['id']);
    	if (in_array($currentUser -> user['id'], array(47, 48))) {
	    	$testContentID = $blockInfo['unit_id'];
	    	
	    	$result = eF_getTableData(
	    		"module_xcontent_schedule cont LEFT JOIN module_xentify_scopes scop ON cont.xentify_scope_id = scop.id", 
	    		"xentify_scope_id, block_html", "CURRENT_TIMESTAMP BETWEEN cont.start AND cont.end AND cont.active = 1"
	    	);
	    	
	    	/*
			content_id		 	 	 	 	 	 	
			xentify_scope_id		 	 	 	 	 	 	
				 	 	 	 	 	 		
			end		 	 	 	 	 	 	
			block_html		 	 	 				 
			active
	    	*/
	    	
	    	$this->assignSmartyModuleVariables();
	    	
	    	$this->getParent()->appendTemplate(array(
		   		'title'			=> __XCONTENT_SCHEDULE,
		   		'template'		=> $this->moduleBaseDir . 'templates/blocks/content.schecule.list.tpl',
		   		'contentclass'	=> 'blockContents'
	    	), $blockIndex);
	    	
	    	return true;
    	}
    	
    	return false;
    }
    /* ACTIONS FUNCTIONS */
    public function registerXcontentScheduleAction() {
    	$smarty 		= $this->getSmartyVar();
    	$currentUser	= $this->getCurrentUser();
    	
    	if (in_array($currentUser -> user['id'], array(47, 48))) {
	    	/*
	    	BUSCAR POLO DO ALUNO
	    		- CHECAR SE EXISTE ALGUM AGENDAMENTO PENDENTE
	    		- SE SIM, VERIFICAR SE É NO MESMO ( CURSO, DISCIPLINA E TURMA) DO ALUNO
	    		- SE SIM MOSTRAR AGENDA COM O PERIODO SELECIONADO, COM AS OPÇÕES PARA MARCAR.
	    		
	    	MOSTRAR AGENDA BASEADO EM: 
	    		- Polo do aluno
	    	*/	
	    	
	    	$smarty -> assign("T_XCONTENT_SCHEDULE_ITEM", "Agendamento da Prova Presencial"); 
	    	
	    	//$this->injectJS("jquery/jquery.weekcalendar");
	    	//$this->injectCSS("jquery/jquery.weekcalendar");
	    	
	    	return true;
    	} else {
    		return false;
    	}
    }

	public function getUserTestScoreAction($token = null, $constraints = null) {
		
		if (isset($constraints['login'])) {
			$currentUser	= MagesterUserFactory :: factory($constraints['login']);
		} else {
			$currentUser	= $this->getCurrentUser();
		}
		// OPEN TEST RESULT
		$testContentID = $constraints['unit_id'];
		
		try {
			$userTest = new MagesterTest($testContentID);
			
			$recentUserTests = eF_getTableData(
					"completed_tests JOIN tests ON tests_id = tests.id JOIN users ON completed_tests.users_LOGIN = users.login",
					"completed_tests.id, completed_tests.test, completed_tests.score, users.name as username, users.surname, completed_tests.tests_ID, tests.name, completed_tests.timestamp, completed_tests.users_LOGIN",
					"completed_tests.status != 'deleted' and completed_tests.users_LOGIN = '" . $currentUser->user['login'] . "' and completed_tests.tests_id = " . $userTest->test['id'], "timestamp DESC");
		
			if (count($recentUserTests) > 0) {
				$userScore = is_null($recentUserTests[0]['score']) ? 0 : $recentUserTests[0]['score'];
				
				if ($userScore <= 40) {
					$level = 1;
				} elseif ($userScore > 40 && $userScore <= 55) {
					$level = 2;
				} elseif ($userScore > 55 && $userScore <= 70) {
					$level = 3;
				} elseif ($userScore > 70 && $userScore <= 85) {
					$level = 4;
				} else {
					$level = 5;
				}				
				
				return array(
					'score'	=> $userScore,
					'level'	=> $level
				);
			}
		} catch (Exception $e) {
		}
		return array();
	}
}
?>