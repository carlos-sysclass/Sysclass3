
jQuery(function($) {
	defaults = {
			"bProcessing": true,
			"bJQueryUI": true,
			"bSortClasses": false,
			"bAutoWidth": true,
			"bInfo": true,
			"sScrollY": "100%",	
			"sScrollX": "100%",
			"bScrollCollapse": true,
			"sPaginationType": "full_numbers",
			"iDisplayLength"	: 10,
			"aLengthMenu": [[10, 20, 50, 100, -1], [10, 20, 50, 100, "Tudo"]],
			"oLanguage": {
				"sUrl": window.location.pathname + "?ctg=module&op=module_language&action=get_section&section_id=datatable&output=json"
		}
	};
	opt = defaults;
				
	var o_xCourseClassTable = jQuery("#_XENROLLMENT_LAST_LIST").dataTable( opt );
});