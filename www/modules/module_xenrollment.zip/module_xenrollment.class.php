<?php

class module_xenrollment extends MagesterExtendedModule {
	

	/*
	const GET_XUSERS				= 'get_xusers';
	const GET_XUSERS_SOURCE			= 'get_xusers_source';
	const ADD_XUSER					= 'add_xuser';
	const EDIT_XUSER				= 'edit_xuser';
	const DELETE_XUSER				= 'delete_xuser';
	const UPDATE_XUSER				= 'update_xuser';
	*/
	/* Model Data */
	/** @todo Cache this data */
	protected $editedEnrollment 	= null;
	protected $editedUser 			= null;
	protected $editedCourse 		= null;
	
	
	/* AÇÕES DISPONIBILIZADAS */
	const SHOW_LAST_XENROLLMENTS		= 'show_last_xenrollments';
	 
	const REGISTER_XENROLLMENT			= 'register_xenrollment';
	const UNREGISTER_XENROLLMENT		= 'unregister_xenrollment';
	
	/* ENROLLMENT STATUSES */
	const COMMIT_STATE		= 2;
	const ROLLBACK_STATE	= 3;
	
	public function __construct($defined_moduleBaseUrl, $defined_moduleFolder) {
		parent::__construct($defined_moduleBaseUrl, $defined_moduleFolder);
		
		$this->preActions[] = 'checkUserPermissionAction';
//		$this->preActions[] = 'makeEnrollmentOptions';
		
//		$this->postActions[] = 'checkUserPermission';
		$this->postActions[] = 'makeXenrollmentOptionsAction';
	}
	
	
    // Mandatory functions required for module function
    public function getName() {
        return "XENROLLMENT";
    }
       
    
	public function getTitle($action) {
		switch($action) {
			case $this->getDefaultAction() : {
				return __XENROLLMENT_NAME; 
			}
			case self::SHOW_LAST_XENROLLMENTS : {
				return __XENROLLMENT_SHOW_LAST_ENROLLMENT_TITLE; 
			}
			case self::REGISTER_XENROLLMENT : {
				return __XENROLLMENT_REGISTER_TITLE;
			}
			case self::UNREGISTER_XENROLLMENT : {
				return __XENROLLMENT_UNREGISTER_TITLE;
			}
		}
		return parent::getTitle($action);
	}
	
	public function getUrl($action) {
		return $this->moduleBaseUrl . "&action=" . $action;
	} 

    public function getPermittedRoles() {
        return array("administrator");
    }

    public function isLessonModule() {
        return false;
    }
    
    public function getDefaultAction() {
    	return self::SHOW_LAST_XENROLLMENTS;
    }
    
    protected function getModuleData() {
		$parentData = parent::getModuleData();
		
		$selfData = array(
			$this->index_name . ".show_last_limit"	=> 10
		);
		
		return array_merge_recursive($parentData, $selfData);  
    }
    
    
    /* ACTION HANDLERS */
    public function openXenrollmentAction() {
    	$token = $this->createToken(30);

    	$newID = eF_insertTableData("module_xenrollment", array(
    		"token"	=> $token 
    	));
    	
    	return array(
    		"id"	=> $newID,
    		"token"	=> $token
    	);
    }
	public function updateXenrollmentAction($enrollment_token, $fields) {
    	/** @todo RETURN IN A WAY TO UPDATE THIS opened enrollment */
		eF_updateTableData("module_xenrollment", $fields, "token = '" . $enrollment_token . "'");
		
		$result = eF_getTableData("module_xenrollment", "*", "token = '" . $enrollment_token . "'");
		
		if ($result) {
			return $result[0];
		} else {
			return array_merge(
				array(
	    			"token"	=> $token
				),
				$fields
			);
		}
    }
	public function commitXenrollmentAction($enrollment_token) {
		return $this->updateEnrollmentAction($enrollment_token, array('status_id' => self::COMMIT_STATE));
	}
    public function rollbackXenrollmentAction($enrollment_token) {
    	return $this->updateEnrollmentAction($enrollment_token, array('status_id' => self::ROLLBACK_STATE));
    }
    public function registerXenrollmentAction() {

    }
    public function unregisterXenrollmentAction() {
		$template = array(
			'title'			=> __ENROLLMENT_UNREGISTER,
	        'template'		=> $this->moduleBaseDir . "templates/actions/xenrollment.unregister.tpl"
		);
		
		$this->appendTemplate($template);
    }
    public function showLastXenrollmentsAction() {
    	$configData = $this->getModuleData();
    	
		$table[] = "`module_xenrollment` enroll";
		$table[] = "LEFT JOIN module_xenrollment_statuses enroll_status ON enroll.status_id = enroll_status.id";
		$table[] = "LEFT JOIN module_ies ies ON enroll.ies_id = ies.id";
		$table[] = "LEFT JOIN users user ON enroll.users_id = user.id";
		$table[] = "LEFT JOIN courses course ON enroll.courses_id = course.id";

		$fields[] = "enroll.id";
		$fields[] = "enroll.ies_id"; 
		$fields[] = "ies.nome as ies_name"; 
		$fields[] = "enroll.users_id";
		$fields[] = "user.login";
		$fields[] = "user.name";
		$fields[] = "user.surname"; 
		$fields[] = "enroll.courses_id";
		$fields[] = "course.name as course_name"; 
		$fields[] = "enroll.payment_id";
		$fields[] = "enroll.status_id";
		$fields[] = "enroll_status.name as status";
		$fields[] = "enroll.tag";
		
		$order[] = "data_registro DESC";
		
		$limit = "0, 10";
		
    	$lastEnrollmentsData = eF_getTableData(implode(' ', $table), implode(",", $fields), "", implode(",", $order), "", $limit);
    	
    	$smarty = $this->getSmartyVar();
    	
    	foreach($lastEnrollmentsData as $key => $enrollItem) {
    		$lastEnrollmentsData[$key]['username'] = formatLogin(null, $enrollItem);
    	}
    	
    	$smarty -> assign("T_LAST_ENROLLMENTS_LIST", $lastEnrollmentsData);
    	
    	$template = array(
			'title'			=> $this->getTitle($this->getCurrentAction()),
	        'template'		=> $this->moduleBaseDir . "templates/actions/xenrollment.show_last.tpl",
    		"contentclass"	=> ""
		);
		
		$this->appendTemplate($template);
    }
	public function makeXenrollmentOptionsAction() {
        $selectedAction = $this->getCurrentAction();
		$smarty 		= $this -> getSmartyVar();
		
		$options = array();
		
		$options[] = array(
			'text' 		=> __ENROLLMENT_REGISTER,
			'hint'		=> __ENROLLMENT_REGISTER_HINT, 
			'image' 	=> "/themes/sysclass/images/icons/small/grey/cloud_upload.png", 
			'href' 		=> $this->moduleBaseUrl . '&action=' . self::REGISTER_XENROLLMENT . "&xuser_id=" . $_GET['xuser_id'] . "&xuser_login=" . $_GET['xuser_login']
		);
		
		$smarty -> assign("T_" . $this->getName() . "_OPTIONS", $options);
		
		return true;
    }
    /* MAIN-INDEPENDENT MODULE PAGES */
    /*
    public function getModule() {
    	parent::getModule();
    }
    	*/
		
		
		/*

        if ($selectedAction == self::DELETE_XUSER && eF_checkParameter($_GET['xuser_id'], 'id')) {
        } elseif ($selectedAction == self::UPDATE_XUSER && eF_checkParameter($_GET['xuser_login'], 'login')) {
        } else if (
        	$selectedAction == self::ADD_XUSER || 
        	($selectedAction == self::EDIT_XUSER && eF_checkParameter($_GET['xuser_id'], 'id')) ||
        	($selectedAction == self::EDIT_XUSER && eF_checkParameter($_GET['xuser_login'], 'login'))
        ) {
            //$result = $rendererBasic -> toArray();
            
       		if ( $this->makeEditUserOptions() ) {
       		}
       		
			$templates = array();
       		
           	if ( $this->makeBasicForm() ) {
	            $templates[] = array(
	            	'title'			=> _MODULE_XUSERS_EDITBASICXUSER,
	            	'template'		=> $this->moduleBaseDir . "templates/includes/xuser_basic_form.tpl",
	            	'contentclass'	=> ''
	            );
            }
            
        	if ( $this->makeResponsibleForm() ) {
	            $templates[] = array(
	            	'title'			=> _MODULE_XUSERS_EDITRESPONSIBLEXUSER,
	            	'template'		=> $this->moduleBaseDir . "templates/includes/xuser_responsible_form.tpl",
	            	'contentclass'	=> ''
	            );
            }
            
            if (
        		($selectedAction == self::EDIT_XUSER && eF_checkParameter($_GET['xuser_id'], 'id')) ||
        		($selectedAction == self::EDIT_XUSER && eF_checkParameter($_GET['xuser_login'], 'login'))
        	) {
        	}
            

            
			$smarty -> assign('T_MODULE_XUSER_FORM_TABS',
				$templates
			);
            
        } elseif ($selectedAction == self::GET_XUSERS_SOURCE) {
        	$this->getDatatableSource();
		} else {
//			$smarty -> assign("T_USERS_SIZE", sizeof($users));

//            $smarty -> assign("T_XUSERS", $users);

			$smarty -> assign("T_CURRENT_USER", $this->getCurrentUser());
            $smarty -> assign("T_XROLES", MagesterUser :: getRoles(true));
            
//            $smarty -> assign("T_XUSERS", $xusers);
        }
        return true;
    }
*/
    /* DATA MODEL FUNCTIONS /*/
	public function getEnrollmentById($enrollment_id){
		$result = eF_getTableData("module_xenrollment", "*", "id = '" . $enrollment_id . "'");
		
		if ($result) {
			return $result[0];
		} else {
			return false;
		}
	}
	public function getEnrollmentByToken($enrollment_token){
		$result = eF_getTableData("module_xenrollment", "*", "token = '" . $enrollment_token . "'");
		
		if ($result) {
			return $result[0];
		} else {
			return false;
		}
	}
    
    public function getEditedUser($reload = false, $login = null) {
    	if (!is_null($login)) {
    		return $this->editedUser = MagesterUserFactory::factory($login);
    	}
    	
    	if (!is_null($this->editedUser) && !$reload) {
    		return $this->editedUser;
    	}
    	if (eF_checkParameter($_GET['xuser_id'], 'id')) {
    		
		} elseif (eF_checkParameter($_GET['xuser_login'], 'login')) {
			return $this->editedUser = MagesterUserFactory::factory($_GET['xuser_login']);
		}
    	
    	return false;
    }
    
    
    }
?>