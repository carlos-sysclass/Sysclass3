jQuery(function($) {
	
	jQuery("#xuser_entry_form :input[name='new_login']").val(
		createNewUserLogin(jQuery("#xuser_entry_form :input[name='name']").val(), jQuery("#xuser_entry_form :input[name='surname']").val())
	);
		
	jQuery("#xuser_entry_form :input[name='name'], #xuser_entry_form :input[name='surname']").keyup(function() {
		jQuery("#xuser_entry_form :input[name='new_login']").val(
			createNewUserLogin(jQuery("#xuser_entry_form :input[name='name']").val(), jQuery("#xuser_entry_form :input[name='surname']").val())
		);
	});	
	
	
	if (typeof(getUsersDatatableID) != "undefined") {
		if (jQuery('#' + getUsersDatatableID).size() > 0) {
			defaults = {
				"bProcessing": true,
				"bServerSide": true,
				"sAjaxSource": datatableSourceUrl + "&action=get_xusers_source",
				//"bJQueryUI": true,
				"bDeferRender" : true,
				"bSortClasses": false,
				"bAutoWidth": true,
				"bInfo": true,
				"sScrollY": "100%",	
				"sScrollX": "100%",
				"bScrollCollapse": true,
				"sPaginationType": "full_numbers",
				"iDisplayLength"	: 20,
				"aLengthMenu": [[10, 20, 50, 100, -1], [10, 20, 50, 100, "Tudo"]],
				//"sDom" : '<"H"lf<"dataTables_outerprocessing"r>>t<"F"ip>',
				"aoColumns": [
				    { "mDataProp": "login" },
				    { "mDataProp": "user_type_name", sClass : "center" },
				    { "mDataProp": "courses_num", sClass : "center", "bSortable" : false },
				    { "mDataProp": "last_login", sClass : "center"  },
				    { "mDataProp": "active", sClass : "center", "bSortable" : false }
				],
				"oLanguage": {
					"sUrl": window.location.pathname + "?ctg=module&op=module_language&action=get_section&section_id=datatable&output=json"
				}
			};

			var oTable = $('#' + getUsersDatatableID).dataTable( defaults );
		}
	}
	
	MinorCutLine = new Date();
	MinorCutLine.setFullYear(MinorCutLine.getFullYear() - 18);
	
	checkMinorFunction = function() {
		var ValueDate = jQuery(this).datepicker('getDate');
		
		if (ValueDate > MinorCutLine) {
			// MENOR DE IDADE
			//jQuery("._XUSER_responsibleBlock").dialog('open');
		} else {
			// MAIOR DE IDADE
			//jQuery("._XUSER_responsibleBlock").dialog('close');
		}
	};
	// checa se a idade é menor que 18, e em caso positivo, habilita opção para registrar dados do responsável
	$(":input[name='data_nascimento']").change(checkMinorFunction);
	
	checkMinorFunction();
	
	jQuery("button[name='_XUSER_NOT18AGEOLD_BUTTON']").click(function () {
		//jQuery("._XUSER_responsibleBlock").dialog('open');
	});
	
	jQuery("button.activateUserLink").live("hover", function() {
		
		
	});
	/*
	jQuery("button.activateUserLink").tipsy(
		{live: true}
	);
	*/
	
	/*
	jQuery("._XUSER_responsibleBlock").dialog({
		autoOpen	: true, 
		show		: "fade",
		hide		: "fade",
		modal		: true,
		width		: 600,
		minWidth	: 600
	});
	*/
	
	jQuery("._XUSER_COURSETYPE_DIALOG").dialog({
		autoOpen: false, 
		show: "fade",
		hide: "fade",
		modal: true,
		width: 'auto',
		buttons : {
			'Salvar' : function() {	
				// SAVE AND CLOSE, UPDATE TABLE TOO.
				console.log(jQuery(this).data());
				course_id = jQuery(this).data('course_id');
				sentData = {
					user_login : jQuery(this).data('user_login'),
					course_id	: course_id,
					course_type : jQuery(this).find(":input[name='dialog_course_type[" + course_id + "]']:checked").val()
				};
				
				// UPDATE DATA AND REDIRECT
				jQuery.post(
					window.location.pathname + "?ctg=module&op=module_xuser&action=update_xuser&xuser_login=" + sentData.user_login + "&field=user_course.course_type",
					sentData,
					function(data, status) {
						// REFRESH WINDOW, OR REFRESH SCREEN ???
						window.location.href = 
							window.location.protocol + "//" +
							window.location.hostname +
							window.location.pathname +
							window.location.search +
							"#" + JS_clearStringSymbols($languageJS['__XUSER_SHOWUSERCOURSES']);
						
						window.location.reload(true);
						/*
						jQuery("#_PAGAMENTO_COURSETYPE_CHANGELINK-" + sentData.course_id).html(
							sentData.course_type	
						);
						*/
					}
				);
				jQuery(this).dialog('close');
			},
			'Cancelar' 	: function() {
				jQuery(this).dialog('close');
			}
		}
		
	});
});

function createNewUserLogin(name, surname, login) {
	name = new String(name);
	surname = new String(surname);
	
	if (name.length > 0 && surname.length > 0) {
		// get first name and last name
		firstname = name.split(' ', 2);
		firstname = firstname[0];
		
		lastname = surname.split(' ');
		if (lastname[lastname.length - 1].length > 0) {
			lastname = lastname[lastname.length - 1];
		} else {
			if (lastname[lastname.length - 2].length > 0) {
				lastname = lastname[lastname.length - 2];
			} else {
				return '';
			}
		}
		
		login = firstname.toLocaleLowerCase() + '.' + lastname.toLocaleLowerCase();
		
		return login;
	}
	return '';
}

function changeUserCourseType(user_login, course_id) {
	jQuery("#_XUSER_COURSETYPE_DIALOG-" + course_id)
		.data('user_login', user_login)
		.data('course_id', course_id)
		.dialog('open');
}
function changeUserCourseClass(user_login, course_id, class_id) {
	jQuery("#_XUSER_NOTIMPLEMENTEDYET_DIALOG").dialog('open');
}


function xuser_activateUser(el, user) {
	if (jQuery(el).hasClass('red')) { // 
		parameters = {
			activate_user:user, 
			method: 'get'
		};
	} else {
		parameters = {
			deactivate_user:user, 
			method: 'get'
		};
	}
    var url = window.location.pathname + "?ctg=users";
    
    var elem = el;
    
    jQuery.get(
    	url,
    	parameters,
    	function(data, status) {
   			jQuery(el)
   				.toggleClass('red')
   				.toggleClass('green')
   				.attr("title", activeStates[data])
   				.attr("original-title", activeStates[data]);
   			
   			if (data == 1) {
   				jQuery(el)
   					.parents("tr")
   					.find("a.editLink")
   					.css("color", "");
   			} else {
   				jQuery(el)
	   				.parents("tr")
	   				.find("a.editLink")
	   				.css("color", "red");
   			}
    		/*
    		 if (response == 0) {
    		     setImageSrc(el, 16, "trafficlight_red.png");
    		        el.writeAttribute({alt:activate, title:activate});
    		        el.up().up().addClassName('deactivatedTableElement');
    		    } else if (response == 1) {
    		     setImageSrc(el, 16, "trafficlight_green.png");
    		        el.writeAttribute({alt:deactivate, title:deactivate});
    		        el.up().up().removeClassName('deactivatedTableElement');
    		    }
    		*/
    		
    	}
    );
    //ajaxRequest(el, url, parameters, onActivateUser);
}