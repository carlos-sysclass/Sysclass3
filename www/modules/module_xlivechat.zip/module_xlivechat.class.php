<?php
class module_xlivechat extends MagesterExtendedModule {
	
	
	
    public function getName() {
        return "XLIVECHAT";
    }
	
    public function getPermittedRoles() {
        return array("administrator","professor","student");
    }	

}
?>
