jQuery(function($) {
	if (typeof(getUsersDatatableID) != "undefined") {
		if (jQuery('#' + getUsersDatatableID).size() > 0) {
			defaults = {
				"bProcessing": true,
				"bServerSide": true,
				"sAjaxSource": datatableSourceUrl + "&action=get_xusers_source",
				"bJQueryUI": true,
				"bDeferRender" : true,
				"bSortClasses": false,
				"bAutoWidth": true,
				"bInfo": true,
				"sScrollY": "100%",	
				"sScrollX": "100%",
				"bScrollCollapse": true,
				"sPaginationType": "full_numbers",
				"iDisplayLength"	: 20,
				"aLengthMenu": [[10, 20, 50, 100, -1], [10, 20, 50, 100, "Tudo"]],
				"sDom" : '<"H"lf<"dataTables_outerprocessing"r>>t<"F"ip>',
				"aoColumns": [
				    { "mDataProp": "login" },
				    { "mDataProp": "user_type_name", sClass : "center" },
				    { "mDataProp": "courses_num", sClass : "center", "bSortable" : false },
				    { "mDataProp": "last_login", sClass : "center"  },
				    { "mDataProp": "active", sClass : "center", "bSortable" : false }
				],
				"oLanguage": {
					"sUrl": window.location.pathname + "?ctg=module&op=module_language&action=get_section&section_id=datatable&output=json"
				}
			};
			opt = defaults;
					
			var oTable = $('#' + getUsersDatatableID).dataTable( opt );
		}
	}
	
	MinorCutLine = new Date();
	MinorCutLine.setFullYear(MinorCutLine.getFullYear() - 18);
	
	checkMinorFunction = function() {
		var ValueDate = jQuery(this).datepicker('getDate');
		
		if (ValueDate > MinorCutLine) {
			// MENOR DE IDADE
			//jQuery("._XUSER_responsibleBlock").dialog('open');
		} else {
			// MAIOR DE IDADE
			//jQuery("._XUSER_responsibleBlock").dialog('close');
		}
	};
	// checa se a idade é menor que 18, e em caso positivo, habilita opção para registrar dados do responsável
	$(":input[name='data_nascimento']").change(checkMinorFunction);
	
	checkMinorFunction();
	
	jQuery("button[name='_XUSER_NOT18AGEOLD_BUTTON']").click(function () {
		//jQuery("._XUSER_responsibleBlock").dialog('open');
	});
	
	jQuery("button.activateUserLink").live("hover", function() {
		
		
	});
	jQuery("button.activateUserLink").tipsy(
		{live: true}
	);
	
	/*
	jQuery("._XUSER_responsibleBlock").dialog({
		autoOpen	: true, 
		show		: "fade",
		hide		: "fade",
		modal		: true,
		width		: 600,
		minWidth	: 600
	});
	*/
});

function xuser_activateUser(el, user) {
	if (jQuery(el).hasClass('red')) { // 
		parameters = {
			activate_user:user, 
			method: 'get'
		};
	} else {
		parameters = {
			deactivate_user:user, 
			method: 'get'
		};
	}
    var url = window.location.pathname + "?ctg=users";
    
    var elem = el;
    
    jQuery.get(
    	url,
    	parameters,
    	function(data, status) {
   			jQuery(el)
   				.toggleClass('red')
   				.toggleClass('green')
   				.attr("title", activeStates[data])
   				.attr("original-title", activeStates[data]);
   			
   			if (data == 1) {
   				jQuery(el)
   					.parents("tr")
   					.find("a.editLink")
   					.css("color", "");
   			} else {
   				jQuery(el)
	   				.parents("tr")
	   				.find("a.editLink")
	   				.css("color", "red");
   			}
    		/*
    		 if (response == 0) {
    		     setImageSrc(el, 16, "trafficlight_red.png");
    		        el.writeAttribute({alt:activate, title:activate});
    		        el.up().up().addClassName('deactivatedTableElement');
    		    } else if (response == 1) {
    		     setImageSrc(el, 16, "trafficlight_green.png");
    		        el.writeAttribute({alt:deactivate, title:deactivate});
    		        el.up().up().removeClassName('deactivatedTableElement');
    		    }
    		*/
    		
    	}
    );
    //ajaxRequest(el, url, parameters, onActivateUser);
}