<?php
define("_TRANSLATE_TRANSLATE","Traduce");//Translate
define("_TRANSLATE_TRANSLATION","Traduceri");//Translation
define("_TRANSLATE_ERRORTRANSLATING","Eroare de traducere");//Error Translating
define("_TRANSLATE_GOTOTRANSLATEPAGE","Du-te la pagina de traducere");//Go to translation page
define("_TRANSLATE_HELLOWORLD","salut lume");//hello world
?>
