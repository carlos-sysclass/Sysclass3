<?php
define("_TRANSLATE_TRANSLATE","ΰ¤…ΰ¤¨ΰ¥ΰ¤µΰ¤Ύΰ¤¦ ΰ¤•ΰ¤°ΰ¤¨ΰ¤Ύ");//Translate
define("_TRANSLATE_TRANSLATION","ΰ¤…ΰ¤¨ΰ¥ΰ¤µΰ¤Ύΰ¤¦");//Translation
define("_TRANSLATE_ERRORTRANSLATING","ΰ¤¤ΰ¥ΰ¤°ΰ¥ΰ¤ΰ¤Ώ ΰ¤…ΰ¤¨ΰ¥ΰ¤µΰ¤Ύΰ¤¦");//Error Translating
define("_TRANSLATE_GOTOTRANSLATEPAGE","ΰ¤…ΰ¤¨ΰ¥ΰ¤µΰ¤Ύΰ¤¦ ΰ¤•ΰ¤°ΰ¤¨ΰ¥‡ ΰ¤•ΰ¥‡ ΰ¤²ΰ¤Ώΰ¤ ΰ¤ΰ¥ƒΰ¤·ΰ¥ΰ¤  ΰ¤ΰ¤Ύΰ¤“");//Go to translation page
define("_TRANSLATE_HELLOWORLD","ΰ¤Ήΰ¥ΰ¤²ΰ¥‹ ΰ¤¦ΰ¥ΰ¤¨ΰ¤Ώΰ¤―ΰ¤Ύ");//hello world
?>
