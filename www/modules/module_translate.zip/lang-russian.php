<?php
define("_TRANSLATE_TRANSLATE","Переводить");//Translate
define("_TRANSLATE_TRANSLATION","Перевод");//Translation
define("_TRANSLATE_ERRORTRANSLATING","Ошибка Перевод");//Error Translating
define("_TRANSLATE_GOTOTRANSLATEPAGE","Перейти на страницу перевода");//Go to translation page
define("_TRANSLATE_HELLOWORLD","привет мир");//hello world
?>
