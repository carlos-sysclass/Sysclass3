<?php
define("_TRANSLATE_TRANSLATE","Translate");
define("_TRANSLATE_TRANSLATION","Translation");
define("_TRANSLATE_ERRORTRANSLATING","Error Translating");
define("_TRANSLATE_GOTOTRANSLATEPAGE","Go to translation page");
define("_TRANSLATE_HELLOWORLD","hello world");
?>