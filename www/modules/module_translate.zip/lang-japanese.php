<?php
define("_TRANSLATE_TRANSLATE","翻訳する");//Translate
define("_TRANSLATE_TRANSLATION","翻訳");//Translation
define("_TRANSLATE_ERRORTRANSLATING","エラーの翻訳");//Error Translating
define("_TRANSLATE_GOTOTRANSLATEPAGE","翻訳のページへ戻る");//Go to translation page
define("_TRANSLATE_HELLOWORLD","こんにちは世界");//hello world
?>
