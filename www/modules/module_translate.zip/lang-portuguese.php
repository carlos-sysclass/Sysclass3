<?php
define("_TRANSLATE_TRANSLATE","Traduzir");//Translate
define("_TRANSLATE_TRANSLATION","Tradução");//Translation
define("_TRANSLATE_ERRORTRANSLATING","Erro de tradução");//Error Translating
define("_TRANSLATE_GOTOTRANSLATEPAGE","Ir para a página de tradução");//Go to translation page
define("_TRANSLATE_HELLOWORLD","Olá mundo");//hello world
?>
