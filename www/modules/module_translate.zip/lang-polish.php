<?php
define("_TRANSLATE_TRANSLATE","Tłumaczyć");//Translate
define("_TRANSLATE_TRANSLATION","Tłumaczenie");//Translation
define("_TRANSLATE_ERRORTRANSLATING","Błąd Przełożenie");//Error Translating
define("_TRANSLATE_GOTOTRANSLATEPAGE","Przejdź do strony tłumaczenia");//Go to translation page
define("_TRANSLATE_HELLOWORLD","Hello World");//hello world
?>
