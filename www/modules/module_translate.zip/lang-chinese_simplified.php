<?php
define("_TRANSLATE_TRANSLATE","翻译");//Translate
define("_TRANSLATE_TRANSLATION","翻译");//Translation
define("_TRANSLATE_ERRORTRANSLATING","翻译错误");//Error Translating
define("_TRANSLATE_GOTOTRANSLATEPAGE","转到翻译一页");//Go to translation page
define("_TRANSLATE_HELLOWORLD","你好世界");//hello world
?>
