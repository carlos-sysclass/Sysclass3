<?php
define("_TRANSLATE_TRANSLATE","Traducir");//Translate
define("_TRANSLATE_TRANSLATION","Traducción");//Translation
define("_TRANSLATE_ERRORTRANSLATING","Traducción de error");//Error Translating
define("_TRANSLATE_GOTOTRANSLATEPAGE","Ir a la página de traducción");//Go to translation page
define("_TRANSLATE_HELLOWORLD","hola mundo");//hello world
?>
