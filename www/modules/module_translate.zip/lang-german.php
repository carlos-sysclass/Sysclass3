<?php
define("_TRANSLATE_TRANSLATE","Übersetzen");//Translate
define("_TRANSLATE_TRANSLATION","Übersetzung");//Translation
define("_TRANSLATE_ERRORTRANSLATING","Fehler beim Übersetzen");//Error Translating
define("_TRANSLATE_GOTOTRANSLATEPAGE","Gehe zu Übersetzungs-Seite");//Go to translation page
define("_TRANSLATE_HELLOWORLD","hallo Welt");//hello world
?>
