<?php
define("_TRANSLATE_TRANSLATE","يترجم");//Translate
define("_TRANSLATE_TRANSLATION","الترجمة");//Translation
define("_TRANSLATE_ERRORTRANSLATING","خطأ ترجمة");//Error Translating
define("_TRANSLATE_GOTOTRANSLATEPAGE","اذهب إلى صفحة الترجمة");//Go to translation page
define("_TRANSLATE_HELLOWORLD","مرحبا العالم");//hello world
?>
