<?php
define("_TRANSLATE_TRANSLATE","Kääntää");//Translate
define("_TRANSLATE_TRANSLATION","Käännös");//Translation
define("_TRANSLATE_ERRORTRANSLATING","Virhe Translating");//Error Translating
define("_TRANSLATE_GOTOTRANSLATEPAGE","Siirry käännös sivu");//Go to translation page
define("_TRANSLATE_HELLOWORLD","Hello World");//hello world
?>
