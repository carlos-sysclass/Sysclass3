<?php
define("_TRANSLATE_TRANSLATE","Traduire");//Translate
define("_TRANSLATE_TRANSLATION","Traduction");//Translation
define("_TRANSLATE_ERRORTRANSLATING","Erreur de traduction");//Error Translating
define("_TRANSLATE_GOTOTRANSLATEPAGE","Aller à la page de traduction");//Go to translation page
define("_TRANSLATE_HELLOWORLD","Bonjour tout le monde");//hello world
?>
