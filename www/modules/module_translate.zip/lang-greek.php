<?php
define("_TRANSLATE_TRANSLATE","Μετάφραση");
define("_TRANSLATE_TRANSLATION","Μετάφραση");
define("_TRANSLATE_ERRORTRANSLATING","Σφάλμα κατά την μετάφραση");
define("_TRANSLATE_GOTOTRANSLATEPAGE","Μετάβαση στη σελίδα μετάφρασης");
define("_TRANSLATE_HELLOWORLD","Γεια σου κόσμε");
?>