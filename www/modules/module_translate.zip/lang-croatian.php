<?php
define("_TRANSLATE_TRANSLATE","Prevesti");//Translate
define("_TRANSLATE_TRANSLATION","Prijevod");//Translation
define("_TRANSLATE_ERRORTRANSLATING","Pogreška Translating");//Error Translating
define("_TRANSLATE_GOTOTRANSLATEPAGE","Idi na stranicu prijevod");//Go to translation page
define("_TRANSLATE_HELLOWORLD","Pozdrav svijetu");//hello world
?>
