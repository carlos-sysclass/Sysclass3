<?php
define("_TRANSLATE_TRANSLATE","Oversette");//Translate
define("_TRANSLATE_TRANSLATION","Oversettelse");//Translation
define("_TRANSLATE_ERRORTRANSLATING","Feil Oversetter");//Error Translating
define("_TRANSLATE_GOTOTRANSLATEPAGE","Gå til oversettelse side");//Go to translation page
define("_TRANSLATE_HELLOWORLD","hello world");//hello world
?>
