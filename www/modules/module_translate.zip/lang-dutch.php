<?php
define("_TRANSLATE_TRANSLATE","Vertalen");//Translate
define("_TRANSLATE_TRANSLATION","Vertaling");//Translation
define("_TRANSLATE_ERRORTRANSLATING","Fout Vertalen");//Error Translating
define("_TRANSLATE_GOTOTRANSLATEPAGE","Ga naar pagina vertaling");//Go to translation page
define("_TRANSLATE_HELLOWORLD","hello world");//hello world
?>
