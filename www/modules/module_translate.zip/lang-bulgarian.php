<?php
define("_TRANSLATE_TRANSLATE","Превеждам");//Translate
define("_TRANSLATE_TRANSLATION","Превод");//Translation
define("_TRANSLATE_ERRORTRANSLATING","Грешка Превод");//Error Translating
define("_TRANSLATE_GOTOTRANSLATEPAGE","Отиди на страница превод");//Go to translation page
define("_TRANSLATE_HELLOWORLD","Здравейте света");//hello world
?>
