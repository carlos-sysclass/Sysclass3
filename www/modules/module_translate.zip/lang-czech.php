<?php
define("_TRANSLATE_TRANSLATE","Přeložit");//Translate
define("_TRANSLATE_TRANSLATION","Překlady");//Translation
define("_TRANSLATE_ERRORTRANSLATING","Chyba Překlad");//Error Translating
define("_TRANSLATE_GOTOTRANSLATEPAGE","Jdi na stránku překladů");//Go to translation page
define("_TRANSLATE_HELLOWORLD","hello world");//hello world
?>
