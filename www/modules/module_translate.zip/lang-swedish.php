<?php
define("_TRANSLATE_TRANSLATE","Översätta");//Translate
define("_TRANSLATE_TRANSLATION","Översättning");//Translation
define("_TRANSLATE_ERRORTRANSLATING","Fel Omsättning");//Error Translating
define("_TRANSLATE_GOTOTRANSLATEPAGE","Gå till översättning sida");//Go to translation page
define("_TRANSLATE_HELLOWORLD","Hello World");//hello world
?>
