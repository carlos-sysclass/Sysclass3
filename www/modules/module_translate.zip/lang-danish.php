<?php
define("_TRANSLATE_TRANSLATE","Oversætte");//Translate
define("_TRANSLATE_TRANSLATION","Oversættelse");//Translation
define("_TRANSLATE_ERRORTRANSLATING","Fejl Omsætning");//Error Translating
define("_TRANSLATE_GOTOTRANSLATEPAGE","Gå til oversættelse side");//Go to translation page
define("_TRANSLATE_HELLOWORLD","Hej verden");//hello world
?>
