<?php
define("_TRANSLATE_TRANSLATE","Tradurre");//Translate
define("_TRANSLATE_TRANSLATION","Traduzione");//Translation
define("_TRANSLATE_ERRORTRANSLATING","Errore Tradurre");//Error Translating
define("_TRANSLATE_GOTOTRANSLATEPAGE","Vai alla pagina di traduzione");//Go to translation page
define("_TRANSLATE_HELLOWORLD","ciao a tutti");//hello world
?>
