<?php
define("_YOUTUBE","YouTube");//YouTube
define("_YOUTUBE_YOUTUBELIST","YouTube liste des liens");//YouTube links list
define("_YOUTUBE_ADDYOUTUBE","Ajouter un lien vidéo");//Add video link
define("_YOUTUBE_PREVIEW","Capture vidéo");//Video snapshot
define("_YOUTUBE_NAME","Vidéo nom");//Video name
define("_YOUTUBE_VIDEOLINK","YouTube lien vidéo");//YouTube video link

define("_YOUTUBE_PROBLEMINSERTINGYOUTUBEENTRY","YouTube lien entrée vidéo n&#39;a pas pu être créé");//YouTube video link entry could not be created
define("_YOUTUBE_SUCCESFULLYINSERTEDYOUTUBEENTRY","Succesfylly lien inséré vidéo");//Succesfylly inserted video link
define("_YOUTUBE_SUCCESFULLYUPDATEDYOUTUBEENTRY","Mis à jour un lien vidéo");//Succesfully updated video link
define("_YOUTUBE_EDITYOUTUBE","Modifier le lien vidéo");//Edit video link
define("_YOUTUBE_DELETEYOUTUBE","Supprimer le lien vidéo");//Delete video link
define("_YOUTUBEAREYOUSUREYOUWANTTODELETEEVENT","Êtes-vous sûr de vouloir supprimer cette liaison vidéo à partir de la liste");//Are you sure you want to delete this video link from the list
define("_YOUTUBE_SUCCESFULLYDELETEDYOUTUBEENTRY","Des liaisons vidéo a été supprimé");//Video links deleted succesfully
define("_YOUTUBENOMEETINGSCHEDULED","La liste des vidéos YouTube est vide");//The YouTube video list is empty

define("_YOUTUBE_DESCRIPTION","Description");//Description
define("_YOUTUBE_YOUTUBEVIDEODATA","Les données vidéo");//Video data
define("_YOUTUBE_MANAGEMENT","Gestion vidéo");//Video management
define("_YOUTUBE_PREVIOUS","Précédent");//Previous
define("_YOUTUBE_NEXT","Suivant");//Next
define("_YOUTUBE_EXAMPLE","Exemple");//Example
?>
