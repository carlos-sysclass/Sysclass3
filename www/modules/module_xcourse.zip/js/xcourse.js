jQuery(function($) {
	
	if (typeof(getCoursesDatatableID) != "undefined") {
		if (jQuery('#' + getCoursesDatatableID).size() > 0) {
			var defaults = {
				"bProcessing": true,
	//			"bServerSide": true,
	//			"sAjaxSource": datatableSourceUrl + "&action=get_xusers_source",
				"bJQueryUI": true,
				"bDeferRender" : true,
				"bSortClasses": false,
				"bAutoWidth": true,
				"bInfo": true,
				"sScrollY": "100%",	
				"sScrollX": "100%",
				"bScrollCollapse": true,
				"sPaginationType": "full_numbers",
				"iDisplayLength"	: 20,
				"aLengthMenu": [[10, 20, 50, 100, -1], [10, 20, 50, 100, "Tudo"]],
				"sDom" : '<"H"lf<"dataTables_outerprocessing"r>>t<"F"ip>',
				/*
				"aoColumns": [
				    { "mDataProp": "login" },
				    { "mDataProp": "user_type_name", sClass : "center" },
				    { "mDataProp": "courses_num", sClass : "center", "bSortable" : false },
				    { "mDataProp": "last_login", sClass : "center"  },
				    { "mDataProp": "active", sClass : "center", "bSortable" : false }
				],
				*/
				"oLanguage": {
					"sUrl": window.location.pathname + "?ctg=module&op=module_language&action=get_section&section_id=datatable&output=json"
				}
			};
			var opt = defaults;
					
			oCourseTable = $('#' + getCoursesDatatableID).dataTable( opt );
		}
		
		
		
		// EVENT HANDLERS
		/*
		jQuery("button.activateUserLink").click(function() {

		}
		*/
	}
	
	if (typeof(editCourse_ID) != 'undefined') {
		 
		defaults = {
				"bProcessing": true,
				"bServerSide": true,
				"sAjaxSource": window.location.pathname + "?ctg=module&op=module_xcourse&action=get_xcourse_users_source&xcourse_id=" + editCourse_ID,
				"fnServerData": function ( sSource, aoData, fnCallback ) {
					/* Add some extra data to the sender */
					if (typeof($_moduleData['xcourse_class_id']) != undefined) {
						aoData.push( { "name": "xcourse_class_id", "value": $_moduleData['xcourse_class_id'] } );	
					}
					
					$.getJSON( sSource, aoData, function (json) { 
						/* Do whatever additional processing you want on the callback, then tell DataTables */
						fnCallback(json)
					} );
				},
				"bJQueryUI": true,
				"bSortClasses": false,
				"bAutoWidth": true,
				"bInfo": true,
				"sScrollY": "100%",	
				"sScrollX": "100%",
				"bScrollCollapse": true,
				"sPaginationType": "full_numbers",
				"iDisplayLength"	: 20,
				"aLengthMenu": [[10, 20, 50, 100, -1], [10, 20, 50, 100, "Tudo"]],
				"sDom" : '<"H"lf<"dataTables_outerprocessing"r>>t<"F"ip>',
				"aoColumns": [
				    { "mDataProp": "login" },
				    { "mDataProp": "user_type", sClass : "center" },
				    { "mDataProp": "active_in_course", sClass : "center"},
				    { "mDataProp": "timestamp_completed", sClass : "center"},
				    //{ "mDataProp": "status", sClass : "center"},
				   // { "mDataProp": "completed", sClass : "center"},
				    { "mDataProp": "score", sClass : "center"},
				    { "mDataProp": "operations", sClass : "center", "bSortable" : false}
				],
				"oLanguage": {
					"sUrl": window.location.pathname + "?ctg=module&op=module_language&action=get_section&section_id=datatable&output=json"
			}
		};
		
		opt = defaults;
					
		var o_xCourseUserTable = jQuery("#_XCOURSE_USERS_LIST").dataTable( opt );
		
		
		jQuery(":input[name='_XCOURSE_USERS_CLASSES_FILTER']").change(function() {
			//alert(jQuery(this).val());
			if (typeof($_moduleData) == 'object') {
				$_moduleData['xcourse_class_id'] = jQuery(this).val();
				o_xCourseUserTable.fnDraw();
			}
		});
		
		jQuery("#_XCOURSE_CLASSES_LIST .usersClassLink").click(function() {
			classeData = jQuery(this).parents("tr").metadata();
			
			jQuery(":input[name='_XCOURSE_USERS_CLASSES_FILTER']")
				.val(classeData['id'])
				.change();
	
			// FOCUS ON TAB
			jQuery("#" + JS_clearStringSymbols($languageJS["__XCOURSE_EDITXCOURSE"]))
				.tabs("select", JS_clearStringSymbols($languageJS["__XCOURSE_EDITXCOURSEUSERS"]));
		});
		
	}
	
	defaults = {
			"bProcessing": true,
			"bJQueryUI": true,
			"bSortClasses": false,
			"bAutoWidth": true,
			"bInfo": true,
			"sScrollY": "100%",	
			"sScrollX": "100%",
			"bScrollCollapse": true,
			"sPaginationType": "full_numbers",
			"iDisplayLength"	: 10,
			"aLengthMenu": [[10, 20, 50, 100, -1], [10, 20, 50, 100, "Tudo"]],
			"oLanguage": {
				"sUrl": window.location.pathname + "?ctg=module&op=module_language&action=get_section&section_id=datatable&output=json"
		}
	};
	opt = defaults;
				
	var o_xCourseClassTable = jQuery("#_XCOURSE_CLASSES_LIST").dataTable( opt );
	
	jQuery("#_XCOURSE_CLASS_FORM").dialog({
		autoOpen: false, 
		show: "fade",
		hide: "fade",
		title : $languageJS['__XCOURSE_EDIT_CLASS_DIALOG_TITLE'],
		modal: true,
		width: 'auto',
		minWidth : 450
	});
	
	jQuery(".addClassLink").click(function() {
		//inject INTO FORM
		jQuery(":input[name='id']", jQuery("form#add_courseclass_form")).val(-1);
//		jQuery(":input[name='a']", jQuery("form#add_courseclass_form")).val(classeData['id']);
		
		jQuery(":input[name='name']", jQuery("form#add_courseclass_form")).val('');
		
		jQuery(":input[name='active']", jQuery("form#add_courseclass_form")).attr("checked",  "checked");
		jQuery("#max-users-slider").slider('value', 30);
		
		jQuery(":input[name='start_date']", jQuery("form#add_courseclass_form")).datepicker('setDate', new Date());
		jQuery(":input[name='end_date']", jQuery("form#add_courseclass_form")).datepicker('setDate', new Date());
		
		jQuery.uniform.update();
		
		jQuery("#_XCOURSE_CLASS_FORM").dialog('option', 'title', $languageJS['__XCOURSE_INSERT_CLASS_DIALOG_TITLE']);
		jQuery("#_XCOURSE_CLASS_FORM").dialog('open');	
		
		return false;
	});
	
	jQuery("#_XCOURSE_CLASSES_LIST .editClassLink").click(function() {
		classeData = jQuery(this).parents("tr").metadata();
		
		//inject INTO FORM
		jQuery(":input[name='id']", jQuery("form#add_courseclass_form")).val(classeData['id']);
//		jQuery(":input[name='a']", jQuery("form#add_courseclass_form")).val(classeData['id']);
		
		jQuery(":input[name='name']", jQuery("form#add_courseclass_form")).val(classeData['name']);
		
		if (classeData['active'] == 1) {
			jQuery(":input[name='active']", jQuery("form#add_courseclass_form")).attr("checked",  "checked");
		} else {
			jQuery(":input[name='active']", jQuery("form#add_courseclass_form")).removeAttr("checked");
		}
		jQuery("#max-users-slider").slider('value', classeData['max_users']);
		
		jQuery(":input[name='start_date']", jQuery("form#add_courseclass_form")).datepicker('setDate', new Date(classeData['start_date'] * 1000));
		endDate = new Date(classeData['end_date'] * 1000);
		endDate.setDate(endDate.getDate()-1);
		
		jQuery(":input[name='end_date']", jQuery("form#add_courseclass_form")).datepicker('setDate', endDate);
		
		jQuery.uniform.update();
		
		jQuery("#_XCOURSE_CLASS_FORM").dialog('option', 'title', $languageJS['__XCOURSE_EDIT_CLASS_DIALOG_TITLE']);
		jQuery("#_XCOURSE_CLASS_FORM").dialog('open');
		
		return false;
	});
	
	jQuery("#_XCOURSE_CLASS_CALENDAR_DIALOG").dialog({
		autoOpen: false, 
		show: "fade",
		hide: "fade",
		title : $languageJS['__XCOURSE_CLASS_CALENDAR_DIALOG_TITLE'],
		modal: true,
		width: 'auto',
		minWidth : 450,
		maxWidth : 800,
		buttons : {
			'Salvar' : function () {
				jQuery(this).find("#schedule_clonable").remove();
				url = jQuery(this).find('form').attr('action');
				
				var self = this;
				jQuery.post(
					url,
					jQuery(this).find('form').serialize(),
					function(data) {
						jQuery.messaging.show(data);
					},
					'json'
				).complete(function(data, response) {
					jQuery(self).dialog('close');
				});
				
			},
			'Cancelar' : function () {
				jQuery(this).dialog('close');
			}
		}
	});
	
	//jQuery('._XCOURSE_CLASS_CALENDAR_START, ._XCOURSE_CLASS_CALENDAR_END').timepicker();

	jQuery("#_XCOURSE_CLASSES_LIST .calendarClassLink").click(function() {
		classeData = jQuery(this).parents("tr").metadata();
		
		var url = 
					window.location.protocol + "//" +
					window.location.hostname +
					window.location.pathname +
					"?ctg=module&op=module_xcourse&action=get_class_schedules" + 
					"&xcourse_id=" + classeData['courses_ID'] + "&xcourse_class_id=" + classeData['id'];
		
		jQuery.get(	url	).complete(function(data, status, result) {
			jQuery("#_XCOURSE_CLASS_CALENDAR_DIALOG")
				.html(data.responseText)
				.dialog('open');
				
			jQuery("#_XCOURSE_CLASS_CALENDAR_DIALOG :input[alt='time']").setMask('time');
		});

		return false;
	});
	
	jQuery(".classScheduleDelete").live('click', function() {
		jQuery(this).parents("li").remove();
	});

	jQuery(".classScheduleInsert").live('click', function() {
		var classScheduleModel = jQuery(this).parents("ul").find("#schedule_clonable").clone();
		
		jQuery(this).parents("li").before(
			classScheduleModel.removeAttr('id').show()
		);
		
		jQuery("#_XCOURSE_CLASS_CALENDAR_DIALOG :input[alt='time']").setMask('time');
	});

	
	
	
	
	jQuery("#" + JS_clearStringSymbols($languageJS["__XCOURSE_EDITXCOURSE"])).bind( "tabsshow", function(event, ui) {

		var oTabTable = $('div.dataTables_scrollBody>table.display', ui.panel).dataTable();
		if ( oTabTable.length > 0 ) {
			oTabTable.fnAdjustColumnSizing();
		}
	});
	if (typeof(slider_value) != 'undefined') {
		jQuery("#max-users-slider").slider({
			range: "min",
			value: slider_value,
			min: 0,
			max: 150,
			change : function( event, ui ) {
				jQuery("#max-users-text").html( ui.value );
				jQuery(":input[name='max_users']").val( ui.value );
			},
			slide : function( event, ui ) {
				jQuery("#max-users-text").html( ui.value );
				jQuery(":input[name='max_users']").val( ui.value );
			}
		});
	}

	jQuery("#max-users-text").html( jQuery( "#max-users-slider" ).slider( "value" ) );
	jQuery(":input[name='max_users']").val( jQuery( "#max-users-slider" ).slider( "value" ) );
});

function xcourse_deleteCourse(el, course) {
	
	var opt = {
			autoOpen: true, 
			show: "fade",
			hide: "fade",
			title : $languageJS['__XCOURSE_DELETE_DIALOG_TITLE'],
			modal: true,
			width: 'auto',
			buttons : {
				'Sim'	: function() {
					var url = window.location.pathname + "?ctg=courses";
					parameters = {delete_course:course, method: 'get'};

				    jQuery.get(
				    	url,
				    	parameters,
				    	function(data, status) {
				    		oCourseTable.fnDeleteRow(
								jQuery(el).parents("tr").get(0)
							);
				    	}
				    );
					
					jQuery(this).dialog('destroy').remove();
				},
				'Não' 	: function() {
					jQuery(this).dialog('destroy').remove();
				}
			}
		};
		
		$dialog = jQuery('<div><p>' + $languageJS['__XCOURSE_DELETE_DIALOG_TEXT'] + '</p></div>');
		$dialog.appendTo("body");
		$dialog.dialog(opt);	
	

	/*
	oCourseTable.fnDraw(true);
	console.log(jQuery(el).parents("tr"));	
	jQuery(el).parents("tr").remove();
	*/
	//
	/*
	var url = window.location.pathname + "?ctg=courses";
	//parameters = {delete_course:course, method: 'get'};
	
    jQuery.get(
    	url,
    	parameters,
    	function(data, status) {
    		oCourseTable.fnDeleteRow( el );
    	}
    );
    */
}

function xcourse_activateCourse(el, course) {
	
	if (jQuery(el).hasClass('red')) { // 
		parameters = {
			activate_course:course, 
			method: 'get'
		};
	} else {
		parameters = {
			deactivate_course:course, 
			method: 'get'
		};
	}
    var url = window.location.pathname + "?ctg=courses";
    
    jQuery.get(
    	url,
    	parameters,
    	function(data, status) {
   			jQuery(el)
   				.toggleClass('red')
   				.toggleClass('green')
   				.attr("title", activeStates[data])
   				.attr("original-title", activeStates[data]);
   			
   			if (data == 1) {
   				jQuery(el)
   					.parents("tr")
   					.find("a.editLink")
   					.css("color", "");
   			} else {
   				jQuery(el)
	   				.parents("tr")
	   				.find("a.editLink")
	   				.css("color", "red");
   			}
    		
    	}
    );
}

function xcourse_confirmUser(el, course, user) {
	 
	if (jQuery(el).hasClass('red')) { // 
		parameters = {edit_course: course, ajax:'confirm_user', user: user, method: 'get'};
	} else {
		parameters = {edit_course: course, ajax:'unconfirm_user', user: user, method: 'get'};
	}
    var url = window.location.pathname + "?ctg=courses";
    
    jQuery.get(
    	url,
    	parameters,
    	function(data, status) {
   			jQuery(el)
   				.toggleClass('red')
   				.toggleClass('green')
   			
   			if (parameters.ajax == 'unconfirm_user') {
   				jQuery(el)
	   				.parents("tr")
	   				.find("a.editLink")
	   				.css("color", "red");
   			} else {
   				jQuery(el)
	   				.parents("tr")
	   				.find("a.editLink")
	   				.css("color", "red");
   			}
    	}
    );
}

function xcourse_deleteCourseClass(el, course, courseclass) {
	 
	var opt = {
		autoOpen: true, 
		show: "fade",
		hide: "fade",
		title : $languageJS['__XCOURSE_DELETE_CLASS_DIALOG_TITLE'],
		modal: true,
		width: 'auto',
		buttons : {
			'Sim'	: function() {
				parameters = {};

				parameters = {
					courseclass 		: course, 
					delete_courseclass  : courseclass, 
					method: 'get'
				};

				var url = window.location.pathname + "?ctg=courses";

				jQuery.get(
				    url,
				    parameters,
				    function(data, status) {
				    	
						window.location.href = 
							window.location.protocol + "//" +
							window.location.hostname +
							window.location.pathname +
							window.location.search + 
							"#" + JS_clearStringSymbols($languageJS["__XCOURSE_EDITXCOURSECLASSES"])
						;
						window.location.reload();
			    	}
			    );				
				
				//window.location.href = T_MODULE_PAGAMENTO_BASEURL + '&action=delete_payment_type&payment_type_id=' + payment_type_id;
			},
			'Não' 	: function() {
				jQuery(this).dialog('destroy').remove();
			}
		}
	};
	
	$dialog = jQuery('<div><p>' + $languageJS['__XCOURSE_DELETE_CLASS_DIALOG_TEXT'] + '</p></div>');
	$dialog.appendTo("body");
	$dialog.dialog(opt);
}
