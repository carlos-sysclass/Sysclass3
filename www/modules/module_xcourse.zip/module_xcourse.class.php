<?php

class module_xcourse extends MagesterModule {
	const GET_XCOURSES				= 'get_xcourses';
	//const GET_XCOURSES_SOURCE			= 'get_xcourses_source';
	const ADD_XCOURSE				= 'add_xcourse';
	const EDIT_XCOURSE				= 'edit_xcourse';
	const DELETE_XCOURSE			= 'delete_xcourse';
	const UPDATE_XCOURSE			= 'update_xcourse';
	
	const CONFIRM_USER_IN_XCOURSE	= 'confirm_user_in_xcourse';
	const UNCONFIRM_USER_IN_XCOURSE	= 'unconfirm_user_in_xcourse';
	
	const GET_CLASS_SCHEDULES		= 'get_class_schedules';
	const SAVE_CLASS_SCHEDULES		= 'save_class_schedules';
	
	const GET_XCOURSE_USERS_SOURCE	= 'get_xcourse_users_source';
	
    // Mandatory functions required for module function
    public function getName() {
        return __XCOURSES;
    }

    public function getPermittedRoles() {
        return array("administrator" /*,"professor" *//*,"student"*/);
    }

    public function isLessonModule() {
        return false;
    }
    
    public function getNavigationLinks() {
    	$selectedAction = isset($_GET['action']) ? $_GET['action'] : self::GET_XCOURSES;

        $basicNavArray = array (
			array ('title' => _HOME, 'link' => "administrator.php?ctg=control_panel"),
    		array ('title' => __XCOURSES_MANAGEMENT, 'link'  => $this -> moduleBaseUrl)
		);
        
		if ($selectedAction == self::EDIT_XCOURSE /* || $selectedAction == self::EDIT_XCOURSE_CLASS */) {
            $basicNavArray[] = array ('title' => __XCOURSE_EDITXCOURSE, 'link'  => $this -> moduleBaseUrl . "&action=" . self::EDIT_XCOURSE . "&xcourse_id=". $_GET['xcourse_id']);
            /**
             * @todo Subsituir por edição do calendário da Turma 
            if ($selectedAction == self::EDIT_XCOURSE_CLASS) {
            	$basicNavArray[] = array ('title' => __XCOURSE_EDITXCOURSE_CLASS, 'link'  => $this -> moduleBaseUrl . "&action=" . self::EDIT_XCOURSE_CLASS . "&xcourse_id=". $_GET['xcourse_id'] . "&xcource_class_id=" . $_GET['xcource_class_id'] );
            }
            */
		} else if ($selectedAction == self::ADD_XCOURSE) {
            $basicNavArray[] = array ('title' => __XCOURSES_ADDXCOURSE, 'link'  => $this -> moduleBaseUrl . "&action=" . self::ADD_XCOURSE);
		}
        return $basicNavArray;
    }

    public function getLinkToHighlight() {
        return 'xcourses_link_id1';
    }
    
    /* MAIN-INDEPENDENT MODULE PAGES */
    public function getModule() {
		$selectedAction = isset($_GET['action']) ? $_GET['action'] : self::GET_XCOURSES;
		
		$js_module_data = array();
		
		if (isset($currentUser -> coreAccess['lessons']) && $currentUser -> coreAccess['lessons'] == 'hidden') {
			eF_redirect(basename($_SERVER['PHP_SELF'])."?ctg=control_panel&message=".urlencode(_UNAUTHORIZEDACCESS)."&message_type=failure");
		} else if (isset($currentUser -> coreAccess['lessons']) && $currentUser -> coreAccess['lessons'] != 'change') {
			$_change_ = false;
		} else {
			$_change_ = true;
		}
		
        // Get smarty global variable
        $smarty = $this -> getSmartyVar();
		
		$smarty -> assign("T_MODULE_XCOURSE_ACTION", $selectedAction);    	
    	
        if ($selectedAction == self::DELETE_XCOURSE && eF_checkParameter($_GET['xcourse_id'], 'id')) {
        	/*
            eF_deleteTableData("module_xcourse", "id=".$_GET['xcourse_id']);
            header("location:". $this -> moduleBaseUrl ."&message=".urlencode(_MODULE_XCOURSES_SUCCESFULLYDELETEDXCOURSEENTRY)."&message_type=success");
            */
        } elseif ($selectedAction == self::UPDATE_XCOURSE && eF_checkParameter($_GET['xcourse_login'], 'login')) {
			/*
        	
        	
        	switch($_GET['field']) {
        		case "user_course.course_type" : {
        			
        			$user_login = $_GET['xcourse_login'];
        			$course_id = $_POST['course_id'];
        			$course_type = $_POST['course_type'];
        			if (!in_array($course_type, array('Presencial', 'Via Web'))) {
        				$course_type = "";
        			}
        			
        			$result = eF_updateTableData(
        				"users_to_courses", 
        				array('course_type' => $course_type), 
        				sprintf("users_LOGIN = '%s' AND courses_ID = %d", $user_login, $course_id) 
        			);
        			
        			var_dump($result);
        			//echo sprintf("users_LOGIN = '%s' AND courses_ID = %d", $user_login, $course_id);
        			
        			if ($result) {
	        			echo json_encode(array(
	        				'status'	=> 'success',
	        				'message'	=> _XCOURSE_UPDATED_SUCCESS
	        			));
        			} else {
	        			echo json_encode(array(
	        				'status'	=> 'error',
	        				'message'	=> _XCOURSE_UPDATED_ERROR
	        			));
        			}
        			exit;

        			break;
        		}
        		default : {
        			
        			
        		}
        		
        	}
        	*/
        } else if ($selectedAction == self::GET_XCOURSE_USERS_SOURCE) {
        	$this->getDatatableSource();
        	exit; 
        	
        } else if ($selectedAction == self::GET_CLASS_SCHEDULES) {
        	// LOAD L10N DATA	
        	$modules = eF_loadAllModules(true);
        	$l10nSection = $modules['module_language']->getSection("l10n");
        	
        	$smarty -> assign("T_L10N_DATA", $l10nSection['data']);
        	
        	
        	// LOAD SCHEDULES FOR CLASS
			$courseClasses = $this->getEditedCourse()->getCourseClasses();
			
			if (eF_checkParameter($_GET['xcourse_class_id'], 'id')) {
				$courseClassID = $_GET['xcourse_class_id'];
				
				//var_dump($courseClasses[$courseClassID]->classe['schedules']);
				
				$smarty -> assign("T_XCOURSE_CLASS_SCHEDULES", $courseClasses[$courseClassID]->classe['schedules']);
				
				$smarty -> assign("T_FORM_ACTION", $this->moduleBaseUrl . '&action=' . self::SAVE_CLASS_SCHEDULES . '&xcourse_class_id=' . $courseClassID);
				
				echo $result = $smarty->fetch(
					$this->moduleBaseDir . '/templates/actions/' . self::GET_CLASS_SCHEDULES . '.tpl'
				);
			}
			exit;
		} else if ($selectedAction == self::SAVE_CLASS_SCHEDULES) {
			
			if (eF_checkParameter($_GET['xcourse_class_id'], 'id')) {
				$insertData = array(
					'week_day' 	=> $_POST['week_day']['new'],
					'start'		=> $_POST['start']['new'],
					'end' 		=> $_POST['end']['new']
				);
				
				unset($_POST['week_day']['new']);
				unset($_POST['start']['new']);
				unset($_POST['end']['new']);
				
				$updateData = array(
					'week_day' 	=> $_POST['week_day'],
					'start'		=> $_POST['start'],
					'end' 		=> $_POST['end']
				);
				

				$courseClassID = $_GET['xcourse_class_id'];
				$courseClass = new MagesterCourseClass($courseClassID);
				
				$courseClass->clearSchedule();
				
				
				foreach($updateData['week_day'] as $index => $value) {
					$courseClass->appendSchedule(
						$updateData['week_day'][$index],
						$updateData['start'][$index],
						$updateData['end'][$index]
					);
				}
				
				//var_dump($courseClass);
				
				foreach($insertData['week_day'] as $index => $value) {
					$courseClass->appendSchedule(
						$insertData['week_day'][$index],
						$insertData['start'][$index],
						$insertData['end'][$index]
					);
				}
				
				if ($courseClass->persistSchedule()) {
					echo json_encode(array(
						'message'		=> __XCOURSE_CLASS_SCHEDULE_SAVE_MESSAGE,
						'message_type'	=> 'success'
					));
				} else {
					echo json_encode(array(
						'message'		=> __XCOURSE_CLASS_SCHEDULE_SAVE_ERROR_MESSAGE,
						'message_type'	=> 'error'
					));
				}
			} else {
				echo json_encode(array(
					'message'		=> __XCOURSE_CLASSID_NOT_FOUND,
					'message_type'	=> 'failure'
				));
			}
			exit;
        } else if (
        	$selectedAction == self::ADD_XCOURSE || 
        	($selectedAction == self::EDIT_XCOURSE && eF_checkParameter($_GET['xcourse_id'], 'id')) ||
        	($selectedAction == self::EDIT_XCOURSE && eF_checkParameter($_GET['xcourse_login'], 'login'))
        ) {
        	

        	
			$smarty -> assign("T_COURSE_OPTIONS", array(
					array(
						'text' => _COURSESETTINGS, 
						'image' => "16x16/generic.png", 
						'href' => basename($_SERVER['PHP_SELF'])."?ctg=courses&course=".$_GET['edit_course']."&op=course_info"
					)
				)
			);


			$form = new HTML_QuickForm("add_courses_form", "post", $_SERVER['REQUEST_URI'], "", null, true);
			$form -> registerRule('checkParameter', 'callback', 'eF_checkParameter');

			$form -> addElement('text', 'name', _COURSENAME, 'class = "large"');
			$form -> addRule('name', _THEFIELD.' "'._COURSENAME.'" '._ISMANDATORY, 'required', null, 'client');
			//$form -> addRule('name', _INVALIDFIELDDATA, 'checkParameter', 'text');
			
   			$schools = eF_getTableDataFlat("module_ies", "id, nome", "active = 1" );
   			
   			if (count($schools) > 0) {
	   			$schools = array_merge(
	   				array(-1 => __SELECT_ONE_OPTION),
	   				array_combine($schools['id'], $schools['nome'])
	   			);
   			} else {
   				$schools = array(-1 => __NO_DISPONIBLE_OPTIONS);
   			}
   			
            $form -> addElement('select', 'ies_id', __IES_FORM_NAME, $schools, 'class = "large"');
            			
			try {
				$directionsTree = new MagesterDirectionsTree();
				if (sizeof($directionsTree -> tree) == 0) {
					eF_redirect(basename($_SERVER['PHP_SELF']).'?ctg=directions&add_direction=1&message='.urlencode(_TOCREATECOURSEYOUMUSTFIRSTCREATECATEGORY).'&message_type=failure');
				}
				$directions = $directionsTree -> toPathString();
			} catch (Exception $e) {
				handleNormalFlowExceptions($e);
			}
			$form -> addElement('select', 'directions_ID', _DIRECTION, $directions); //Append a directions select box to the form
			
			if ($GLOBALS['configuration']['onelanguage'] != true) {
				$languages = MagesterSystem :: getLanguages(true, true);
				$form -> addElement('select', 'languages_NAME', _LANGUAGE, $languages);
			}

			$form -> addElement('advcheckbox', 'active', _ACTIVEFEM, null, null, array(0, 1));
			$form -> addElement('advcheckbox', 'show_catalog', _SHOWCOURSEINCATALOG, null, null, array(0, 1));
			$form -> addElement('text', 'price', __XCOURSE_FORM_PRICE, 'class = "small" alt="decimal"');
			 
			/* PRICE BY MODALIDADE */
			$modalidades = MagesterCourse::getModalidades();
			 
			foreach($modalidades as $groupName => $group) {
				$elems = array();
				foreach($group['fields'] as $fieldName => $field) {
					$elems[] = $form -> addElement($field['type'], $fieldName, $field['label'], $field['attr'], null, $field['options']);
					$form -> setDefaults(array($fieldName => $field['default']));
				}
			//$form->addGroup($elems, $groupName, $group['groupLabel'], ' ');
			}

			
/* 

$form -> addElement('text', 'training_hours', _TRAININGHOURS, 'class = "inputText" style = "width:50px"');


$recurringOptions = array(0 => _NO, 'D' => _DAILY, 'W' => _WEEKLY, 'M' => _MONTHLY, 'Y' => _YEARLY);
$recurringDurations = array('D' => array_combine(range(1, 90), range(1, 90)),
        'W' => array_combine(range(1, 52), range(1, 52)),
        'M' => array_combine(range(1, 24), range(1, 24)),
        'Y' => array_combine(range(1, 5), range(1, 5))); //Imposed by paypal interface
 $form -> addElement('select', 'recurring', _SUBSCRIPTION, $recurringOptions, 'onchange = "$(\'duration_row\').show();$$(\'span\').each(function (s) {if (s.id.match(\'_duration\')) {s.hide();}});if (this.selectedIndex) {$(this.options[this.selectedIndex].value+\'_duration\').show();} else {$(\'duration_row\').hide();}"');
 $form -> addElement('select', 'D_duration', _DAYSCONDITIONAL, $recurringDurations['D']);
 $form -> addElement('select', 'W_duration', _WEEKSCONDITIONAL, $recurringDurations['W']);
 $form -> addElement('select', 'M_duration', _MONTHSCONDITIONAL, $recurringDurations['M']);
 $form -> addElement('select', 'Y_duration', _YEARSCONDITIONAL, $recurringDurations['Y']);
 $form -> addElement('text', 'calendar_event', _CALENDAREVENT, 'class = "inputText"');
 $form -> addElement('text', 'max_users', _MAXIMUMUSERS, 'class = "inputText" style = "width:50px"');
 $form -> addElement('text', 'duration', _AVAILABLEFOR, 'style = "width:50px;"');
 $form -> addRule('duration', _THEFIELD.' "'._AVAILABLEFOR.'" '._MUSTBENUMERIC, 'numeric', null, 'client');
*/
			if ($selectedAction == self::EDIT_XCOURSE) {
				$editCourse = new MagesterCourse($_GET['xcourse_id']);
				$smarty -> assign('T_EDIT_COURSE', $editCourse);
				$form -> setDefaults($editCourse -> options);
				$form -> setDefaults($editCourse -> course);
				$form -> setDefaults(array($editCourse -> options['recurring'].'_duration' => $editCourse -> options['recurring_duration']));
			} else {
				$form -> setDefaults(array(
					'active' 	=> 1,
					'ies_id'	=> -1,
					'show_catalog' => 1,
					'price' => 0,
					'languages_NAME' => $GLOBALS['configuration']['default_language']));
			}
			
			if (!$_change_) {
				$form -> freeze();
			} else {
				$form -> addElement('submit', 'submit_xcourse', _MODULE_XCOURSES_SAVE, 'class = "button_colour round_all"');
				
				if ($form -> isSubmitted() && $form -> validate()) {
	/*
$values = $form -> exportValues();
$fields = array('languages_NAME' => $GLOBALS['configuration']['onelanguage'] ? $GLOBALS['configuration']['default_language'] : $form -> exportValue('languages_NAME'),
       'show_catalog' => $form -> exportValue('show_catalog'),
       'directions_ID' => $form -> exportValue('directions_ID'),
       'name' => $form -> exportValue('name'),
       'active' => $form -> exportValue('active'),
       //'duration'	   	 => $form -> exportValue('duration') ? $form -> exportValue('duration') : null,
       'max_users' => $form -> exportValue('max_users') ? $form -> exportValue('max_users') : null,
       'price' => $form -> exportValue('price'),
       'supervisor_LOGIN' => $values['supervisor_LOGIN'] ? $values['supervisor_LOGIN'] : null);
   
   
   
   
	foreach($modalidades as $groupName => $group) {
 		foreach($group['fields'] as $fieldName => $field) {
 			$fields[$fieldName] = $form -> exportValue($fieldName);
 		}
 	}
 	

   try {
    if (isset($_GET['edit_course'])) {
     if ($fields['directions_ID'] != $editCourse -> course['directions_ID']) {
      $updateCourseInstancesCategory = true; //This means we need to update instances to match the course's new category
     }
     $editCourse -> course = array_merge($editCourse -> course, $fields);
     if ($courseSk = $editCourse -> getCourseSkill()) {
      eF_updateTableData("module_hcd_skills", array("description" => _KNOWLEDGEOFCOURSE . " " .$form -> exportValue('name')), "skill_ID = " .$courseSk['skill_ID']) ;
     }
     $message = _COURSEUPDATED;
     //$redirect = basename($_SERVER['PHP_SELF']).'?ctg=courses&message='.urlencode(_COURSEUPDATED).'&message_type=success';
    } else {
     $editCourse = MagesterCourse :: createCourse($fields);
     
     $message = _SUCCESFULLYCREATEDCOURSE;
     $redirect = basename($_SERVER['PHP_SELF'])."?ctg=courses&edit_course=".$editCourse -> course['id']."&tab=lessons&message=".urlencode(_SUCCESFULLYCREATEDCOURSE)."&message_type=success";
    }
    $message_type = 'success';
    if ($form -> exportValue('price') && $form -> exportValue('recurring') && in_array($form -> exportValue('recurring'), array_keys($recurringOptions))) {
     $editCourse -> options['recurring'] = $form -> exportValue('recurring');
     if ($editCourse -> options['recurring']) {
      $editCourse -> options['recurring_duration'] = $form -> exportValue($editCourse -> options['recurring'].'_duration');
     }
    } else {
     unset($editCourse -> options['recurring']);
    }
    //$editCourse -> course['instance_source'] OR $editCourse -> options['course_code'] = $form -> exportValue('course_code');	//Instances don't have a code of their own
    $editCourse -> options['training_hours'] = $form -> exportValue('training_hours');
    $editCourse -> options['duration'] = $form -> exportValue('duration') ? $form -> exportValue('duration') : null;
    //$editCourse -> options['course_code'] 	 = $form -> exportValue('course_code') ? $form -> exportValue('course_code') : null;
    //$editCourse -> options['duration'] = $form -> exportValue('duration');
    //$start_date = mktime(0, 0, 0, $_POST['date_Month'], $_POST['date_Day'], $_POST['date_Year']);
    $editCourse -> persist();
    if (isset($updateCourseInstancesCategory) && $updateCourseInstancesCategory) {
     eF_updateTableData("courses", array("directions_ID" => $editCourse -> course['directions_ID']), "instance_source=".$editCourse -> course['id']);
    }
    if ($form -> exportValue('branches_ID') && eF_checkParameter($form -> exportValue('branches_ID'), 'id')) {
     $result = eF_getTableDataFlat("module_hcd_course_to_branch", "branches_ID", "courses_ID=".$editCourse -> course['id']);
     if (sizeof($result['branches_ID']) == 0) {
      eF_insertTableData("module_hcd_course_to_branch", array("branches_ID" => $form -> exportValue('branches_ID'), "courses_ID" => $editCourse -> course['id']));
     } elseif (sizeof($result) == 1) {
      //Only one branch associated with this course, as a 'location'
      eF_updateTableData("module_hcd_course_to_branch", array("branches_ID" => $form -> exportValue('branches_ID')), "courses_ID=".$editCourse -> course['id']);
     }
    } else {
    }
    !isset($redirect) OR eF_redirect($redirect);
   } catch (Exception $e) {
       handleNormalFlowExceptions($e);
   }
   */
				}
			}
			/*
			$renderer = prepareFormRenderer($form);
//			$form -> accept($renderer);
			$smarty -> assign('T_MODULE_XCOURSE_BASIC_FORM', $renderer -> toArray());
			*/
		
            $renderer = new HTML_QuickForm_Renderer_ArraySmarty($smarty);
            $form -> accept($renderer);
            $smarty -> assign('T_MODULE_XCOURSE_BASIC_FORM', $renderer -> toArray());
			        	
        	/*
        	if ($selectedAction == self::EDIT_XCOURSE && eF_checkParameter($_GET['xcourse_id'], 'id')) {
        		// GET COURSE BY ID!!!
        		//$editedUser = MagesterUserFactory :: factory($_GET['xcourse_login']);
//        		$editedCourse 
        		 
        	} elseif ($selectedAction == self::EDIT_XCOURSE && eF_checkParameter($_GET['xcourse_login'], 'login')) {
				$editedUser = MagesterUserFactory :: factory($_GET['xcourse_login']);
        	}
        	*/
			/*
			$currentUser = $this->getCurrentUser();
        	
        	
			$form = new HTML_QuickForm("xcourse_entry_form", "post", $_SERVER['REQUEST_URI'], "", null, true);
			$responsibleForm = new HTML_QuickForm("xcourse_responsible_entry_form", "post", $_SERVER['REQUEST_URI'], "", null, true);
			$form -> addElement('hidden', 'xcourse_ID');
			$responsibleForm -> addElement('hidden', 'xcourse_ID');
			
			//Register this rule for checking user input with our function, eF_checkParameter
            $form -> registerRule('checkParameter', 'callback', 'eF_checkParameter');
            
            if ($selectedAction == self::EDIT_XCOURSE) {
            
				// In classic _magester, only the administrator may change someone else's data
				//if (!$editedUser -> isLdapUser) { //needs to check ldap

		   			$form -> addElement('password', 'password_', _PASSWORDLEAVEBLANK, 'autocomplete="off" class = "medium"');
					$form -> addElement('password', 'passrepeat', _REPEATPASSWORD, 'class = "medium "');
					$form -> addRule(array('password_', 'passrepeat'), _PASSWORDSDONOTMATCH, 'compare', null, 'client');
	            
	            	$stateList = localization::getStateList();
	            
					$form -> addElement('text', 'cep', _MODULE_XCOURSES_CEP, 'class = "medium" alt="cep"');
					$form -> addElement('text', 'endereco', _MODULE_XCOURSES_ENDERECO, 'class = "large"');
					$form -> addElement('text', 'numero', _MODULE_XCOURSES_NUMERO, 'class = "small"');
					$form -> addElement('text', 'complemento', _MODULE_XCOURSES_COMPLEMENTO, 'class = "small"');
					$form -> addElement('text', 'bairro', _MODULE_XCOURSES_BAIRRO, 'class = "medium"');
					$form -> addElement('text', 'cidade', _MODULE_XCOURSES_CIDADE, 'class = "medium"');
					$form -> addElement('select', 'uf', _MODULE_XCOURSES_UF, $stateList, 'class = "small"');
					
					$form -> addElement('text', 'telefone', _MODULE_XCOURSES_TELEFONE, 'class = "medium" alt="phone"');
					$responsibleForm -> addElement('text', 'telefone', _MODULE_XCOURSES_TELEFONE, 'class = "medium" alt="phone"');
					$form -> addElement('text', 'celular', _MODULE_XCOURSES_CELULAR, 'class = "medium" alt="phone"');
					$responsibleForm -> addElement('text', 'celular', _MODULE_XCOURSES_CELULAR, 'class = "medium" alt="phone"');
					$form -> addElement('jquerydate', 'data_nascimento', _COURSE_DATA_NASCIMENTO);
					$responsibleForm -> addElement('jquerydate', 'data_nascimento', _COURSE_DATA_NASCIMENTO);
					$form -> addElement('text', 'rg', _COURSE_RG, 'class = "medium"');
					$responsibleForm -> addElement('text', 'rg', _COURSE_RG, 'class = "medium"');
					$form -> addElement('text', 'cpf', _COURSE_CPF, 'class = "medium" alt="cpf"');
					$responsibleForm -> addElement('text', 'cpf', _COURSE_CPF, 'class = "medium" alt="cpf"');
				//} else {
	   			//	$smarty -> assign("T_LDAP_COURSE", true);
  				//}
  				$smarty -> assign("T_COURSE_TYPE", $editedUser -> user['user_type']);
  				$smarty -> assign("T_REGISTRATION_DATE", $editedUser -> user['timestamp']);
  				
	  			try {
	   				$avatar = new MagesterFile($editedUser -> user['avatar']);
	   				$smarty -> assign ("T_AVATAR", urlencode($editedUser -> user['avatar']));
				   list($width, $height) = getimagesize($avatar['path']);
	   				if ($width > 200 || $height > 100) {
					    // Get normalized dimensions
	    				list($newwidth, $newheight) = eF_getNormalizedDims($avatar['path'], 200, 100);
					    // The template will check if they are defined and normalize the picture only if needed
	    				$smarty -> assign("T_NEWWIDTH", $newwidth);
	    				$smarty -> assign("T_NEWHEIGHT", $newheight);
	   				}
	  			} catch (Exception $e) {
	   				$smarty -> assign ("T_AVATAR", urlencode(G_SYSTEMAVATARSPATH."unknown_small.png"));
	  			}
            }
            
            $form -> addElement('text', 'name', _NAME, 'class = "large"');
			$form -> addRule('name', _THEFIELD.' '._NAME.' '._ISMANDATORY, 'required', null, 'client');
			$responsibleForm -> addElement('text', 'name', _NAME, 'class = "large"');
			$responsibleForm -> addRule('name', _THEFIELD.' '._NAME.' '._ISMANDATORY, 'required', null, 'client');
			$form -> addElement('text', 'surname', _SURNAME, 'class = "large"');
 			$form -> addRule('surname', _THEFIELD.' '._SURNAME.' '._ISMANDATORY, 'required', null, 'client');
 			$responsibleForm -> addElement('text', 'surname', _SURNAME, 'class = "large"');
 			$responsibleForm -> addRule('surname', _THEFIELD.' '._SURNAME.' '._ISMANDATORY, 'required', null, 'client');
			$form -> addElement('text', 'email', _EMAILADDRESS, 'class = "large mask-email"');
			$form -> addRule('email', _THEFIELD.' '._EMAILADDRESS.' '._ISMANDATORY, 'required', null, 'client');
			$form -> addRule('email', _INVALIDFIELDDATA, 'checkParameter', 'email');
			
			$responsibleForm -> addElement('text', 'email', _EMAILADDRESS, 'class = "large mask-email"');
			$responsibleForm -> addRule('email', _THEFIELD.' '._EMAILADDRESS.' '._ISMANDATORY, 'required', null, 'client');
			$responsibleForm -> addRule('email', _INVALIDFIELDDATA, 'checkParameter', 'email');
			// Find all groups available to create the select-group drop down
			if (!isset($groups_table)) {
				$groups_table = eF_getTableData("groups", "id, name", "active=1");
			}
			if (!empty($groups_table)) {
				$groups = array ("" => "");
				foreach ($groups_table as $group) {
					$gID = $group['id'];
					$groups["$gID"] = $group['name'];
				}
				$form -> addElement('select', 'group' , _GROUP, $groups ,'class = "medium" id="group" name="group"');
			} else {
				$form -> addElement('select', 'group' , _GROUP, array ("" => _NOGROUPSDEFINED) ,'class = "medium" id="group" name="group" disabled="disabled"');
			}
			

			if ($selectedAction == self::EDIT_XCOURSE) {
				$editedUser -> getGroups();
				$init_group = end($editedUser -> groups);
				$form -> setDefaults(array('group' => $init_group['groups_ID']));

			}
			$resultRole = eF_getTableData("users", "user_types_ID", "login='".$currentUser -> login."'");
			$smarty -> assign("T_CURRENTCOURSEROLEID", $resultRole[0]['user_types_ID']);
			
			$timezones = eF_getTimezones();
			$form -> addElement("select", "timezone", _TIMEZONE, $timezones, 'class = "large" style="width:20em"');
			// Set default values for new users
			if (($selectedAction == self::ADD_XCOURSE) || ($selectedAction == self::EDIT_XCOURSE && $editedUser -> user['timezone'] == "")) {
				$form -> setDefaults(array('timezone' => $GLOBALS['configuration']['time_zone']));
			}
			if ($editedUser->user['login'] == $_SESSION['s_login']) { //prevent a logged admin to change its type
				$form -> freeze(array('user_type'));
			}
			
			
			if ($GLOBALS['configuration']['onelanguage']) {
				$form -> addElement('hidden', 'languages_NAME', $GLOBALS['configuration']['default_language']);
			} else {
				$form -> addElement('select', 'languages_NAME', _LANGUAGE, MagesterSystem :: getLanguages(true, true));
				// Set default values for new users
				if (isset($_GET['add_user'])) {
					$form -> setDefaults(array('languages_NAME' => $GLOBALS['configuration']['default_language']));
				}
			}
			
	         // In HCD mode supervisors - and not only administrators - may create employees
	 		if ($currentUser -> getType() == "administrator") {
	 			$rolesTypes = MagesterUser :: getRoles();
	  			if ($resultRole[0]['user_types_ID'] == 0 || $rolesTypes[$resultRole[0]['user_types_ID']] == "administrator") {
				   	$roles = eF_getTableDataFlat("user_types", "*");
				   	$roles_array['student'] = _STUDENT;
				   	$roles_array['professor'] = _PROFESSOR;
					$roles_array['administrator'] = _ADMINISTRATOR;
					if (sizeof($roles) > 0) {
						for ($k = 0; $k < sizeof($roles['id']); $k++) {
							if ($roles['active'][$k] == 1 || (isset($editedUser) && $editedUser -> user['user_types_ID'] == $roles['id'][$k])) { //Make sure that the user's current role will be listed, even if it's deactivated
								$roles_array[$roles['id'][$k]] = $roles['name'][$k];
							}
						}
					}
					$form -> addElement('select', 'user_type', _COURSETYPE, $roles_array);
				}
				$form -> addElement('advcheckbox', 'active', _ACTIVECOURSE, null, 'class = "inputCheckbox" id="activeCheckbox" ', array(0, 1));
				// Set default values for new users
				if (isset($_GET['add_user'])) {
					$form -> setDefaults(array('active' => '1'));
				}
			}
            
           	$form -> addElement('submit', 'submit_xcourse', _MODULE_XCOURSES_SAVE, 'class = "button_colour round_all"');
           	$responsibleForm -> addElement('submit', 'submit_xcourse', _MODULE_XCOURSES_SAVE, 'class = "button_colour round_all"');
           	
            if ($selectedAction == self::EDIT_XCOURSE) {
            	
				$form -> setDefaults($editedUser -> user);
				$form -> setDefaults(MagesterUserDetails::getUserDetails($editedUser -> user['login']));
				
				//If the user's type is other than the basic types, set the corresponding select box to point to this one
				if ($editedUser -> user['user_types_ID']) {
					$form -> setDefaults(array('user_type' => $editedUser -> user['user_types_ID']));
				}
            	
                $xcourse_entry = eF_getTableData("module_xcourse", "*", "id=".$editedUser -> user['id']);
                
				$defaults = array(
					'xcourse_ID'			=> $xcourse_entry[0]['id'],
					'nome' 				=> $xcourse_entry[0]['nome'],
					'cep'				=> $xcourse_entry[0]['cep'],
					'endereco'			=> $xcourse_entry[0]['endereco'],
					'numero'			=> $xcourse_entry[0]['numero'],
					'complemento'		=> $xcourse_entry[0]['complemento'],
					'bairro'			=> $xcourse_entry[0]['bairro'],
					'cidade'			=> $xcourse_entry[0]['cidade'],
					'uf'				=> $xcourse_entry[0]['uf'],
					'telefone'			=> $xcourse_entry[0]['telefone'],
					'celular'			=> $xcourse_entry[0]['celular'],
					'data_nascimento'	=> $xcourse_entry[0]['data_nascimento']
				);
				
                $xcourse_responsible_entry = eF_getTableData("module_xcourse_responsible", "*", "id=".$editedUser -> user['id']);
                
				$defaultsResponsible = array(
					'xcourse_ID'			=> $xcourse_responsible_entry[0]['id'],
					'name' 				=> $xcourse_responsible_entry[0]['name'],
					'surname' 			=> $xcourse_responsible_entry[0]['surname'],
					'data_nascimento'	=> $xcourse_responsible_entry[0]['data_nascimento'],
					'rg'				=> $xcourse_responsible_entry[0]['rg'],
					'cpf'				=> $xcourse_responsible_entry[0]['cpf'],
					'telefone'			=> $xcourse_responsible_entry[0]['telefone'],
					'celular'			=> $xcourse_responsible_entry[0]['celular']
				);
            } else {
                $defaults = $defaultsResponsible = array(
					'xcourse_ID'		=> -1
				);
            }
            
            $form -> setDefaults( $defaults );
            $responsibleForm -> setDefaults( $defaultsResponsible );

            if ($form -> isSubmitted() && $form -> validate()) {

            	$values = $form->exportValues();
            	
             	if ($selectedAction == self::EDIT_XCOURSE) {
					$users_content = array(
						'name' 				=> $values['name'],
                    	'surname' 			=> $values['surname'],
                        'email' 			=> $values['email'],
                        'user_types_ID' 	=> $values['user_types_ID'],
                        'languages_NAME'	=> $values['languages_NAME'],
                        'timezone' 			=> $values['timezone']
					);
					
    				if ($currentUser -> getType() == "administrator") {
     					$users_content['active'] = $values['active'];
				
     					$users_content['user_type'] = $values['user_type'];
     					$users_content['pending'] = 0; //The user cannot be pending, since the admin sent this information
    				}
    				if (isset($values['password_']) && $values['password_']) {
     					$users_content['password'] = MagesterUser::createPassword($values['password_']);
    				}
				    // If name/surname changed then the sideframe must be reloaded
				    if (
				    	$editedUser -> login == $currentUser -> login && (
				    		$editedUser -> user['languages_NAME'] != $values['languages_NAME'] || 
				    		$editedUser -> user['name'] != $values['name'] || 
				    		$editedUser -> user['surname'] != $values['surname']
				    	)
				    ) {
					    $smarty -> assign("T_REFRESH_SIDE", 1);
     					$smarty -> assign("T_PERSONAL_CTG", 1);
     					if ($_SESSION['s_language'] != $values['languages_NAME']) {
      						$_SESSION['s_language'] = $values['languages_NAME'];
     					}
    				}
    				eF_updateTableData("users", $users_content, "login='".$editedUser -> login."'");
    				
	             	switch ($GLOBALS['configuration']['date_format']) {
						case "YYYY/MM/DD": {
							$date_format = 'Y/m/d'; break;
						}
						case "MM/DD/YYYY": {
							$date_format = 'm/d/Y'; break;
						}
						case "DD/MM/YYYY": 
						default: {
							$date_format = 'd/m/Y'; break;
						}
					}
					
					$values['data_nascimento'] = date_create_from_format($date_format, $values['data_nascimento']);
					
     				$user_details = array(
						'rg'				=> $values['rg'],
						'cpf'				=> $values['cpf'],
						'cep'				=> $values['cep'],
						'endereco'			=> $values['endereco'],
						'numero'			=> $values['numero'],
						'complemento'		=> $values['complemento'],
						'bairro'			=> $values['bairro'],
						'cidade'			=> $values['cidade'],
						'uf'				=> $values['uf'],
						'telefone'			=> $values['telefone'],
						'celular'			=> $values['celular']
				     );
				    if ($values['data_nascimento']) {
				     	$user_details['data_nascimento']	= $values['data_nascimento']->format('Y-m-d');
				    }
     
     				MagesterUserDetails :: injectDetails($editedUser -> login, $user_details);
    
				    // mpaltas temporary solution: manual OO to keep $editedUser object cache consistent
					if ($editedUser -> user['user_type'] != $values['user_type']) {
				     	// the new instance will be of the updated type
						$editedUser = MagesterUserFactory :: factory($_GET['edit_user']);
				    }
				    foreach ($users_content as $field => $content) {
						$editedUser -> user[$field] = $content;
				    }
				    // end of mpaltas temp solution
					$currentUser -> getType() == "administrator" ? $message = _PERSONALDATACHANGESUCCESSADMIN : $message = _PERSONALDATACHANGESUCCESS;
				    $message_type = 'success';
					if (isset($values['password_']) && $values['password_'] && $currentUser -> login == $_GET['edit_user']) { //In case the user changed his password, change it in the session as well
						$_SESSION['s_password'] = $users_content['password'];
				    }
				    // Assignment of user group
				    if ($values['group'] != $init_group['groups_ID']) {
						if ($init_group['groups_ID']) {
							$editedUser -> removeGroups($init_group['groups_ID']);
						}
						if ($values['group']) {
							$editedUser -> addGroups($values['group']);
						} else {
							$groups = eF_getTableDataFlat("groups","id","");
							$editedUser -> removeGroups($groups['id']);
						}
				    }

				    $this->setMessageVar($message, $message_type);
             	
				} else {

				}
            }
            
			if ($responsibleForm -> isSubmitted() && $responsibleForm -> validate()) {

            	$values = $responsibleForm->exportValues();
            	
             	if ($selectedAction == self::EDIT_XCOURSE) {
             	switch ($GLOBALS['configuration']['date_format']) {
						case "YYYY/MM/DD": {
							$date_format = 'Y/m/d'; break;
						}
						case "MM/DD/YYYY": {
							$date_format = 'm/d/Y'; break;
						}
						case "DD/MM/YYYY": 
						default: {
							$date_format = 'd/m/Y'; break;
						}
					}
					
					$values['data_nascimento'] = date_create_from_format($date_format, $values['data_nascimento']);
					
     				$responsible_details = array(
						'name' 				=> $values['name'],
                    	'surname' 			=> $values['surname'],
                        'email' 			=> $values['email'],
						'rg'				=> $values['rg'],
						'cpf'				=> $values['cpf'],
						'telefone'			=> $values['telefone'],
						'celular'			=> $values['celular']
				     );
				    if ($values['data_nascimento']) {
				     	$responsible_details['data_nascimento']	= $values['data_nascimento']->format('Y-m-d');
				    }
				    
				    
					$xcourse_responsible_entry = eF_getTableData("module_xcourse_responsible", "*", "id=".$editedUser -> user['id']);
				    // SAVE DATA
					if (count($xcourse_responsible_entry) == 0) {
						$responsible_details['id']	= $editedUser -> user['id'];
						eF_insertTableData("module_xcourse_responsible", $responsible_details);
					} else {
				        eF_updateTableData("module_xcourse_responsible", $responsible_details, "id='".$editedUser -> user['id'] ."'");
					}				    
    
					$currentUser -> getType() == "administrator" ? $message = _PERSONALDATACHANGESUCCESSADMIN : $message = _PERSONALDATACHANGESUCCESS;
				    $message_type = 'success';

				    $this->setMessageVar($message, $message_type);
             	
				} else {

				}
            }
            
            
            
            
            

            $rendererBasic = new HTML_QuickForm_Renderer_ArraySmarty($smarty);
            $form -> accept($rendererBasic);
            $smarty -> assign('T_MODULE_XCOURSE_BASIC_FORM', $rendererBasic -> toArray());
            
            $rendererResponsible = new HTML_QuickForm_Renderer_ArraySmarty($smarty);
            $responsibleForm -> accept($rendererResponsible);
            $smarty -> assign('T_MODULE_XCOURSE_BASIC_RESPONSIBLE_FORM', $rendererResponsible -> toArray());
            
            
            
            //$rendererExtended = new HTML_QuickForm_Renderer_ArraySmarty($smarty);
            //$form -> accept($rendererExtended);
            
            //$smarty -> assign('T_MODULE_XCOURSE_EXTENDED_FORM', $rendererExtended -> toArray());
            */
            $modules = eF_loadAllModules(true);
            
            $templates = array();
            // ADD / EDIT COURSE
            $templates[] = array(
            	'title'			=> __XCOURSE_EDITBASICXCOURSE,
            	'template'		=> $this->moduleBaseDir . "templates/includes/xcourse.form.basic.tpl",
            	'contentclass'	=> ''
            );
            // ADD / EDIT USER IN CLASSES

            if ($selectedAction == self::EDIT_XCOURSE) {
            	/*
				$roles = MagesterLessonUser :: getLessonsRoles(true);
				$smarty -> assign("T_ROLES", $roles);
				
				$rolesBasic = MagesterLessonUser :: getLessonsRoles();
				$smarty -> assign("T_BASIC_ROLES_ARRAY", $rolesBasic);
				
				$constraints = array('archive' => false, 'active' => 1, 'return_objects' => false);
				$xcourseUsers = $editCourse -> getCourseUsersIncludingUnassigned($constraints);
				
				$smarty -> assign ("T_XCOURSE_USERS_LIST", $xcourseUsers);	
				*/
            	if ($this->getCache('xcourse_class_id') !== FALSE) {
            		$js_module_data['xcourse_class_id'] = $this->getCache('xcourse_class_id');	
            	} else {
            		$this->setCache('xcourse_class_id', ($js_module_data['xcourse_class_id'] = -1));
            	}
 
            	$userClassesFilters = array(
            		-1 	=> __XCOURSE_USERS_WITH_OR_WITHOUT_CLASS,
            		0	=> __XCOURSE_USERS_WITHOUT_CLASS
            	);

	            // COURSE CLASSES (TURMAS)
				$constraints = array('archive' => false, 'active' => true);
				
				$classes = $editCourse -> getCourseClasses($constraints);
				$totalEntries = $editCourse -> countCourseClasses($constraints);
				$xcourseClasses = MagesterCourseClass :: convertClassesObjectsToArrays($classes);
				
				foreach($xcourseClasses as $classe) {
					if ($classe['active'] == 1) {
						$userClassesFilters[$classe['id']] = $classe['name'];
					}
				}
            	
            	$smarty -> assign("T_USER_CLASSES_FILTERS", $userClassesFilters);
            	 
            	
	            $templates[] = array(
	            	'title'			=> __XCOURSE_EDITXCOURSEUSERS,
	            	'template'		=> $this->moduleBaseDir . "templates/includes/xcourse.list.users.tpl",
	            	'contentclass'	=> '',
	            	'class'			=> 'no_padding_color no_padding'
	            );
	            
	            
	            
	            
	            
				$formClass = new HTML_QuickForm(
					"add_courseclass_form", 
					"post", 
					$_SERVER['REQUEST_URI'] . "#" . urlencode(clearStringSymbols(__XCOURSE_EDITXCOURSECLASSES)), 
					"", null, true
				);
				
				$formClass -> addElement('hidden', 'coursesID');
				$formClass -> addElement('hidden', 'action');
				$formClass -> addElement('hidden', 'id');
				
			 	$formClass -> addElement('text', 'name', _COURSECLASSNAME, 'class = "large"');
			 	$formClass -> addRule('name', _THEFIELD.' "'._COURSECLASSNAME.'" '._ISMANDATORY, 'required', null, 'client');
			 	$formClass -> addElement('advcheckbox', 'active', _ACTIVEFEM, null, null, array(0, 1));
			 	//$formClass -> addElement('advcheckbox', 'show_catalog', _SHOWCOURSEINCATALOG, null, null, array(0, 1));

			 	$formClass -> addElement('text', 'max_users', _MAXSTUDENTS, 'style = "display: none;"');
			 	$formClass -> addRule('max_users', _THEFIELD.' "'._MAXSTUDENTS.'" '._ISMANDATORY, 'numeric', null, 'client');
			 	
			 	$formClass -> addElement('jquerydate', 'start_date', _STARTDATE);
			 	$formClass -> addElement('jquerydate', 'end_date', _ENDDATE);
			 	
				$formClass -> addElement('submit', 'submit_xcourse_class', _SUBMIT);
				
				if (!$_change_) {
					$formClass -> freeze();
				} else {
					if ($formClass -> isSubmitted() && $formClass -> validate()) {
						$fields = $formClass -> exportValues();
								
						$fields = array(
							'courses_ID'		=> $formClass -> exportValue('coursesID'),
							'id'				=> $formClass -> exportValue('id'),
							'name'				=> $formClass -> exportValue('name'),
							'info'				=> '',
							'active'			=> $formClass -> exportValue('active'),
							'duration'			=> 0,
							'options'			=> '',
							'languages_NAME'	=> $GLOBALS['configuration']['default_language'], 
							'metadata'			=> null,
							'share_folder'		=> null,
							//'created'			=> time(),
							'max_users'			=> $formClass -> exportValue('max_users'),
							'archive'			=> 0
						);
						if (date_create_from_format('d/m/Y', $formClass -> exportValue('start_date')) !== FALSE) {
							$fields['start_date']	= date_create_from_format('d/m/Y', $formClass -> exportValue('start_date'))->format('U');
						}
						if (date_create_from_format('d/m/Y', $formClass -> exportValue('end_date')) !== FALSE) {
							$fields['end_date']	= date_create_from_format('d/m/Y', $formClass -> exportValue('end_date'))->format('U');
						}
						
						
						
						if (is_numeric($fields['id']) && $fields['id'] > 0) {
							// UPDATE CourseClass	
							$editCourseClass = new MagesterCourseClass($fields['id']);
							$editCourseClass->classe = array_merge($editCourseClass->classe, $fields);
							$editCourseClass->persist();
							
							$this->setMessageVar(__XCOURSE_CLASS_UPDATE_MESSAGE, 'success');
						} else {
							$editCourseClass = MagesterCourseClass:: createCourseClass($fields);
							
							$this->setMessageVar(__XCOURSE_CLASS_INSERT_MESSAGE, 'success');
						}
						
						//$smarty -> assign("T_REDIRECT_PARENT_TO", basename($_SERVER['PHP_SELF'])."?ctg=courses&edit_course=" . $course->course['id'] );
						// RELOAD CLASS LIST
						$classes = $editCourse -> getCourseClasses($constraints);
						$totalEntries = $editCourse -> countCourseClasses($constraints);
						$xcourseClasses = MagesterCourseClass :: convertClassesObjectsToArrays($classes);
					}
				}
				
				$defaults = MagesterCourseClass :: getDefaultCourseClassValues();
				/* GET CONFIG DATE OPTIONS */
				$defaults['start_date']	= date('d/m/Y', $defaults['start_date']);
				$defaults['end_date']	= date('d/m/Y', $defaults['end_date']);
				
				unset($defaults['courses_ID']);
				
				
				
				$formClass->setDefaults($defaults);
				$formClass->setDefaults(array(
					'coursesID'	=> intval($editCourse->course['id'])
				));
				
				$rendererClass = new HTML_QuickForm_Renderer_ArraySmarty($smarty);
				$formClass -> accept($rendererClass);
				$smarty -> assign('T_XCOURSE_CLASS_FORM', $rendererClass -> toArray());
				
				$smarty -> assign ("T_XCOURSE_CLASSES_LIST", $xcourseClasses);				
            	
	            $templates[] = array(
	            	'title'			=> __XCOURSE_EDITXCOURSECLASSES,
	            	'template'		=> $this->moduleBaseDir . "templates/includes/xcourse.list.classes.tpl",
	            	'contentclass'	=> '',
	            	'class'			=> 'no_padding_color no_padding'
	            	
	            );
            }
            
            /*
            if ( in_array($editedUser->getType(), array_keys($editedUser->getLessonsRoles())) ) {
	            $templates[] = array(
	            	'title'			=> _MODULE_XCOURSES_EDITRESPONSIBLEXCOURSE,
	            	'template'		=> $this->moduleBaseDir . "templates/includes/xcourse_responsible_form.tpl",
	            	'contentclass'	=> ''
	            );
            }
            if ( in_array($editedUser->getType(), array_keys($editedUser->getLessonsRoles())) ) {
	            $templates[] = array(
	            	'title'			=> _MODULE_XCOURSES_SHOWCOURSECOURSES,
	            	'template'		=> $this->moduleBaseDir . "templates/includes/xcourse_user_courses.tpl",
	            	'contentclass'	=> ''
	            );
            }
			*/
            foreach ($modules as $module_name => $module) {
            	if (is_callable(array($module, "receiveEvent"))) {
            		$appendTpl = $module->receiveEvent($this, $selectedAction, array('editedCourse' => $editCourse));
            		if (is_array($appendTpl)) {
	        			$templates[] =  $appendTpl;
            		}  
            	}
            }
            
			$smarty -> assign('T_MODULE_XCOURSE_FORM_TABS',
				$templates
			);
			//exit;
/*           
        } elseif ($selectedAction == self::GET_XCOURSES_SOURCE) {
        	//$this->getDatatableSource();
*/
		} else { // $selectedAction == self::GET_XCOURSES

			if (isset($this->getCurrentUser() -> coreAccess['lessons']) && $this->getCurrentUser() -> coreAccess['lessons'] == 'hidden') {
				eF_redirect(basename($_SERVER['PHP_SELF'])."?ctg=control_panel&message=".urlencode(_UNAUTHORIZEDACCESS)."&message_type=failure");
			} else if (isset($this->getCurrentUser() -> coreAccess['lessons']) && $this->getCurrentUser() -> coreAccess['lessons'] != 'change') {
			 	$_change_ = false;
			} else {
			 	$_change_ = true;
			}
			$smarty -> assign("T_MODULE_XCOURSE_CANCHANGE", $_change_);
        	
			$sortedColumns = array('name', 'location', 'num_students', 'num_lessons', 'num_skills', 'start_date', 'end_date', 'price_presencial', 'price_web', 'created', 'active', 'operations');
		
			$smarty -> assign("T_DATASOURCE_SORT_BY", array_search('active', $sortedColumns));
			$smarty -> assign("T_DATASOURCE_SORT_ORDER", 'desc');
			$smarty -> assign("T_DATASOURCE_OPERATIONS", array('statistics', 'settings', 'delete'));
			$smarty -> assign("T_DATASOURCE_COLUMNS", $sortedColumns);
			
			$constraints = array('archive' => false, 'instance' => false);
			$constraints['required_fields'] = array('has_instances', 'location', 'num_students', 'num_lessons', 'num_skills');
			
			$courses = MagesterCourse :: getAllCourses($constraints);
			$totalEntries = MagesterCourse :: countAllCourses($constraints);
			$dataSource = MagesterCourse :: convertCourseObjectsToArrays($courses);
			
			/*
			echo '<pre>';
			var_dump($dataSource);
			
			echo '</pre>';
			exit;
			*/
			
			$smarty -> assign("T_XCOURSE_DATASOURCE", $dataSource);
			$smarty -> assign("T_XCOURSE_DATASOURCE_COUNT", $totalEntries);
			
        /*
			$users = eF_getTableData("users", "*", "archive = 0");
			$user_lessons = eF_getTableDataFlat("users_to_lessons as ul, lessons as l", "ul.users_LOGIN, count(ul.lessons_ID) as lessons_num", "ul.lessons_ID=l.id AND l.archive=0", "", "ul.users_LOGIN");
			$user_courses = eF_getTableDataFlat("users_to_courses as uc, courses as c", "uc.users_LOGIN, count(uc.courses_ID) as courses_num", "uc.courses_ID=c.id AND c.archive=0", "", "uc.users_LOGIN");
			$user_groups = eF_getTableDataFlat("users_to_groups", "users_LOGIN, count(groups_ID) as groups_num", "", "", "users_LOGIN");
			$user_lessons = array_combine($user_lessons['users_LOGIN'], $user_lessons['lessons_num']);
			$user_courses = array_combine($user_courses['users_LOGIN'], $user_courses['courses_num']);
			$user_groups = array_combine($user_groups['users_LOGIN'], $user_groups['groups_num']);
			array_walk($users, create_function('&$v, $k, $s', '$s[$v["login"]] ? $v["lessons_num"] = $s[$v["login"]] : $v["lessons_num"] = 0;'), $user_lessons); //Assign lessons number to users array (this way we eliminate the need for an expensive explicit loop)
			array_walk($users, create_function('&$v, $k, $s', '$s[$v["login"]] ? $v["courses_num"] = $s[$v["login"]] : $v["courses_num"] = 0;'), $user_courses);
			array_walk($users, create_function('&$v, $k, $s', '$s[$v["login"]] ? $v["groups_num"] = $s[$v["login"]] : $v["groups_num"] = 0;'), $user_groups);
			$result = eF_getTableDataFlat("logs", "users_LOGIN, timestamp", "action = 'login'", "timestamp");
			$lastLogins = array_combine($result['users_LOGIN'], $result['timestamp']);
		            
			foreach ($users as $key => $value) {
				$users[$key]['last_login'] = $lastLogins[$value['login']];
				if (isset($_COOKIE['toggle_active'])) {
					if (($_COOKIE['toggle_active'] == 1 && !$value['active']) || ($_COOKIE['toggle_active'] == -1 && $value['active'])) {
						unset($users[$key]);
					}
				}
			}
		*/	
//			$smarty -> assign("T_COURSES_SIZE", sizeof($users));

//            $smarty -> assign("T_XCOURSES", $users);

			$smarty -> assign("T_CURRENT_USER", $this->getCurrentUser());
//            $smarty -> assign("T_XROLES", MagesterUser :: getRoles(true));
            
//            $smarty -> assign("T_XCOURSES", $xcourses);
        }
        
        $smarty -> assign("T_JS_MODULE_DATA", $js_module_data);
        
        return true;
    }
    
    public function getSmartyTpl() {
        $smarty = $this -> getSmartyVar();
        $smarty -> assign("T_MODULE_XCOURSE_BASEDIR" , $this -> moduleBaseDir);
        $smarty -> assign("T_MODULE_XCOURSE_BASEURL" , $this -> moduleBaseUrl);
        $smarty -> assign("T_MODULE_XCOURSE_BASELINK" , $this -> moduleBaseLink);
        
        $selectedAction = isset($_GET['action']) ? $_GET['action'] : self::GET_XCOURSES;
        
        if (
        	$selectedAction == self::ADD_XCOURSE ||
	       	$selectedAction == self::EDIT_XCOURSE
		) {
			if ($selectedAction == self::ADD_XCOURSE) {
				$smarty -> assign("T_MODULE_XCOURSE_FORM_TABS_TITLE", __XCOURSE_ADDXCOURSE);
			} elseif ($selectedAction == self::EDIT_XCOURSE) {
				$smarty -> assign("T_MODULE_XCOURSE_FORM_TABS_TITLE", __XCOURSE_EDITXCOURSE);
			}
			$smarty -> assign('T_MODULE_XCOURSE_MAIN_TEMPLATE', 'includes/xcourse.block.add_edit_course.tpl');
		}
        
        return $this -> moduleBaseDir . "templates/default.tpl";
    }

/*    
    public function addScripts() {
    	return array('jquery/jquery.meio.mask');
    }
*/
    /*
    public function addStylesheets() {
    	return array('fullcalendar/fullcalendar');
    }
    */
    public function getModuleCSS() {
		return $this -> moduleBaseDir . "css/xcourse.css";
    }
    public function getModuleJS() {
		return $this -> moduleBaseDir . "js/xcourse.js";
    }
    
    public function getEditedCourse($reload = false, $course_ID = null) {
    	if (!is_null($login)) {
    		return $this->editedCourse = new MagesterCourse($course_ID);
    	}
    	if (!is_null($this->editedCourse) && !$reload) {
    		return $this->editedCourse;
    	}
		if (eF_checkParameter($_GET['xcourse_id'], 'id')) {
			return $this->editedCourse = new MagesterCourse($_GET['xcourse_id']);
		}
    	return false;
    }
    
    protected function getDatatableSource() {
		$selectedAction = isset($_GET['action']) ? $_GET['action'] : self::GET_XCOURSES;
    	
    	if ($selectedAction == self::GET_XCOURSE_USERS_SOURCE) {
		
			/* Array of database columns which should be read and sent back to DataTables. Use a space where
			 * you want to insert a non-database field (for example a counter or static image)
			 */
    		$editCourse = new MagesterCourse($_GET['xcourse_id']);
            	
			$roles = MagesterLessonUser :: getLessonsRoles(true);
				
			$rolesBasic = MagesterLessonUser :: getLessonsRoles();
				
			$constraints = array(
				'archive' => false, 
				'active' => 1, 
				'return_objects' => false
			);
			$xcourseUsersCount = $editCourse -> countCourseUsersIncludingUnassigned($constraints);

			// APPEND WHERE CONSTRAINTS
			$aColumns = array(
				'login',
				'user_type',
				'active_in_course',
				'timestamp_completed',
              	'active_in_course',
				//'completed',
				'score',
				'operations'			
			);
			
			/*
			Filter By => $_GET['xcourse_class_id']
			$_GET['xcourse_class_id'] == -1 // IGNORE PARAM
			$_GET['xcourse_class_id'] == 0 // USERS WITHOUT CLASS
			$_GET['xcourse_class_id'] > 0 // USE THIS CLASS 
			*/
			$this->setCache('xcourse_class_id', $_GET['xcourse_class_id']);
			
			switch($_GET['xcourse_class_id']) {
				case "-1" : {
					break;
				}
				case "0" : {
					$constraints['condition'] = "u.id NOT IN (
					    SELECT users_ID FROM users_to_classes ucl WHERE ucl.classes_ID IN (
					        SELECT id FROM classes cla WHERE cla.courses_ID = r.courses_ID
					    )
					)";
					break;
				}
				default  : {
					if (is_numeric($_GET['xcourse_class_id']) && $_GET['xcourse_class_id'] > 0) {
						$constraints['condition'] = sprintf(
							"u.id IN (
						    	SELECT users_ID FROM users_to_classes ucl WHERE ucl.classes_ID = %d AND ucl.classes_ID IN (
						        	SELECT id FROM classes cla WHERE cla.courses_ID = r.courses_ID
						    	)
							)", $_GET['xcourse_class_id']
						);
					}					
				}
			}
			
    		//$sWhere = $sFixedWhere = "usr.archive = 0";
			if ( $_GET['sSearch'] != "" )
			{
				/*
				$sWhere .= " AND (login LIKE '%".mysql_real_escape_string( $_GET['sSearch'] )."%' OR ";
				$sWhere .= "name LIKE '%".mysql_real_escape_string( $_GET['sSearch'] )."%' OR ";
				$sWhere .= "surname LIKE '%".mysql_real_escape_string( $_GET['sSearch'] )."%')";
				*/
				
				$constraints['filter'] = $_GET['sSearch'];
			}
			
			
    		if ( isset( $_GET['iSortCol_0'] ) )
			{
				//$sOrder = "ORDER BY  ";
				for ( $i=0 ; $i<intval( $_GET['iSortingCols'] ) ; $i++ )
				{
					if ( $_GET[ 'bSortable_'.intval($_GET['iSortCol_'.$i]) ] == "true" )
					{
						$constraints['sort']	= $aColumns[ intval( $_GET['iSortCol_'.$i] ) ];
						$constraints['order']	= mysql_real_escape_string( $_GET['sSortDir_'.$i] );
					}
				}
				
				$sOrder = substr_replace( $sOrder, "", -2 );
				/*
				if ( $sOrder == "ORDER BY" )
				{
					$sOrder = "";
				}
				*/
			}
    		/* 
			 * Paging
			 */
			$sLimit = "";
			if ( isset( $_GET['iDisplayStart'] ) && $_GET['iDisplayLength'] != '-1' )
			{
				$constraints['limit'] 	= mysql_real_escape_string( $_GET['iDisplayLength'] );
				$constraints['offset']	= mysql_real_escape_string( $_GET['iDisplayStart'] );
			}
			
			$xcourseUsers = $editCourse -> getCourseUsersIncludingUnassigned($constraints);
			$xcourseUsersDisplayedCount = $editCourse -> countCourseUsersIncludingUnassigned($constraints);
			
			$output = array(
				"sEcho" => intval($_GET['sEcho']),
				"iTotalRecords" => intval($xcourseUsersCount),
				"iTotalDisplayRecords" => intval($xcourseUsersDisplayedCount),
				"aaData" => array()
			);
			
			$activeString = '
				<button class="%2$s skin_colour round_all activateUserLink" title = "%1$s" %3$s>
				<img 
					class = "ajaxHandle" 
					src = "/' . G_CURRENTTHEMEURL . '/images/icons/small/white/alert_2.png"
					width="16" 
					height="16"
					alt = "%1$s" 
					>
				</button>';
			
			$canChange = false;
			
			//var_dump($this->getCurrentUser()->coreAccess);
			if (
				!isset($this->getCurrentUser()->coreAccess['users']) || 
				$this->getCurrentUser()->coreAccess['users'] == 'change'
			) {
				$canChange = true;
			}
			
			foreach($xcourseUsers as $xcourseUser) {
				$operationButtons = array();
			
				$row = array();
				$row["DT_RowId"] 	= "xcourse_user_" . $xcourseUser['id'];
				
				$url = $_SESSION['s_type'] . '.php?ctg=module&op=module_xuser' . "&action=edit_xuser&xuser_login=" . $xcourseUser[ 'login' ];
				
				$row["login"] = sprintf(
					'<a href = "%s" class = "editLink" %s>%s</a>',
					$url,
					$xcourseUser['active_in_course'] == 0 ? 'style="color:red;"' : '',
					formatLogin(null, $xcourseUser)
				);
				
				$row['user_type']			= $roles[$xcourseUser['user_type']];
				
				$row['active_in_course']	= !is_null($xcourseUser['active_in_course']) && $xcourseUser['active_in_course'] != 0 ? strftime('%d/%m/%Y', $xcourseUser['active_in_course']) : '';
				
				$row['timestamp_completed']	= !is_null($xcourseUser['timestamp_completed']) && $xcourseUser['timestamp_completed'] != 0 ? strftime('%d/%m/%Y', $xcourseUser['timestamp_completed']) : '';
				
				/** @todo Checar função para formatar inteiros, decimais, monetários, percentuais, etc.. */
				$row['score']				= str_replace('.', ',', sprintf("%0.2f", $xcourseUser['score']) . '%');
				
				//var_dump($xcourseUser);
				
				if (is_null($xcourseUser['active_in_course'])) {
					$operationButtons[] = sprintf('
						<button class="%2$s skin_colour round_all enrollUser" title = "%1$s">
							<img 
								src = "/' . G_CURRENTTHEMEURL . '/images/icons/small/white/books.png"
								width="16" 
								height="16"
								alt = "%1$s" 
								>
						</button>',
						__XCOURSE_ENROLLUSER_HINT,
						""
					);
           		} elseif ($xcourseUser['active_in_course'] != 0) {
					$operationButtons[] = sprintf(
						$activeString, 
						_DEACTIVATE, 
						"green",
						($canChange) ? 
							'onclick = "xcourse_confirmUser(this, ' . $editCourse->course['id'] . ', \'' . $xcourseUser['login'] . '\'); "' : 
							"" 
					);
           		} else {
					$operationButtons[] = sprintf(
						$activeString, 
						_ACTIVATE, 
						"red",
						($canChange) ? 
							'onclick = "xcourse_confirmUser(this, ' . $editCourse->course['id'] . ', \'' . $xcourseUser['login'] . '\'); "' : 
							"" 
					);
				}
				
				$row['operations']			= sprintf('
					<div class="button_display">
					%s
					</div>', implode(' ', $operationButtons)
				);								
				
				
				$output['aaData'][] = $row;
				
			}
			header("Content-Type: application/javascript");
	
			//usort($output['aaData'], create_function('$first, $last', 'return $first["user_type_name"] < $last["user_type_name"] ? -1 : 1;'));
			
			echo json_encode( $output );
			exit;
    	}
    }
}
?>