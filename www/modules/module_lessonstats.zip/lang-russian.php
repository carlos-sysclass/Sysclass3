<?php
define("_LESSONSTATS","Урок статистика");//Lesson statistics
define("_LESSONSTATS_LESSONLINK","Урок статистика");//Lesson statistics
define("_LESSONSTATS_MODULE","Урок модуль статистики");//Lesson Statistics Module
define("_LESSONSTATS_MAIN","Главная страница");//Main page
define("_LESSONSTATS_LASTLOGINS","Последний урок регистрационную");//Last lesson logins
define("_LESSONSTATS_LOGIN","Войти");//Login
define("_LESSONSTATS_LOGINTIME","Логин времени");//Login time
define("_LESSONSTATS_LOGINDURATION","Логин срок");//Login duration
define("_LESSONSTATS_NOLOGINSFOUND","Нет урок регистрационную найдено");//No lesson logins found
define("_LESSONSTATS_GOTOLESSONSTATSPAGE","Перейти на страницу Урок статистика");//Go to Lesson statistics page
?>
