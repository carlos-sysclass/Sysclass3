<?php
define("_LESSONSTATS","Lektions-Statistiken");//Lesson statistics
define("_LESSONSTATS_LESSONLINK","Lektion-Statistiken");//Lesson statistics
define("_LESSONSTATS_MODULE","Lektions-Statistik-Modul");//Lesson Statistics Module
define("_LESSONSTATS_MAIN","Startseite");//Main page
define("_LESSONSTATS_LASTLOGINS","Letzte Lektion Logins");//Last lesson logins
define("_LESSONSTATS_LOGIN","Anmeldung");//Login
define("_LESSONSTATS_LOGINTIME","Login Zeit");//Login time
define("_LESSONSTATS_LOGINDURATION","Login Dauer");//Login duration
define("_LESSONSTATS_NOLOGINSFOUND","Keine Lektions-Logins gefunden");//No lesson logins found
define("_LESSONSTATS_GOTOLESSONSTATSPAGE","Gehe zu Seite Lektions-Statistiken");//Go to Lesson statistics page
?>
