<?php
define("_LESSONSTATS","Στατιστικά μαθήματος");
define("_LESSONSTATS_LESSONLINK", "Στατιστικά μαθήματος");
define("_LESSONSTATS_MODULE", "Άρθρωμα στατιστικά μαθήματος");
define("_LESSONSTATS_MAIN", "Κύρια Σελίδα");
define("_LESSONSTATS_LASTLOGINS", "Τελευταίες συνδέσεις στο μάθημα");
define("_LESSONSTATS_LOGIN", "Login");
define("_LESSONSTATS_LOGINTIME", "Ημερομηνία σύνδεσης");
define("_LESSONSTATS_LOGINDURATION", "Διάρκεια σύνδεσης");
define("_LESSONSTATS_NOLOGINSFOUND", "Δεν βρέθηκαν συνδέσεις στο μάθημα");
define("_LESSONSTATS_GOTOLESSONSTATSPAGE", "Μετάβαση στη σελίδα των Στατιστικών μαθήματος");
?>