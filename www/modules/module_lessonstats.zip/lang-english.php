<?php
define("_LESSONSTATS","Lesson statistics");
define("_LESSONSTATS_LESSONLINK", "Lesson statistics");
define("_LESSONSTATS_MODULE", "Lesson Statistics Module");
define("_LESSONSTATS_MAIN", "Main page");
define("_LESSONSTATS_LASTLOGINS", "Last lesson logins");
define("_LESSONSTATS_LOGIN", "Login");
define("_LESSONSTATS_LOGINTIME", "Login time");
define("_LESSONSTATS_LOGINDURATION", "Login duration");
define("_LESSONSTATS_NOLOGINSFOUND", "No lesson logins found");
define("_LESSONSTATS_GOTOLESSONSTATSPAGE", "Go to Lesson statistics page");
?>