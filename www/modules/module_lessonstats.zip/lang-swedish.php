<?php
define("_LESSONSTATS","Lektion statistik");//Lesson statistics
define("_LESSONSTATS_LESSONLINK","Lektion statistik");//Lesson statistics
define("_LESSONSTATS_MODULE","Lektion statistik modul");//Lesson Statistics Module
define("_LESSONSTATS_MAIN","Startsida");//Main page
define("_LESSONSTATS_LASTLOGINS","Senaste lektionen inloggningar");//Last lesson logins
define("_LESSONSTATS_LOGIN","Logga in");//Login
define("_LESSONSTATS_LOGINTIME","Logga in tid");//Login time
define("_LESSONSTATS_LOGINDURATION","Logga in varaktighet");//Login duration
define("_LESSONSTATS_NOLOGINSFOUND","Ingen läxa inloggningar hittades");//No lesson logins found
define("_LESSONSTATS_GOTOLESSONSTATSPAGE","Gå till Lektion statistik sida");//Go to Lesson statistics page
?>
