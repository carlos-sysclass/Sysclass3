<?php
define("_LESSONSTATS","Lesson statistieken");//Lesson statistics
define("_LESSONSTATS_LESSONLINK","Lesson statistieken");//Lesson statistics
define("_LESSONSTATS_MODULE","Lesson Statistieken module");//Lesson Statistics Module
define("_LESSONSTATS_MAIN","Hoofd pagina");//Main page
define("_LESSONSTATS_LASTLOGINS","Laatste les logins");//Last lesson logins
define("_LESSONSTATS_LOGIN","Inloggen");//Login
define("_LESSONSTATS_LOGINTIME","Login tijd");//Login time
define("_LESSONSTATS_LOGINDURATION","Login duur");//Login duration
define("_LESSONSTATS_NOLOGINSFOUND","Geen les logins gevonden");//No lesson logins found
define("_LESSONSTATS_GOTOLESSONSTATSPAGE","Ga naar Lesson statistieken pagina");//Go to Lesson statistics page
?>
