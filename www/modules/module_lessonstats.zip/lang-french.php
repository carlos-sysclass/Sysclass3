<?php
define("_LESSONSTATS","Leçon statistiques");//Lesson statistics
define("_LESSONSTATS_LESSONLINK","Leçon statistiques");//Lesson statistics
define("_LESSONSTATS_MODULE","Leçon module de statistiques");//Lesson Statistics Module
define("_LESSONSTATS_MAIN","Page principale");//Main page
define("_LESSONSTATS_LASTLOGINS","Dernière leçon de connexion");//Last lesson logins
define("_LESSONSTATS_LOGIN","Connexion");//Login
define("_LESSONSTATS_LOGINTIME","Login temps");//Login time
define("_LESSONSTATS_LOGINDURATION","Login durée");//Login duration
define("_LESSONSTATS_NOLOGINSFOUND","Pas de leçon de connexion trouvés");//No lesson logins found
define("_LESSONSTATS_GOTOLESSONSTATSPAGE","Aller à la page de statistiques de leçon");//Go to Lesson statistics page
?>
