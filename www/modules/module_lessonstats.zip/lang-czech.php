<?php
define("_LESSONSTATS","Lekce statistika");//Lesson statistics
define("_LESSONSTATS_LESSONLINK","Lekce statistika");//Lesson statistics
define("_LESSONSTATS_MODULE","Lekce Statistika modulu");//Lesson Statistics Module
define("_LESSONSTATS_MAIN","Hlavní stránka");//Main page
define("_LESSONSTATS_LASTLOGINS","Poslední lekci přihlášení");//Last lesson logins
define("_LESSONSTATS_LOGIN","Přihlásit");//Login
define("_LESSONSTATS_LOGINTIME","Čas přihlášení");//Login time
define("_LESSONSTATS_LOGINDURATION","Přihlásit se doba trvání");//Login duration
define("_LESSONSTATS_NOLOGINSFOUND","Ne lekci loginu nalezeno");//No lesson logins found
define("_LESSONSTATS_GOTOLESSONSTATSPAGE","Jdi na stránku lekce statistika");//Go to Lesson statistics page
?>
