<?php
define("_LESSONSTATS","Lektion statistik");//Lesson statistics
define("_LESSONSTATS_LESSONLINK","Lektion statistik");//Lesson statistics
define("_LESSONSTATS_MODULE","Lektion Statistik modul");//Lesson Statistics Module
define("_LESSONSTATS_MAIN","Main page");//Main page
define("_LESSONSTATS_LASTLOGINS","Seneste lektion logins");//Last lesson logins
define("_LESSONSTATS_LOGIN","Login");//Login
define("_LESSONSTATS_LOGINTIME","Login tid");//Login time
define("_LESSONSTATS_LOGINDURATION","Login varighed");//Login duration
define("_LESSONSTATS_NOLOGINSFOUND","Nr. lektion logins fundet");//No lesson logins found
define("_LESSONSTATS_GOTOLESSONSTATSPAGE","Gå til Lektion statistikker side");//Go to Lesson statistics page
?>
