<?php
define("_LESSONSTATS","Leksjon statistikk");//Lesson statistics
define("_LESSONSTATS_LESSONLINK","Leksjon statistikk");//Lesson statistics
define("_LESSONSTATS_MODULE","Leksjon statistikk modulen");//Lesson Statistics Module
define("_LESSONSTATS_MAIN","Hovedside");//Main page
define("_LESSONSTATS_LASTLOGINS","Sist leksjon innlogginger");//Last lesson logins
define("_LESSONSTATS_LOGIN","Innlogging");//Login
define("_LESSONSTATS_LOGINTIME","Login tid");//Login time
define("_LESSONSTATS_LOGINDURATION","Login varighet");//Login duration
define("_LESSONSTATS_NOLOGINSFOUND","Ingen lekse innlogginger funnet");//No lesson logins found
define("_LESSONSTATS_GOTOLESSONSTATSPAGE","Gå til leksjon statistikk siden");//Go to Lesson statistics page
?>
