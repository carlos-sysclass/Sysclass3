<?php
define("_LESSONSTATS","Obrazovni statistika");//Lesson statistics
define("_LESSONSTATS_LESSONLINK","Obrazovni statistika");//Lesson statistics
define("_LESSONSTATS_MODULE","Obrazovni Modul statistike");//Lesson Statistics Module
define("_LESSONSTATS_MAIN","Glavna stranica");//Main page
define("_LESSONSTATS_LASTLOGINS","Posljednji sat prijave");//Last lesson logins
define("_LESSONSTATS_LOGIN","Prijava");//Login
define("_LESSONSTATS_LOGINTIME","Login vrijeme");//Login time
define("_LESSONSTATS_LOGINDURATION","Login trajanje");//Login duration
define("_LESSONSTATS_NOLOGINSFOUND","Nema pronađenih sat prijave");//No lesson logins found
define("_LESSONSTATS_GOTOLESSONSTATSPAGE","Idi na stranicu Obrazovni statistika");//Go to Lesson statistics page
?>
