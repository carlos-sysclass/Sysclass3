<?php
define("_LESSONSTATS","Estatísticas da lição");//Lesson statistics
define("_LESSONSTATS_LESSONLINK","Estatísticas da lição");//Lesson statistics
define("_LESSONSTATS_MODULE","Módulo das estatísticas da lição");//Lesson Statistics Module
define("_LESSONSTATS_MAIN","Página principal");//Main page
define("_LESSONSTATS_LASTLOGINS","Logins da última lição");//Last lesson logins
define("_LESSONSTATS_LOGIN","Login");//Login
define("_LESSONSTATS_LOGINTIME","Hora de Login");//Login time
define("_LESSONSTATS_LOGINDURATION","Duração de Login");//Login duration
define("_LESSONSTATS_NOLOGINSFOUND","Nao foi encontrado nehum login para lição");//No lesson logins found
define("_LESSONSTATS_GOTOLESSONSTATSPAGE","Ir à página estatísticas da lição");//Go to Lesson statistics page
?>
