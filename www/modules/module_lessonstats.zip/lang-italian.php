<?php
define("_LESSONSTATS","Lezione statistiche");//Lesson statistics
define("_LESSONSTATS_LESSONLINK","Lezione statistiche");//Lesson statistics
define("_LESSONSTATS_MODULE","Lezione modulo statistiche");//Lesson Statistics Module
define("_LESSONSTATS_MAIN","Pagina principale");//Main page
define("_LESSONSTATS_LASTLOGINS","Ultima lezione login");//Last lesson logins
define("_LESSONSTATS_LOGIN","Accesso");//Login
define("_LESSONSTATS_LOGINTIME","Login tempo");//Login time
define("_LESSONSTATS_LOGINDURATION","Login durata");//Login duration
define("_LESSONSTATS_NOLOGINSFOUND","N. lezione login trovato");//No lesson logins found
define("_LESSONSTATS_GOTOLESSONSTATSPAGE","Vai alla pagina delle statistiche Lezione");//Go to Lesson statistics page
?>
