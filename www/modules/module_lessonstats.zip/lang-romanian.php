<?php
define("_LESSONSTATS","Lectia statistici");//Lesson statistics
define("_LESSONSTATS_LESSONLINK","Lectia statistici");//Lesson statistics
define("_LESSONSTATS_MODULE","Lectia Modulul de statistici");//Lesson Statistics Module
define("_LESSONSTATS_MAIN","Pagina principală");//Main page
define("_LESSONSTATS_LASTLOGINS","Ultima lecţie login");//Last lesson logins
define("_LESSONSTATS_LOGIN","Conecta");//Login
define("_LESSONSTATS_LOGINTIME","Login timp");//Login time
define("_LESSONSTATS_LOGINDURATION","Login durata");//Login duration
define("_LESSONSTATS_NOLOGINSFOUND","Nu lectie de login găsit");//No lesson logins found
define("_LESSONSTATS_GOTOLESSONSTATSPAGE","Du-te la pagina Lectia statistici");//Go to Lesson statistics page
?>
