<?php
define("_LESSONSTATS","Oppitunnin tilastot");//Lesson statistics
define("_LESSONSTATS_LESSONLINK","Oppitunnin tilastot");//Lesson statistics
define("_LESSONSTATS_MODULE","Oppitunnin Tilastot moduuli");//Lesson Statistics Module
define("_LESSONSTATS_MAIN","PRH");//Main page
define("_LESSONSTATS_LASTLOGINS","Viimeisin opetus kirjautumistunnuksensa");//Last lesson logins
define("_LESSONSTATS_LOGIN","Kirjautuminen");//Login
define("_LESSONSTATS_LOGINTIME","Kirjaudu aika");//Login time
define("_LESSONSTATS_LOGINDURATION","Kirjaudu kesto");//Login duration
define("_LESSONSTATS_NOLOGINSFOUND","Ei opetus kirjautumistunnuksensa löytyi");//No lesson logins found
define("_LESSONSTATS_GOTOLESSONSTATSPAGE","Siirry Oppitunnin tilastot sivu");//Go to Lesson statistics page
?>
