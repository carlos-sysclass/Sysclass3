<?php
define("_LESSONSTATS","統計課");//Lesson statistics
define("_LESSONSTATS_LESSONLINK","統計課");//Lesson statistics
define("_LESSONSTATS_MODULE","統計模塊課");//Lesson Statistics Module
define("_LESSONSTATS_MAIN","主網頁");//Main page
define("_LESSONSTATS_LASTLOGINS","上次的教訓登錄");//Last lesson logins
define("_LESSONSTATS_LOGIN","註冊");//Login
define("_LESSONSTATS_LOGINTIME","登錄時間");//Login time
define("_LESSONSTATS_LOGINDURATION","登錄時間");//Login duration
define("_LESSONSTATS_NOLOGINSFOUND","沒有找到登錄的教訓");//No lesson logins found
define("_LESSONSTATS_GOTOLESSONSTATSPAGE","到課統計頁面");//Go to Lesson statistics page
?>
