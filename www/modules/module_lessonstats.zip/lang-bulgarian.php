<?php
define("_LESSONSTATS","Урок статистика");//Lesson statistics
define("_LESSONSTATS_LESSONLINK","Урок статистика");//Lesson statistics
define("_LESSONSTATS_MODULE","Урок статистика модул");//Lesson Statistics Module
define("_LESSONSTATS_MAIN","Основна страница");//Main page
define("_LESSONSTATS_LASTLOGINS","Последните данни за вход урок");//Last lesson logins
define("_LESSONSTATS_LOGIN","Влизам");//Login
define("_LESSONSTATS_LOGINTIME","Вход за времето");//Login time
define("_LESSONSTATS_LOGINDURATION","Вход продължителност");//Login duration
define("_LESSONSTATS_NOLOGINSFOUND","Не урок намерени данни за вход");//No lesson logins found
define("_LESSONSTATS_GOTOLESSONSTATSPAGE","Отиди на страница Урок статистика");//Go to Lesson statistics page
?>
