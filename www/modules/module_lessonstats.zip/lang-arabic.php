<?php
define("_LESSONSTATS","الدرس الإحصائيات");//Lesson statistics
define("_LESSONSTATS_LESSONLINK","الدرس الإحصائيات");//Lesson statistics
define("_LESSONSTATS_MODULE","الدرس الإحصائيات وحدة");//Lesson Statistics Module
define("_LESSONSTATS_MAIN","الصفحة الرئيسية");//Main page
define("_LESSONSTATS_LASTLOGINS","الدرس الأخير تسجيل الدخول");//Last lesson logins
define("_LESSONSTATS_LOGIN","تسجيل الدخول");//Login
define("_LESSONSTATS_LOGINTIME","دخول الوقت");//Login time
define("_LESSONSTATS_LOGINDURATION","مدة تسجيل الدخول");//Login duration
define("_LESSONSTATS_NOLOGINSFOUND","العثور على أي درس تسجيل الدخول");//No lesson logins found
define("_LESSONSTATS_GOTOLESSONSTATSPAGE","الدرس الإحصائيات اذهب إلى صفحة");//Go to Lesson statistics page
?>
