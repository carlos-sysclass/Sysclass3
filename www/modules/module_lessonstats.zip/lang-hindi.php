<?php
define("_LESSONSTATS","ΰ¤Έΰ¤¬ΰ¤• ΰ¤†ΰ¤ΰ¤•ΰ¤΅ΰ¤Όΰ¥‡");//Lesson statistics
define("_LESSONSTATS_LESSONLINK","ΰ¤Έΰ¤¬ΰ¤• ΰ¤†ΰ¤ΰ¤•ΰ¤΅ΰ¤Όΰ¥‡");//Lesson statistics
define("_LESSONSTATS_MODULE","ΰ¤Έΰ¤¬ΰ¤• ΰ¤†ΰ¤ΰ¤•ΰ¤΅ΰ¤Όΰ¥‡ ΰ¤®ΰ¥‰ΰ¤΅ΰ¥ΰ¤―ΰ¥‚ΰ¤²");//Lesson Statistics Module
define("_LESSONSTATS_MAIN","ΰ¤®ΰ¥ΰ¤–ΰ¥ΰ¤― ΰ¤ΰ¥ƒΰ¤·ΰ¥ΰ¤ ");//Main page
define("_LESSONSTATS_LASTLOGINS","ΰ¤ΰ¤Ώΰ¤›ΰ¤²ΰ¥‡ ΰ¤Έΰ¤¬ΰ¤• ΰ¤²ΰ¥‰ΰ¤—ΰ¤Ώΰ¤¨");//Last lesson logins
define("_LESSONSTATS_LOGIN","ΰ¤²ΰ¥‰ΰ¤— ΰ¤‡ΰ¤¨");//Login
define("_LESSONSTATS_LOGINTIME","ΰ¤²ΰ¥‰ΰ¤—ΰ¤‡ΰ¤¨ ΰ¤Έΰ¤®ΰ¤―");//Login time
define("_LESSONSTATS_LOGINDURATION","ΰ¤²ΰ¥‰ΰ¤—ΰ¤Ώΰ¤¨ ΰ¤…ΰ¤µΰ¤§ΰ¤Ώ");//Login duration
define("_LESSONSTATS_NOLOGINSFOUND","ΰ¤•ΰ¥‹ΰ¤ ΰ¤Έΰ¤¬ΰ¤• ΰ¤²ΰ¥‰ΰ¤—ΰ¤Ώΰ¤¨ ΰ¤ΰ¤Ύΰ¤―ΰ¤Ύ");//No lesson logins found
define("_LESSONSTATS_GOTOLESSONSTATSPAGE","ΰ¤Έΰ¤¬ΰ¤• ΰ¤†ΰ¤ΰ¤•ΰ¤΅ΰ¤Όΰ¥‡ ΰ¤ΰ¥ƒΰ¤·ΰ¥ΰ¤  ΰ¤ΰ¤° ΰ¤ΰ¤Ύΰ¤ΰ¤");//Go to Lesson statistics page
?>
