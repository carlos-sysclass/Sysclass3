<?php
define("_LESSONSTATS","统计课");//Lesson statistics
define("_LESSONSTATS_LESSONLINK","统计课");//Lesson statistics
define("_LESSONSTATS_MODULE","统计模块课");//Lesson Statistics Module
define("_LESSONSTATS_MAIN","主网页");//Main page
define("_LESSONSTATS_LASTLOGINS","上次的教训登录");//Last lesson logins
define("_LESSONSTATS_LOGIN","注册");//Login
define("_LESSONSTATS_LOGINTIME","登录时间");//Login time
define("_LESSONSTATS_LOGINDURATION","登录时间");//Login duration
define("_LESSONSTATS_NOLOGINSFOUND","没有找到登录的教训");//No lesson logins found
define("_LESSONSTATS_GOTOLESSONSTATSPAGE","到课统计页面");//Go to Lesson statistics page
?>
