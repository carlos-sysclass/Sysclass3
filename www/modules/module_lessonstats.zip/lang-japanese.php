<?php
define("_LESSONSTATS","レッスン統計");//Lesson statistics
define("_LESSONSTATS_LESSONLINK","レッスン統計");//Lesson statistics
define("_LESSONSTATS_MODULE","レッスンの統計モジュール");//Lesson Statistics Module
define("_LESSONSTATS_MAIN","メインページ");//Main page
define("_LESSONSTATS_LASTLOGINS","最後のレッスンログイン");//Last lesson logins
define("_LESSONSTATS_LOGIN","ログイン");//Login
define("_LESSONSTATS_LOGINTIME","ログイン時間");//Login time
define("_LESSONSTATS_LOGINDURATION","ログイン期間");//Login duration
define("_LESSONSTATS_NOLOGINSFOUND","レッスンはありませんログインが見つかりました");//No lesson logins found
define("_LESSONSTATS_GOTOLESSONSTATSPAGE","レッスンの統計情報のページへ");//Go to Lesson statistics page
?>
