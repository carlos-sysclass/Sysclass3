<?php
define("_LESSONSTATS","Lección estadísticas");//Lesson statistics
define("_LESSONSTATS_LESSONLINK","Lección estadísticas");//Lesson statistics
define("_LESSONSTATS_MODULE","Lección módulo de estadísticas");//Lesson Statistics Module
define("_LESSONSTATS_MAIN","Página Principal");//Main page
define("_LESSONSTATS_LASTLOGINS","Última lección de inicios de sesión");//Last lesson logins
define("_LESSONSTATS_LOGIN","Inicio de sesión");//Login
define("_LESSONSTATS_LOGINTIME","Login tiempo");//Login time
define("_LESSONSTATS_LOGINDURATION","Login duración");//Login duration
define("_LESSONSTATS_NOLOGINSFOUND","No encontró lección inicios de sesión");//No lesson logins found
define("_LESSONSTATS_GOTOLESSONSTATSPAGE","Ir a la página de estadísticas Lección");//Go to Lesson statistics page
?>
