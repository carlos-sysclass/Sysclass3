<?php

class module_school extends MagesterModule {
	
	const GET_SCHOOLS				= 'get_schools';
	const ADD_SCHOOL				= 'add_school';
	const EDIT_SCHOOL				= 'edit_school';
	const DELETE_SCHOOL				= 'delete_school';
	
    // Mandatory functions required for module function
    public function getName() {
        return _MODULE_SCHOOL;
    }

    public function getPermittedRoles() {
        return array("administrator" /*,"professor" *//*,"student"*/);
    }

    public function isLessonModule() {
        return false;
    }
    
	// Optional functions
    // What should happen on installing the module
    public function onInstall() {
        eF_executeNew("drop table if exists module_schools");
        $a = eF_executeNew("CREATE TABLE IF NOT EXISTS `module_schools` (
  		`id` mediumint(8) NOT NULL AUTO_INCREMENT,
  		`nome` varchar(250) NOT NULL,
  		`razao_social` varchar(250) NOT NULL,
  		`contato` varchar(250) NOT NULL,
  		`observacoes` text,
  		`cep` varchar(15) NOT NULL,
  		`endereco` varchar(150) NOT NULL,
  		`numero` varchar(15) NOT NULL,
  		`complemento` varchar(50) DEFAULT NULL,
  		`bairro` varchar(100) DEFAULT NULL,
  		`cidade` varchar(100) NOT NULL,
  		`uf` varchar(20) NOT NULL,
  		`telefone` varchar(20) DEFAULT NULL,
  		`celular` varchar(20) DEFAULT NULL,
  		`active` tinyint(4) NOT NULL DEFAULT '1',
  		PRIMARY KEY (`id`)
	) ENGINE=MyISAM  DEFAULT CHARSET=utf8;");

        return $a;
    }

    // And on deleting the module
    public function onUninstall() {
        $a = eF_executeNew("drop table module_schools;");

        return $a;
    }


    public function getCenterLinkInfo() {
        $currentUser = $this -> getCurrentUser();
        if ($currentUser -> getType() == "administrator") {
            return array('title' => _MODULE_SCHOOL,
                         'image' => $this -> moduleBaseDir . 'images/schools.png',
                         'link'  => $this -> moduleBaseUrl
            );
        }
    }

    public function getNavigationLinks() {
    	$selectedAction = isset($_GET['action']) ? $_GET['action'] : self::GET_SCHOOLS;

        $basicNavArray = array (
			array ('title' => _HOME, 'link' => "administrator.php?ctg=control_panel"),
    		array ('title' => _MODULE_SCHOOLS_MANAGEMENT, 'link'  => $this -> moduleBaseUrl)
		);
        
		if ($selectedAction == self::EDIT_SCHOOL) {
            $basicNavArray[] = array ('title' => _MODULE_SCHOOLS_EDITSCHOOL, 'link'  => $this -> moduleBaseUrl . "&action=" . self::EDIT_SCHOOL . "&school_id=". $_GET['school_id']);
		} else if ($selectedAction == self::ADD_SCHOOL) {
            $basicNavArray[] = array ('title' => _MODULE_SCHOOLS_ADDSCHOOL, 'link'  => $this -> moduleBaseUrl . "&action=" . self::ADD_SCHOOL);
		}
        return $basicNavArray;
    }

    public function getSidebarLinkInfo() {

        $link_of_menu_clesson = array (array ('id' => 'schools_link_id1',
                                              'title' => _MODULE_SCHOOL,
                                              'image' => $this -> moduleBaseDir . 'images/schools16.png',
                                              '_magesterExtensions' => '1',
                                              'link'  => $this -> moduleBaseUrl));

        return array ( "content" => $link_of_menu_clesson);

    }

    public function getLinkToHighlight() {
        return 'schools_link_id1';
    }
    
    /* MAIN-INDEPENDENT MODULE PAGES */
    public function getModule() {
		$selectedAction = isset($_GET['action']) ? $_GET['action'] : self::GET_SCHOOLS;
		
		$smarty = $this -> getSmartyVar();
		
		$smarty -> assign("T_MODULE_SCHOOLS_ACTION", $selectedAction);    	
    	
        // Get smarty global variable
        $smarty = $this -> getSmartyVar();

        if ($selectedAction == self::DELETE_SCHOOL && eF_checkParameter($_GET['school_id'], 'id')) {
            eF_deleteTableData("module_schools", "id=".$_GET['school_id']);
            
            header("location:". $this -> moduleBaseUrl ."&message=".urlencode(_MODULE_SCHOOLS_SUCCESFULLYDELETEDSCHOOLENTRY)."&message_type=success");
        } else if (
        	$selectedAction == self::ADD_SCHOOL || 
        	($selectedAction == self::EDIT_SCHOOL && eF_checkParameter($_GET['school_id'], 'id'))
        ) {

            // Create ajax enabled table for meeting attendants
            if ($selectedAction == self::EDIT_SCHOOL) {
                if (isset($_GET['ajax']) && $_GET['ajax'] == 'schoolTable') {
                    isset($_GET['limit']) && eF_checkParameter($_GET['limit'], 'uint') ? $limit = $_GET['limit'] : $limit = G_DEFAULT_TABLE_SIZE;

                    if (isset($_GET['sort']) && eF_checkParameter($_GET['sort'], 'text')) {
                        $sort = $_GET['sort'];
                        isset($_GET['order']) && $_GET['order'] == 'desc' ? $order = 'desc' : $order = 'asc';
                    } else {
                        $sort = 'login';
                    }
/*
                    $users = eF_getTableData("users JOIN users_to_lessons ON users.login = users_to_lessons.users_LOGIN
                                                    JOIN module_onsync ON module_onsync.lessons_ID = users_to_lessons.lessons_ID
                                                    LEFT OUTER JOIN module_onsync_users_to_meeting ON module_onsync.internal_ID = module_onsync_users_to_meeting.meeting_ID AND users.login = module_onsync_users_to_meeting.users_LOGIN",
                    
                                                    "users.login, users.name, users.surname, users.email, meeting_ID",
                    								
                                                    " users_to_lessons.archive = 0 " .  
                                                    " AND users_to_lessons.lessons_ID = '".$_SESSION['s_lessons_ID'] . "'" .  
                                                    " AND users.login <> '".$currentUser -> user['login'] . "'" .
                    								" AND (module_onsync.classes_ID = -1 OR users.id IN (SELECT users_ID FROM users_to_classes WHERE classes_ID = module_onsync.classes_ID)) " . 
                                                    " AND module_onsync.internal_ID = '".$_GET['edit_onsync']."'"
					);
*/					
                    $schools = eF_getTableData("module_schools", "*" );

                    $users = eF_multiSort($users, $_GET['sort'], $order);
                    if (isset($_GET['filter'])) {
                        $users = eF_filterData($users , $_GET['filter']);
                    }

                    $smarty -> assign("T_USERS_SIZE", sizeof($users));

                    if (isset($_GET['limit']) && eF_checkParameter($_GET['limit'], 'int')) {
                        isset($_GET['offset']) && eF_checkParameter($_GET['offset'], 'int') ? $offset = $_GET['offset'] : $offset = 0;
                        $users = array_slice($users, $offset, $limit);
                    }

					$smarty -> assign("T_SCHOOLS", $schools);
                    $smarty -> display($this -> getSmartyTpl());
                    exit;

                } else {
                    $schools = eF_getTableData("module_schools", "*" );
                    $smarty -> assign("T_SCHOOLS", $schools);
                }
            }

            $form = new HTML_QuickForm("school_entry_form", "post", $_SERVER['REQUEST_URI'], "", null, true);
			$form -> addElement('hidden', 'school_ID');
			
            $form -> registerRule('checkParameter', 'callback', 'eF_checkParameter');                   //Register this rule for checking user input with our function, eF_checkParameter
            /*
            $accounts = array();
            
            foreach($this->accounts as $key => $item) {
            	$accounts[$key]	= $item['name'];
            }
            */
            
            $stateList = localization::getStateList();
            
            $form -> addElement('text', 'nome', _MODULE_SCHOOLS_NOME, 'class = "large"');
            $form -> addRule('nome', _MODULE_SCHOOLS_THEFIELDNAMEISMANDATORY, 'required', null, 'client');
            $form -> addElement('text', 'razao_social', _MODULE_SCHOOLS_RAZAO_SOCIAL, 'class = "large"');
            $form -> addRule('razao_social', _MODULE_SCHOOLS_THEFIELDRAZAOSOCIALISMANDATORY, 'required', null, 'client');
            $form -> addElement('text', 'contato', _MODULE_SCHOOLS_CONTATO, 'class = "large"');
			$form -> addElement('text', 'cep', _MODULE_SCHOOLS_CEP, 'class = "medium"');
			$form -> addElement('text', 'endereco', _MODULE_SCHOOLS_ENDERECO, 'class = "large"');
			$form -> addElement('text', 'numero', _MODULE_SCHOOLS_NUMERO, 'class = "small"');
			$form -> addElement('text', 'complemento', _MODULE_SCHOOLS_COMPLEMENTO, 'class = "small"');
			$form -> addElement('text', 'bairro', _MODULE_SCHOOLS_BAIRRO, 'class = "medium"');
			$form -> addElement('text', 'cidade', _MODULE_SCHOOLS_CIDADE, 'class = "medium"');
			$form -> addElement('select', 'uf', _MODULE_SCHOOLS_UF, $stateList, 'class = "small"');
			$form -> addElement('text', 'telefone', _MODULE_SCHOOLS_TELEFONE, 'class = "medium"');
			$form -> addElement('text', 'celular', _MODULE_SCHOOLS_CELULAR, 'class = "medium"');
			$form -> addElement('textarea', 'observacoes', _MODULE_SCHOOLS_OBSERVACOES, 'class = "large"');
			$form -> addElement('advcheckbox', 'active', _MODULE_SCHOOLS_ACTIVE, null, '', array(0, 1));
			
            $form -> addElement('submit', 'submit_school', _MODULE_SCHOOLS_SAVE, 'class = "button_colour round_all"');
            
            if ($selectedAction == self::EDIT_SCHOOL) {
                $school_entry = eF_getTableData("module_schools", "*", "id=".$_GET['school_id']);
                
				$defaults = array(
					'school_ID'		=> $school_entry[0]['id'],
					'nome' 			=> $school_entry[0]['nome'],
					'razao_social'	=> $school_entry[0]['razao_social'],
					'contato'		=> $school_entry[0]['contato'],
					'observacoes'	=> $school_entry[0]['observacoes'],
					'cep'			=> $school_entry[0]['cep'],
					'endereco'		=> $school_entry[0]['endereco'],
					'numero'		=> $school_entry[0]['numero'],
					'complemento'	=> $school_entry[0]['complemento'],
					'bairro'		=> $school_entry[0]['bairro'],
					'cidade'		=> $school_entry[0]['cidade'],
					'uf'			=> $school_entry[0]['uf'],
					'telefone'		=> $school_entry[0]['telefone'],
					'celular'		=> $school_entry[0]['celular'],
					'active'		=> (bool)($school_entry[0]['active'] == '1')				
				);
            } else {
                $defaults = array(
					'school_ID'		=> -1,
                	'active'		=> 1           
				);
            }
            $form -> setDefaults( $defaults );            

            if ($form -> isSubmitted() && $form -> validate()) {
            	$fields = array(
					'nome' 			=> $form -> exportValue('nome'),
					'razao_social'	=> $form -> exportValue('razao_social'),
					'contato'		=> $form -> exportValue('contato'),
					'observacoes'	=> $form -> exportValue('observacoes'),
					'cep'			=> $form -> exportValue('cep'),
					'endereco'		=> $form -> exportValue('endereco'),
					'numero'		=> $form -> exportValue('numero'),
					'complemento'	=> $form -> exportValue('complemento'),
					'bairro'		=> $form -> exportValue('bairro'),
					'cidade'		=> $form -> exportValue('cidade'),
					'uf'			=> $form -> exportValue('uf'),
					'telefone'		=> $form -> exportValue('telefone'),
					'celular'		=> $form -> exportValue('celular'),
					'active'		=> $form -> exportValue('active')				
            	);
            	
             	if ($selectedAction == self::EDIT_SCHOOL) {
             		$fields['id']	= $form -> exportValue('school_ID');
             		
					if (eF_updateTableData("module_schools", $fields, "id=".$_GET['school_id'])) {
						header("location:".$this -> moduleBaseUrl."&message=".urlencode(_MODULE_SCHOOLS_SUCCESFULLYUPDATEDSCHOOLENTRY)."&message_type=success");
					} else {
						header("location:".$this -> moduleBaseUrl."&action=" . self::EDIT_SCHOOL ."&school_id=".$_GET['school_id']."&message=".urlencode(_MODULE_SCHOOLS_PROBLEMUPDATINGSCHOOLENTRY)."&message_type=failure");
					}
				} else {
					if ($result = eF_insertTableData("module_schools", $fields)) {
						header("location:".$this -> moduleBaseUrl."&action=" . self::EDIT_SCHOOL ."&school_id=".$result."&message=".urlencode(_MODULE_SCHOOLS_SUCCESFULLYINSERTEDSCHOOLENTRY)."&message_type=success&tab=users");
					} else {
						header("location:".$this -> moduleBaseUrl."&action=" . self::ADD_SCHOOL . "&message=".urlencode(_MODULE_SCHOOLS_PROBLEMINSERTINGSCHOOLENTRY)."&message_type=failure");
					}
				}
            }
            
            $renderer = new HTML_QuickForm_Renderer_ArraySmarty($smarty);
            $form -> accept($renderer);

            $smarty -> assign('T_MODULE_SCHOOLS_FORM', $renderer -> toArray());
        } else {
			$schools = eF_getTableData("module_schools", "*" );
            $smarty -> assign("T_SCHOOLS", $schools);
        }
        return true;
    }

    public function getSmartyTpl() {
        $smarty = $this -> getSmartyVar();
        $smarty -> assign("T_MODULE_SCHOOLS_BASEDIR" , $this -> moduleBaseDir);
        $smarty -> assign("T_MODULE_SCHOOLS_BASEURL" , $this -> moduleBaseUrl);
        $smarty -> assign("T_MODULE_SCHOOLS_BASELINK" , $this -> moduleBaseLink);
        
        $selectedAction = isset($_GET['action']) ? $_GET['action'] : self::GET_SCHOOLS;
        
        //$smarty -> assign("T_MODULE_SCHOOLS_ACTION", $selectedAction);
        
        return $this -> moduleBaseDir . "templates/default.tpl";
    }
}
?>
