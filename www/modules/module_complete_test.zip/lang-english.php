<?php
define("_COMPLETE_TEST_CORRECTTEST", "Complete test");
define("_COMPLETE_TEST_SETVALUES", "Set values");
define("_COMPLETE_TEST_IMPORTFILE", "Import results file");
define("_COMPLETE_TEST", "Complete test module");
?>