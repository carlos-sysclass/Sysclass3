<?php
define("_COMPLETE_TEST_CORRECTTEST", "Ολοκλήρωση αξιολόγησης");
define("_COMPLETE_TEST_SETVALUES", "Προσθήκη απαντήσεων");
define("_COMPLETE_TEST_IMPORTFILE", "Εισαγωγή αρχείου αποτελεσμάτων");
?>